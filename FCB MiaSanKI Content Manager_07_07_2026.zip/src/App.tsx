import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Layers, GitFork, Sparkles, Clapperboard, Database, Workflow, 
  Settings, Bell, AlertCircle, ShieldAlert, Cpu, CheckCircle2, Globe,
  Mic, MicOff, Volume2, History, Play, Scissors, Check, Download, RotateCcw, Keyboard, X,
  Sliders, Undo, Redo, Lock, Unlock, Info, Network, Save, Trash2,
  Folder, FolderPlus, ChevronDown, ChevronRight, Plus, GripVertical, Search, BarChart3
} from "lucide-react";

import { DashboardOverview } from "./components/DashboardOverview";
import { JourneyBuilder } from "./components/JourneyBuilder";
import { ContentGenerator } from "./components/ContentGenerator";
import { VideoStudio } from "./components/VideoStudio";
import { RagHub } from "./components/RagHub";
import { AutomationLogs } from "./components/AutomationLogs";
import { LangGraphAgent } from "./components/LangGraphAgent";
import { SettingsPanel } from "./components/SettingsPanel";
import { Analytics } from "./components/Analytics";
import { ModerationPanel } from "./components/ModerationPanel";

import { PipelineLog, DraftSocialPost } from "./types";
import { INITIAL_LOGS, FCB_BRAND_RULES } from "./data/mockData";
import { useLanguage } from "./context/LanguageContext";
import { translations, Language } from "./data/i18n";

const AUTOMATION_PRESETS = [
  {
    id: "interview",
    name: "Interview",
    nameDe: "Interview",
    category: "Podcast",
    icon: "🎙️",
    description: "Gentle leveling & speech warmth. Perfect for podcasts & dialogues.",
    descriptionDe: "Sanfte Pegelanpassung & Sprachwärme. Perfekt für Podcasts & Dialoge.",
    activeBg: "bg-cyan-500/15 border-cyan-400 text-cyan-300 font-bold",
    settings: {
      fadeInDuration: 0.5,
      fadeOutDuration: 0.8,
      noiseGateThreshold: 12,
      isNormalized: true,
      compressorEnabled: true,
      compMidThreshold: -20,
      compMidRatio: 3.0,
      compMidMakeup: 4,
      compLowThreshold: -24,
      compLowRatio: 2.5,
      compLowMakeup: 2,
      compHighThreshold: -22,
      compHighRatio: 2.5,
      compHighMakeup: 1,
    }
  },
  {
    id: "dialogue",
    name: "Co-Host",
    nameDe: "Co-Moderator",
    category: "Podcast",
    icon: "👥",
    description: "Balanced dialogue levels & background noise suppression.",
    descriptionDe: "Ausgeglichene Dialog-Pegel & Hintergrundgeräusch-Unterdrückung.",
    activeBg: "bg-cyan-500/15 border-cyan-400 text-cyan-300 font-bold",
    settings: {
      fadeInDuration: 0.4,
      fadeOutDuration: 0.6,
      noiseGateThreshold: 15,
      isNormalized: true,
      compressorEnabled: true,
      compMidThreshold: -18,
      compMidRatio: 2.8,
      compMidMakeup: 3,
      compLowThreshold: -22,
      compLowRatio: 2.2,
      compLowMakeup: 1,
      compHighThreshold: -20,
      compHighRatio: 2.2,
      compHighMakeup: 1,
    }
  },
  {
    id: "hype",
    name: "Hype Intro",
    nameDe: "Hype-Intro",
    category: "Short-form Social",
    icon: "🔥",
    description: "Punchy, heavy compression with a dramatic fade tail for intense introductions.",
    descriptionDe: "Druckvolle, starke Kompression mit dramatischem Fade-Auslauf für intensive Intros.",
    activeBg: "bg-violet-500/15 border-violet-400 text-violet-300 font-bold",
    settings: {
      fadeInDuration: 0.2,
      fadeOutDuration: 1.5,
      noiseGateThreshold: 8,
      isNormalized: true,
      compressorEnabled: true,
      compMidThreshold: -12,
      compMidRatio: 6.0,
      compMidMakeup: 6,
      compLowThreshold: -18,
      compLowRatio: 4.0,
      compLowMakeup: 3,
      compHighThreshold: -15,
      compHighRatio: 4.0,
      compHighMakeup: 3,
    }
  },
  {
    id: "tiktok",
    name: "TikTok V.O.",
    nameDe: "TikTok V.O.",
    category: "Short-form Social",
    icon: "🎵",
    description: "Crisp highs and high presence tailored for mobile devices.",
    descriptionDe: "Klarer Hochtonbereich und hohe Präsenz optimiert für Mobilgeräte.",
    activeBg: "bg-violet-500/15 border-violet-400 text-violet-300 font-bold",
    settings: {
      fadeInDuration: 0.2,
      fadeOutDuration: 0.4,
      noiseGateThreshold: 10,
      isNormalized: true,
      compressorEnabled: true,
      compMidThreshold: -14,
      compMidRatio: 4.5,
      compMidMakeup: 5,
      compLowThreshold: -16,
      compLowRatio: 3.5,
      compLowMakeup: 2,
      compHighThreshold: -12,
      compHighRatio: 4.5,
      compHighMakeup: 4,
    }
  },
  {
    id: "command",
    name: "Voice Command",
    nameDe: "Sprachbefehl",
    category: "System Voice",
    icon: "⚡",
    description: "Ultra-fast curves & heavy noise gating to isolate crisp vocal instructions.",
    descriptionDe: "Ultraschnelle Kurven & starkes Noise Gate zur Isolierung klarer Sprachbefehle.",
    activeBg: "bg-amber-500/15 border-amber-400 text-amber-300 font-bold",
    settings: {
      fadeInDuration: 0.1,
      fadeOutDuration: 0.1,
      noiseGateThreshold: 24,
      isNormalized: true,
      compressorEnabled: true,
      compMidThreshold: -16,
      compMidRatio: 4.0,
      compMidMakeup: 2,
      compLowThreshold: -15,
      compLowRatio: 5.0,
      compLowMakeup: 0,
      compHighThreshold: -18,
      compHighRatio: 3.5,
      compHighMakeup: 1,
    }
  },
  {
    id: "tts",
    name: "TTS Reader",
    nameDe: "TTS-Reader",
    category: "System Voice",
    icon: "🤖",
    description: "Flat, highly transparent leveling for artificial speech readers.",
    descriptionDe: "Flache, hochtransparente Pegelanpassung für künstliche Sprachleser.",
    activeBg: "bg-amber-500/15 border-amber-400 text-amber-300 font-bold",
    settings: {
      fadeInDuration: 0.1,
      fadeOutDuration: 0.2,
      noiseGateThreshold: 6,
      isNormalized: true,
      compressorEnabled: true,
      compMidThreshold: -22,
      compMidRatio: 2.0,
      compMidMakeup: 1,
      compLowThreshold: -26,
      compLowRatio: 1.8,
      compLowMakeup: 0,
      compHighThreshold: -24,
      compHighRatio: 1.8,
      compHighMakeup: 0,
    }
  }
];

interface TreeNode {
  name: string;
  fullPath: string;
  subfolders: Record<string, TreeNode>;
  presets: any[];
}

const buildPresetTree = (presetsToBuild: any[], customPaths: string[]): TreeNode => {
  const root: TreeNode = {
    name: "Root",
    fullPath: "",
    subfolders: {},
    presets: []
  };

  // Add custom empty categories first so they exist in the tree structure
  customPaths.forEach(path => {
    const parts = path.split("/").map(p => p.trim()).filter(Boolean);
    let current = root;
    let currentPath = "";
    parts.forEach((part) => {
      currentPath = currentPath ? `${currentPath}/${part}` : part;
      if (!current.subfolders[part]) {
        current.subfolders[part] = {
          name: part,
          fullPath: currentPath,
          subfolders: {},
          presets: []
        };
      }
      current = current.subfolders[part];
    });
  });

  // Add presets
  presetsToBuild.forEach(preset => {
    const category = preset.category || "General";
    const parts = category.split("/").map(p => p.trim()).filter(Boolean);
    
    let current = root;
    let currentPath = "";
    
    parts.forEach((part) => {
      currentPath = currentPath ? `${currentPath}/${part}` : part;
      if (!current.subfolders[part]) {
        current.subfolders[part] = {
          name: part,
          fullPath: currentPath,
          subfolders: {},
          presets: []
        };
      }
      current = current.subfolders[part];
    });
    
    if (!current.presets.some(p => p.id === preset.id)) {
      current.presets.push(preset);
    }
  });

  return root;
};

const findSubNode = (root: TreeNode, targetPath: string): TreeNode | null => {
  if (targetPath === "All") return root;
  const parts = targetPath.split("/").map(p => p.trim()).filter(Boolean);
  let current = root;
  for (const part of parts) {
    if (current.subfolders[part]) {
      current = current.subfolders[part];
    } else {
      return null;
    }
  }
  return current;
};

export default function App() {
  const { language, setLanguage, t } = useLanguage();
  const [activeTab, setActiveTab] = useState<string>("dashboard");
  const [logs, setLogs] = useState<PipelineLog[]>(INITIAL_LOGS);

  // Shared Campaign Drafts State
  const [drafts, setDrafts] = useState<DraftSocialPost[]>(() => {
    try {
      const saved = localStorage.getItem("fcb_miasanai_drafts");
      return saved ? JSON.parse(saved) : [
        {
          id: "draft-1",
          headline: "MIA SAN HALBFINALE! 🔥",
          caption: "Unglaubliche Nacht in der Allianz Arena! Die Südkurve hat getobt. Thomas Müller zeigt einmal mehr, was echter FC Bayern Kampfgeist bedeutet. Auf geht's ins Halbfinale! #MiaSanMia",
          hashtags: ["#FCBayern", "#MiaSanMia", "#AllianzArena", "#UCL"],
          platform: "Instagram",
          playerName: "Thomas Müller",
          status: "pending",
          createdAt: "10 minutes ago"
        },
        {
          id: "draft-2",
          headline: "CLINICAL KANE STRIKES AGAIN ⚽",
          caption: "Another unforgettable Champions League evening under the Allianz Arena lights! Focused, determined, and straight into the next round. Thanks for the spectacular support, Bayern fans!",
          hashtags: ["#HarryKane", "#FCBayern", "#MiaSanMia", "#UCL"],
          platform: "X/Twitter",
          playerName: "Harry Kane",
          status: "pending",
          createdAt: "25 minutes ago"
        },
        {
          id: "draft-3",
          headline: "BAMBI ON FIRE ⚡",
          caption: "Pure magic on the pitch from Jamal Musiala tonight. Absolute class, skill, and heart. Watch his highlight dribble in the FC Bayern app now!",
          hashtags: ["#Musiala", "#FCBayern", "#ChampionsLeague"],
          platform: "TikTok",
          playerName: "Jamal Musiala",
          status: "approved",
          createdAt: "1 hour ago"
        }
      ];
    } catch {
      return [];
    }
  });

  // Sync drafts to localStorage
  React.useEffect(() => {
    try {
      localStorage.setItem("fcb_miasanai_drafts", JSON.stringify(drafts));
    } catch (e) {
      console.error("Failed to save drafts to localStorage", e);
    }
  }, [drafts]);

  const [selectedPresetCategory, setSelectedPresetCategory] = useState<string>("All");

  // Export Presets State
  const [exportPresetCategoryFilter, setExportPresetCategoryFilter] = useState<string>("All");
  const [exportPresetSearchQuery, setExportPresetSearchQuery] = useState<string>("");
  
  // Hierarchical category states
  const [customCategoryPaths, setCustomCategoryPaths] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem("fcb_miasanai_custom_categories");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [expandedFolders, setExpandedFolders] = useState<Record<string, boolean>>({
    "Technical": true,
    "Creative": true
  });
  const [inTreeCategoryCreatePath, setInTreeCategoryCreatePath] = useState<string | null>(null);
  const [inTreeCategoryInputValue, setInTreeCategoryInputValue] = useState<string>("");
  const [presetSaveParentCategory, setPresetSaveParentCategory] = useState<string>("Technical");
  const [presetSaveNewSubcategory, setPresetSaveNewSubcategory] = useState<string>("");
  const [draggedPresetId, setDraggedPresetId] = useState<string | null>(null);
  const [dragOverPresetId, setDragOverPresetId] = useState<string | null>(null);
  const [exportPresets, setExportPresets] = useState<any[]>(() => {
    const defaultPresets = [
      {
        id: "preset-broadcast",
        name: "Broadcast Master",
        nameDe: "Broadcast-Master",
        category: "Technical",
        compressorEnabled: true,
        isNormalized: true,
        fadeInDuration: 0.5,
        fadeOutDuration: 0.8,
        noiseGateThreshold: 12,
        compLowThreshold: -24,
        compLowRatio: 2.5,
        compLowMakeup: 2,
        compMidThreshold: -16,
        compMidRatio: 4.0,
        compMidMakeup: 3,
        compHighThreshold: -20,
        compHighRatio: 3.0,
        compHighMakeup: 1,
      },
      {
        id: "preset-social-hype",
        name: "Social Hype",
        nameDe: "Social-Hype",
        category: "Creative",
        compressorEnabled: true,
        isNormalized: true,
        fadeInDuration: 0.2,
        fadeOutDuration: 1.5,
        noiseGateThreshold: 8,
        compLowThreshold: -18,
        compLowRatio: 4.0,
        compLowMakeup: 4,
        compMidThreshold: -12,
        compMidRatio: 6.0,
        compMidMakeup: 6,
        compHighThreshold: -16,
        compHighRatio: 5.0,
        compHighMakeup: 3,
      },
      {
        id: "preset-ambient-soft",
        name: "Ambient Soft",
        nameDe: "Ambient-Sanft",
        category: "Creative",
        compressorEnabled: false,
        isNormalized: false,
        fadeInDuration: 1.5,
        fadeOutDuration: 2.0,
        noiseGateThreshold: 5,
        compLowThreshold: -30,
        compLowRatio: 2.0,
        compLowMakeup: 0,
        compMidThreshold: -24,
        compMidRatio: 2.0,
        compMidMakeup: 0,
        compHighThreshold: -28,
        compHighRatio: 1.8,
        compHighMakeup: 0,
      }
    ];
    try {
      const saved = localStorage.getItem("fcb_miasanai_export_presets");
      if (saved) {
        // Handle migration to ensure category is populated
        const loaded = JSON.parse(saved);
        return loaded.map((p: any) => ({
          ...p,
          category: p.category || "Technical"
        }));
      }
    } catch (e) {
      console.error(e);
    }
    return defaultPresets;
  });

  const [newPresetName, setNewPresetName] = useState<string>("");

  const [theme, setTheme] = useState<"dark" | "classic">(() => {
    try {
      const saved = localStorage.getItem("fcb_miasanai_theme");
      if (saved === "classic" || saved === "dark") return saved;
    } catch (e) {
      console.error(e);
    }
    return "dark";
  });

  const [speechEnabled, setSpeechEnabled] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem("fcb_miasanai_speech_enabled");
      if (saved !== null) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return true;
  });

  // Toggle body class and persist theme
  React.useEffect(() => {
    try {
      localStorage.setItem("fcb_miasanai_theme", theme);
    } catch (e) {
      console.error(e);
    }
    if (theme === "classic") {
      document.body.classList.add("theme-classic");
    } else {
      document.body.classList.remove("theme-classic");
    }
  }, [theme]);

  // Persist speech status
  React.useEffect(() => {
    try {
      localStorage.setItem("fcb_miasanai_speech_enabled", JSON.stringify(speechEnabled));
    } catch (e) {
      console.error(e);
    }
  }, [speechEnabled]);

  const [notification, setNotification] = useState<string | null>(null);

  // Synchronize language selection with online notification
  React.useEffect(() => {
    setNotification(t("notificationOnline"));
  }, [language]);

  // Active simulated workflow triggers
  const [activeSimulation, setActiveSimulation] = useState<{
    stageId: string;
    triggerName: string;
    actionName: string;
  } | null>(null);

  const handleAddLog = (newLog: PipelineLog) => {
    setLogs(prev => [...prev, newLog]);
    if (newLog.level === "SUCCESS") {
      setNotification(`✅ ${t("automationSuccess")}${newLog.message}`);
    } else if (newLog.level === "TRIGGER") {
      setNotification(`⚡ ${t("workflowTriggered")}${newLog.message}`);
    }
  };

  const handleSimulateTrigger = (stageId: string, triggerName: string, actionName: string) => {
    setActiveSimulation({ stageId, triggerName, actionName });
    setActiveTab("journey");
    setNotification(`⚡ ${t("simulatedTrigger")}`);
  };

  // Voice Command Assistant states
  const [isListening, setIsListening] = useState<boolean>(false);
  const [speechSupported, setSpeechSupported] = useState<boolean>(false);
  const [speechError, setSpeechError] = useState<string | null>(null);
  const [transcript, setTranscript] = useState<string>("");
  const [showAssistantPanel, setShowAssistantPanel] = useState<boolean>(false);
  const [voiceLog, setVoiceLog] = useState<string | null>(null);
  const [showShortcutsModal, setShowShortcutsModal] = useState<boolean>(false);
  const [showExportSummaryModal, setShowExportSummaryModal] = useState<boolean>(false);
  const [hoveredWaveformBarIdx, setHoveredWaveformBarIdx] = useState<number | null>(null);

  // Audio trimming & visualization states
  const [audioDuration, setAudioDuration] = useState<number>(0);
  const [trimStart, setTrimStart] = useState<number>(0);
  const [trimEnd, setTrimEnd] = useState<number>(0);
  const [isPlayingAudio, setIsPlayingAudio] = useState<boolean>(false);
  const [playheadProgress, setPlayheadProgress] = useState<number>(0);
  const [croppedSuccessfully, setCroppedSuccessfully] = useState<boolean>(false);
  const [fadeInDuration, setFadeInDuration] = useState<number>(1.0);
  const [fadeOutDuration, setFadeOutDuration] = useState<number>(1.0);
  const [silenceThreshold, setSilenceThreshold] = useState<number>(25);
  const [noiseGateThreshold, setNoiseGateThreshold] = useState<number>(15);
  const [isNormalized, setIsNormalized] = useState<boolean>(false);
  const [isTrimLocked, setIsTrimLocked] = useState<boolean>(false);

  // Trimmer History Undo / Redo states
  interface TrimmerHistoryState {
    trimStart: number;
    trimEnd: number;
    fadeInDuration: number;
    fadeOutDuration: number;
  }
  const [trimmerHistory, setTrimmerHistory] = useState<TrimmerHistoryState[]>([]);
  const [historyIndex, setHistoryIndex] = useState<number>(-1);
  const isRollingBackRef = React.useRef<boolean>(false);

  const handleUndo = React.useCallback(() => {
    if (historyIndex > 0) {
      const prevIdx = historyIndex - 1;
      const targetState = trimmerHistory[prevIdx];
      if (targetState) {
        isRollingBackRef.current = true;
        setTrimStart(targetState.trimStart);
        setTrimEnd(targetState.trimEnd);
        setFadeInDuration(targetState.fadeInDuration);
        setFadeOutDuration(targetState.fadeOutDuration);
        setHistoryIndex(prevIdx);
        setPlayheadProgress(targetState.trimStart);
        
        handleAddLog({
          id: `undo-${Date.now()}`,
          timestamp: new Date().toLocaleTimeString(),
          level: "INFO",
          source: "Audio Trimmer",
          message: `Undo action applied. Reverted to trim range [${targetState.trimStart.toFixed(1)}s - ${targetState.trimEnd.toFixed(1)}s] and fade [In: ${targetState.fadeInDuration.toFixed(1)}s, Out: ${targetState.fadeOutDuration.toFixed(1)}s].`
        });
      }
    }
  }, [historyIndex, trimmerHistory]);

  const handleRedo = React.useCallback(() => {
    if (historyIndex < trimmerHistory.length - 1) {
      const nextIdx = historyIndex + 1;
      const targetState = trimmerHistory[nextIdx];
      if (targetState) {
        isRollingBackRef.current = true;
        setTrimStart(targetState.trimStart);
        setTrimEnd(targetState.trimEnd);
        setFadeInDuration(targetState.fadeInDuration);
        setFadeOutDuration(targetState.fadeOutDuration);
        setHistoryIndex(nextIdx);
        setPlayheadProgress(targetState.trimStart);
        
        handleAddLog({
          id: `redo-${Date.now()}`,
          timestamp: new Date().toLocaleTimeString(),
          level: "INFO",
          source: "Audio Trimmer",
          message: `Redo action applied. Re-applied trim range [${targetState.trimStart.toFixed(1)}s - ${targetState.trimEnd.toFixed(1)}s] and fade [In: ${targetState.fadeInDuration.toFixed(1)}s, Out: ${targetState.fadeOutDuration.toFixed(1)}s].`
        });
      }
    }
  }, [historyIndex, trimmerHistory]);

  // Sync / Record state changes with debounce
  React.useEffect(() => {
    if (audioDuration <= 0) return;

    if (isRollingBackRef.current) {
      isRollingBackRef.current = false;
      return;
    }

    const timer = setTimeout(() => {
      const current = { trimStart, trimEnd, fadeInDuration, fadeOutDuration };
      
      setTrimmerHistory(prev => {
        if (prev.length === 0) {
          setHistoryIndex(0);
          return [current];
        }
        
        const activeState = prev[historyIndex];
        if (
          activeState &&
          activeState.trimStart === current.trimStart &&
          activeState.trimEnd === current.trimEnd &&
          activeState.fadeInDuration === current.fadeInDuration &&
          activeState.fadeOutDuration === current.fadeOutDuration
        ) {
          return prev;
        }
        
        const newHistory = prev.slice(0, historyIndex + 1);
        newHistory.push(current);
        setHistoryIndex(newHistory.length - 1);
        return newHistory;
      });
    }, 400);

    return () => clearTimeout(timer);
  }, [trimStart, trimEnd, fadeInDuration, fadeOutDuration, audioDuration, historyIndex]);

  // Multi-band Dynamic Range Compressor States
  const [compressorEnabled, setCompressorEnabled] = useState<boolean>(true);
  const [compressorActiveBand, setCompressorActiveBand] = useState<"low" | "mid" | "high">("mid");

  // Audio Trimmer Draggable Handles logic
  const visualizerRef = React.useRef<HTMLDivElement>(null);
  const isDraggingStartRef = React.useRef<boolean>(false);
  const isDraggingEndRef = React.useRef<boolean>(false);

  const [activeDragHandle, setActiveDragHandle] = useState<"start" | "end" | null>(null);
  const [hoveredTime, setHoveredTime] = useState<number | null>(null);
  const [isHoveringWaveform, setIsHoveringWaveform] = useState<boolean>(false);

  interface CapturedFrame {
    timecode: string;
    frameNo: number;
    title: string;
    subtitle: string;
    imageUrl: string;
    iconType: string;
    description: string;
    cameraInfo: string;
  }

  const getCapturedFrame = (time: number, duration: number): CapturedFrame => {
    const d = duration || 30;
    const ratio = Math.max(0, Math.min(1, time / d));
    const progressSec = Math.max(0, Math.min(time, d));
    const mins = Math.floor(progressSec / 60);
    const secs = Math.floor(progressSec % 60);
    const ms = Math.floor((progressSec % 1) * 10);
    const timecode = `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}.${ms}`;
    const frameNo = Math.floor(progressSec * 25); // 25 fps
    
    if (ratio < 0.15) {
      return {
        timecode,
        frameNo,
        title: language === "de" ? "Südkurve Allianz Arena" : "Südkurve Allianz Arena",
        subtitle: language === "de" ? "Vorrunden-Fan-Choreo" : "Pre-Match Fan Choreo",
        imageUrl: "https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=300&auto=format&fit=crop&q=80",
        iconType: "cheer",
        description: language === "de" ? "Fans schwenken tiefrote Fahnen und riesige Choreo-Tafeln in der Südkurve." : "Fans waving crimson red flags & giant choreography panels in the south stand.",
        cameraInfo: "CAM A - RED MONSTRO 8K"
      };
    } else if (ratio < 0.35) {
      return {
        timecode,
        frameNo,
        title: "Thomas Müller Close-up",
        subtitle: language === "de" ? "Live-Interview-Sitzung" : "Live Interview Session",
        imageUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&auto=format&fit=crop&q=80",
        iconType: "interview",
        description: language === "de" ? "Müller spricht über das taktische Setup und die 'Mia San Mia'-Siegermentalität." : "Müller discussing tactical setup and the 'Mia San Mia' winning mentality.",
        cameraInfo: "CAM B - ARRI ALEXA LF"
      };
    } else if (ratio < 0.55) {
      return {
        timecode,
        frameNo,
        title: "Harry Kane Training",
        subtitle: language === "de" ? "Taktische Schussübung" : "Tactical Shooting Drill",
        imageUrl: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=300&auto=format&fit=crop&q=80",
        iconType: "action",
        description: language === "de" ? "Kane schießt einen platzierten Flachschuss an den Trainingshütchen an der Säbener Straße vorbei." : "Kane strikes a clinical low drive past the training cones at Säbener Straße.",
        cameraInfo: "CAM C - PHANTOM FLEX 4K"
      };
    } else if (ratio < 0.75) {
      return {
        timecode,
        frameNo,
        title: "Jamal Musiala Skill-Cam",
        subtitle: language === "de" ? "Hochgeschwindigkeits-Slalomdribbling" : "High-Speed Slalom Dribble",
        imageUrl: "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=300&auto=format&fit=crop&q=80",
        iconType: "hype",
        description: language === "de" ? "Musiala zeigt rasante Geschwindigkeit und schnelle Beinarbeit um die Slalomstangen." : "Musiala showing blistering speed and quick feet around slalom cones.",
        cameraInfo: "CAM D - GOPRO HERO 12 PRO"
      };
    } else if (ratio < 0.90) {
      return {
        timecode,
        frameNo,
        title: language === "de" ? "Taktische Entwurfsansicht" : "Tactical Blueprint Screen",
        subtitle: language === "de" ? "Virtuelles interaktives Board" : "Virtual Interactive Board",
        imageUrl: "https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=300&auto=format&fit=crop&q=80",
        iconType: "tactics",
        description: language === "de" ? "Visuelle Analyse von Abwehrlinien und schnellen Umschalt-Passwegen." : "Visual analysis of defensive lines and quick transition passing lanes.",
        cameraInfo: "DIGITAL OVERLAY RENDER"
      };
    } else {
      return {
        timecode,
        frameNo,
        title: "Mia San Mia Trophy Lift",
        subtitle: language === "de" ? "Meisterschafts-Outro-Feier" : "Victory Celebration Outro",
        imageUrl: "https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?w=300&auto=format&fit=crop&q=80",
        iconType: "hype",
        description: language === "de" ? "Goldener Konfettiregen geht auf die Mannschaft nieder, während die Stadionlichter blitzen." : "Gold confetti raining down on the squad as the stadium lights flash.",
        cameraInfo: "CAM E - RONIN DJI PRO"
      };
    }
  };

  const trimStartRef = React.useRef<number>(trimStart);
  const trimEndRef = React.useRef<number>(trimEnd);
  const audioDurationRef = React.useRef<number>(audioDuration);

  React.useEffect(() => {
    trimStartRef.current = trimStart;
  }, [trimStart]);

  React.useEffect(() => {
    trimEndRef.current = trimEnd;
  }, [trimEnd]);

  React.useEffect(() => {
    audioDurationRef.current = audioDuration;
  }, [audioDuration]);

  const handleStartDrag = (e: React.MouseEvent | React.TouchEvent) => {
    if (isTrimLocked) return;
    e.preventDefault();
    isDraggingStartRef.current = true;
    setActiveDragHandle("start");
    
    const handleMove = (moveEvent: MouseEvent | TouchEvent) => {
      if (!isDraggingStartRef.current || !visualizerRef.current) return;
      const rect = visualizerRef.current.getBoundingClientRect();
      const clientX = 'touches' in moveEvent ? moveEvent.touches[0].clientX : moveEvent.clientX;
      const relativeX = clientX - rect.left;
      const pct = Math.max(0, Math.min(1, relativeX / rect.width));
      let newTime = pct * audioDurationRef.current;
      
      // Enforce boundaries (at least 0.5s from end, and >= 0)
      newTime = Math.max(0, Math.min(newTime, trimEndRef.current - 0.5));
      newTime = parseFloat(newTime.toFixed(1));
      
      setTrimStart(newTime);
      setCroppedSuccessfully(false);
    };

    const handleEnd = () => {
      isDraggingStartRef.current = false;
      setActiveDragHandle(null);
      window.removeEventListener("mousemove", handleMove);
      window.removeEventListener("mouseup", handleEnd);
      window.removeEventListener("touchmove", handleMove);
      window.removeEventListener("touchend", handleEnd);
    };

    window.addEventListener("mousemove", handleMove);
    window.addEventListener("mouseup", handleEnd);
    window.addEventListener("touchmove", handleMove, { passive: false });
    window.addEventListener("touchend", handleEnd);
  };

  const handleEndDrag = (e: React.MouseEvent | React.TouchEvent) => {
    if (isTrimLocked) return;
    e.preventDefault();
    isDraggingEndRef.current = true;
    setActiveDragHandle("end");

    const handleMove = (moveEvent: MouseEvent | TouchEvent) => {
      if (!isDraggingEndRef.current || !visualizerRef.current) return;
      const rect = visualizerRef.current.getBoundingClientRect();
      const clientX = 'touches' in moveEvent ? moveEvent.touches[0].clientX : moveEvent.clientX;
      const relativeX = clientX - rect.left;
      const pct = Math.max(0, Math.min(1, relativeX / rect.width));
      let newTime = pct * audioDurationRef.current;
      
      // Enforce boundaries (at least 0.5s from start, and <= audioDuration)
      newTime = Math.max(trimStartRef.current + 0.5, Math.min(newTime, audioDurationRef.current));
      newTime = parseFloat(newTime.toFixed(1));
      
      setTrimEnd(newTime);
      setCroppedSuccessfully(false);
    };

    const handleEnd = () => {
      isDraggingEndRef.current = false;
      setActiveDragHandle(null);
      window.removeEventListener("mousemove", handleMove);
      window.removeEventListener("mouseup", handleEnd);
      window.removeEventListener("touchmove", handleMove);
      window.removeEventListener("touchend", handleEnd);
    };

    window.addEventListener("mousemove", handleMove);
    window.addEventListener("mouseup", handleEnd);
    window.addEventListener("touchmove", handleMove, { passive: false });
    window.addEventListener("touchend", handleEnd);
  };

  const handleWaveformMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!visualizerRef.current) return;
    const rect = visualizerRef.current.getBoundingClientRect();
    const relativeX = e.clientX - rect.left;
    const pct = Math.max(0, Math.min(1, relativeX / rect.width));
    const time = pct * audioDuration;
    setHoveredTime(parseFloat(time.toFixed(1)));
  };

  const handleWaveformMouseLeave = () => {
    setIsHoveringWaveform(false);
    setHoveredTime(null);
  };

  const handleWaveformMouseEnter = () => {
    setIsHoveringWaveform(true);
  };

  // Low band settings (Bass / Plosives filter)
  const [compLowThreshold, setCompLowThreshold] = useState<number>(-24);
  const [compLowRatio, setCompLowRatio] = useState<number>(2.5);
  const [compLowAttack, setCompLowAttack] = useState<number>(30);
  const [compLowRelease, setCompLowRelease] = useState<number>(150);
  const [compLowMakeup, setCompLowMakeup] = useState<number>(2);

  // Mid band settings (Speech Body / Presence)
  const [compMidThreshold, setCompMidThreshold] = useState<number>(-16);
  const [compMidRatio, setCompMidRatio] = useState<number>(4.0);
  const [compMidAttack, setCompMidAttack] = useState<number>(15);
  const [compMidRelease, setCompMidRelease] = useState<number>(100);
  const [compMidMakeup, setCompMidMakeup] = useState<number>(3);

  // High band settings (Sibilance / Air)
  const [compHighThreshold, setCompHighThreshold] = useState<number>(-20);
  const [compHighRatio, setCompHighRatio] = useState<number>(3.0);
  const [compHighAttack, setCompHighAttack] = useState<number>(8);
  const [compHighRelease, setCompHighRelease] = useState<number>(80);
  const [compHighMakeup, setCompHighMakeup] = useState<number>(1);

  // Helper to determine mini visual waveform sparkline heights
  const getWaveformBars = (preset: any) => {
    const fIn = preset.fadeInDuration ?? 0.5;
    const fOut = preset.fadeOutDuration ?? 0.8;
    const gate = preset.noiseGateThreshold ?? 10;
    const comp = preset.compressorEnabled ?? false;
    
    const lowThresh = preset.compLowThreshold ?? -24;
    const lowMakeup = preset.compLowMakeup ?? 0;
    
    const midThresh = preset.compMidThreshold ?? -16;
    const midMakeup = preset.compMidMakeup ?? 0;
    
    const highThresh = preset.compHighThreshold ?? -20;
    const highMakeup = preset.compHighMakeup ?? 0;

    const h1 = Math.max(15, Math.min(85, 80 - (fIn * 25) - (gate * 1.2)));
    const h2 = Math.max(25, Math.min(95, 55 + (lowMakeup * 5) - (comp ? Math.abs(lowThresh) * 0.7 : 0)));
    const h3 = Math.max(35, Math.min(100, 70 + (midMakeup * 5) - (comp ? Math.abs(midThresh) * 0.8 : 0)));
    const h4 = Math.max(25, Math.min(95, 60 + (highMakeup * 5) - (comp ? Math.abs(highThresh) * 0.7 : 0)));
    const h5 = Math.max(15, Math.min(85, 80 - (fOut * 15)));

    return [h1, h2, h3, h4, h5];
  };

  // Helper to determine detailed mini visual waveform sparkline heights & compression threshold line
  const getPresetSparklineData = (preset: any) => {
    const fadeIn = preset.fadeInDuration ?? 0.5;
    const fadeOut = preset.fadeOutDuration ?? 0.8;
    const isComp = preset.compressorEnabled ?? false;
    const isNorm = preset.isNormalized ?? false;

    // A beautiful baseline audio wave peak envelope (16 points of diverse levels)
    const RAW_WAVE = [35, 75, 48, 85, 42, 92, 58, 38, 96, 52, 78, 54, 88, 34, 72, 38];
    const barsCount = RAW_WAVE.length;

    // Map compMidThreshold (-36 to 0 dB) to peak scale (20 to 85)
    // -36 dB -> 25 peak threshold
    // 0 dB -> 85 peak threshold
    const midThresh = preset.compMidThreshold ?? -16;
    const thresholdPeak = Math.max(20, Math.min(85, 85 + (midThresh * 1.67)));
    const ratio = preset.compMidRatio ?? 3.0;
    const makeup = preset.compMidMakeup ?? 0;

    const bars = RAW_WAVE.map((rawPeak, idx) => {
      let p = rawPeak;

      // 1. Normalization adjustment to standard base level
      if (isNorm) {
        p = p * 1.15; // boost slightly for normalized signals
      }

      // 2. Apply Compression
      if (isComp) {
        if (p > thresholdPeak) {
          const excess = p - thresholdPeak;
          const compressedExcess = excess / ratio;
          p = thresholdPeak + compressedExcess;
        }
        // Apply makeup gain (each dB adds ~3.5% amplitude)
        p = p + (makeup * 3.5);
      }

      // Clamp peak before fade
      p = Math.max(8, Math.min(98, p));

      // 3. Apply Fade-In (first 40% of the timeline)
      // Representing 16 bars as a 5-second window
      // Let's assume index 0 to 15 is t = 0 to 5 seconds (each index is 0.3125s)
      const t = idx * 0.3125;
      let fadeInFactor = 1.0;
      if (fadeIn > 0) {
        if (t < fadeIn) {
          fadeInFactor = t / fadeIn;
          // Smooth sine curve fade-in
          fadeInFactor = Math.sin(fadeInFactor * Math.PI / 2);
        }
      }

      // 4. Apply Fade-Out (last 40% of the timeline)
      const tFromEnd = (barsCount - 1 - idx) * 0.3125;
      let fadeOutFactor = 1.0;
      if (fadeOut > 0) {
        if (tFromEnd < fadeOut) {
          fadeOutFactor = tFromEnd / fadeOut;
          // Smooth sine curve fade-out
          fadeOutFactor = Math.sin(fadeOutFactor * Math.PI / 2);
        }
      }

      return Math.max(3, Math.round(p * fadeInFactor * fadeOutFactor));
    });

    // Map thresholdPeak to Y-coordinate on a 28px tall canvas
    // 0 peak is Y=26, 100 peak is Y=2.
    const thresholdY = isComp ? Math.round(26 - (thresholdPeak / 100) * 24) : null;

    return {
      bars,
      thresholdY,
      hasCompression: isComp,
      fadeIn,
      fadeOut
    };
  };

  // Helper to save current preset configurations with hierarchical categories
  const handleSaveExportPreset = () => {
    const cleanName = newPresetName.trim();
    const presetId = `preset-custom-${Date.now()}`;
    const customCount = exportPresets.filter(p => p.id.startsWith("preset-custom-")).length + 1;
    const defaultName = `Custom Preset ${customCount}`;
    const defaultNameDe = `Eigenes Preset ${customCount}`;
    
    let resolvedCategory = presetSaveParentCategory;
    const subName = presetSaveNewSubcategory.trim();
    if (subName) {
      resolvedCategory = resolvedCategory ? `${resolvedCategory}/${subName}` : subName;
      // Register this new category folder
      if (!customCategoryPaths.includes(resolvedCategory)) {
        const updatedPaths = [...customCategoryPaths, resolvedCategory];
        setCustomCategoryPaths(updatedPaths);
        try {
          localStorage.setItem("fcb_miasanai_custom_categories", JSON.stringify(updatedPaths));
        } catch (e) {
          console.error(e);
        }
      }
    }

    if (!resolvedCategory) {
      resolvedCategory = "General";
    }

    const newPreset = {
      id: presetId,
      name: cleanName || defaultName,
      nameDe: cleanName || defaultNameDe,
      category: resolvedCategory,
      compressorEnabled,
      isNormalized,
      fadeInDuration,
      fadeOutDuration,
      noiseGateThreshold,
      compLowThreshold,
      compLowRatio,
      compLowMakeup,
      compMidThreshold,
      compMidRatio,
      compMidMakeup,
      compHighThreshold,
      compHighRatio,
      compHighMakeup
    };
    
    const updated = [...exportPresets, newPreset];
    setExportPresets(updated);
    try {
      localStorage.setItem("fcb_miasanai_export_presets", JSON.stringify(updated));
    } catch (err) {
      console.error(err);
    }
    setNewPresetName("");
    setPresetSaveNewSubcategory("");
    
    // Automatically make sure the category is expanded in the folder tree
    setExpandedFolders(prev => ({
      ...prev,
      [resolvedCategory]: true
    }));

    const lastPart = resolvedCategory.split("/").pop() || resolvedCategory;
    const translatedCategory = language === "de"
      ? (lastPart === "Technical" ? "Technisch" : lastPart === "Creative" ? "Kreativ" : lastPart)
      : lastPart;

    handleAddLog({
      id: `export-preset-save-${Date.now()}`,
      timestamp: new Date().toLocaleTimeString(),
      source: "Preset Manager",
      level: "SUCCESS",
      message: language === "de"
        ? `Export-Preset '${newPreset.nameDe}' (${translatedCategory}) erfolgreich gespeichert.`
        : `Export preset '${newPreset.name}' (${translatedCategory}) saved successfully.`
    });
  };

  // Helper to create a category from the folder tree interface directly
  const handleCreateInTreeCategory = (parentPath: string) => {
    const name = inTreeCategoryInputValue.trim();
    if (!name) {
      setInTreeCategoryCreatePath(null);
      return;
    }
    const newPath = parentPath ? `${parentPath}/${name}` : name;
    
    if (!customCategoryPaths.includes(newPath)) {
      const updated = [...customCategoryPaths, newPath];
      setCustomCategoryPaths(updated);
      try {
        localStorage.setItem("fcb_miasanai_custom_categories", JSON.stringify(updated));
      } catch (err) {
        console.error(err);
      }
    }
    
    setInTreeCategoryCreatePath(null);
    setInTreeCategoryInputValue("");
    
    setExpandedFolders(prev => ({
      ...prev,
      [parentPath]: true,
      [newPath]: true
    }));

    handleAddLog({
      id: `export-category-create-${Date.now()}`,
      timestamp: new Date().toLocaleTimeString(),
      source: "Preset Manager",
      level: "SUCCESS",
      message: language === "de"
        ? `Kategorie-Ordner '${name}' erstellt.`
        : `Category folder '${name}' created.`
    });
  };

  // Helper to count presets recursively in nested subfolders
  const countAllPresets = (node: TreeNode): number => {
    let count = 0;
    Object.values(node.subfolders).forEach(sub => {
      count += sub.presets.length + countAllPresets(sub);
    });
    return count;
  };

  // Helper to count presets belonging to a category or its subcategories
  const getCategoryPresetCount = (categoryPath: string) => {
    if (categoryPath === "All") return exportPresets.length;
    return exportPresets.filter(p => p.category === categoryPath || p.category.startsWith(categoryPath + "/")).length;
  };

  // Drag & drop handlers for presets reordering and folder re-assignment
  const handlePresetDragStart = (e: React.DragEvent, presetId: string) => {
    setDraggedPresetId(presetId);
    e.dataTransfer.effectAllowed = "move";
    e.dataTransfer.setData("text/plain", presetId);
  };

  const handlePresetDragOver = (e: React.DragEvent, presetId: string) => {
    e.preventDefault();
    if (draggedPresetId !== presetId) {
      setDragOverPresetId(presetId);
    }
  };

  const handlePresetDrop = (e: React.DragEvent, targetPresetId: string) => {
    e.preventDefault();
    if (!draggedPresetId || draggedPresetId === targetPresetId) {
      setDraggedPresetId(null);
      setDragOverPresetId(null);
      return;
    }

    const sourceIndex = exportPresets.findIndex(p => p.id === draggedPresetId);
    const targetIndex = exportPresets.findIndex(p => p.id === targetPresetId);

    if (sourceIndex !== -1 && targetIndex !== -1) {
      const updatedPresets = [...exportPresets];
      const [draggedItem] = updatedPresets.splice(sourceIndex, 1);
      
      // Smart move: if dragged to a preset in a different folder, update the category of the dragged item
      const targetPreset = exportPresets[targetIndex];
      if (draggedItem.category !== targetPreset.category) {
        draggedItem.category = targetPreset.category;
      }
      
      updatedPresets.splice(targetIndex, 0, draggedItem);
      setExportPresets(updatedPresets);
      try {
        localStorage.setItem("fcb_miasanai_export_presets", JSON.stringify(updatedPresets));
      } catch (err) {
        console.error(err);
      }

      handleAddLog({
        id: `export-preset-reorder-${Date.now()}`,
        timestamp: new Date().toLocaleTimeString(),
        source: "Preset Manager",
        level: "SUCCESS",
        message: language === "de"
          ? `Preset '${draggedItem.nameDe || draggedItem.name}' neu angeordnet.`
          : `Preset '${draggedItem.name}' reordered.`
      });
    }

    setDraggedPresetId(null);
    setDragOverPresetId(null);
  };

  // Helper to render individual preset cards with full sparkline, drag & drop, and deletion functionality
  const renderPresetCard = (preset: any) => {
    const isActive = 
      compressorEnabled === preset.compressorEnabled &&
      isNormalized === preset.isNormalized &&
      Math.abs(fadeInDuration - preset.fadeInDuration) < 0.05 &&
      Math.abs(fadeOutDuration - preset.fadeOutDuration) < 0.05 &&
      noiseGateThreshold === preset.noiseGateThreshold &&
      compLowThreshold === preset.compLowThreshold &&
      Math.abs(compLowRatio - preset.compLowRatio) < 0.05 &&
      compLowMakeup === preset.compLowMakeup &&
      compMidThreshold === preset.compMidThreshold &&
      Math.abs(compMidRatio - preset.compMidRatio) < 0.05 &&
      compMidMakeup === preset.compMidMakeup &&
      compHighThreshold === preset.compHighThreshold &&
      Math.abs(compHighRatio - preset.compHighRatio) < 0.05 &&
      compHighMakeup === preset.compHighMakeup;

    const translatedCategory = preset.category.split("/").pop() || preset.category;

    return (
      <div 
        key={preset.id}
        draggable="true"
        onDragStart={(e) => handlePresetDragStart(e, preset.id)}
        onDragOver={(e) => handlePresetDragOver(e, preset.id)}
        onDrop={(e) => handlePresetDrop(e, preset.id)}
        onDragEnd={() => {
          setDraggedPresetId(null);
          setDragOverPresetId(null);
        }}
        className={`p-1 rounded text-[8.5px] font-mono border flex items-center justify-between transition-all duration-200 group h-[44px] cursor-grab active:cursor-grabbing ${
          draggedPresetId === preset.id ? "opacity-30 border-slate-800 scale-95" : ""
        } ${
          dragOverPresetId === preset.id 
            ? "border-cyan-400 bg-cyan-950/40 scale-[1.02] shadow-[0_0_8px_rgba(6,182,212,0.3)]" 
            : isActive 
              ? "bg-cyan-500/10 border-cyan-500/40 text-cyan-300 font-bold" 
              : "bg-slate-950/80 hover:bg-slate-900 border-slate-900 text-slate-400 hover:text-slate-200"
        }`}
        title={
          language === "de"
            ? "Ziehen zum Neuordnen / Ablegen in anderem Ordner"
            : "Drag to reorder / Drop in another folder"
        }
      >
        <div className="flex items-center gap-1 flex-1 min-w-0 h-full">
          {/* Mini Grip Handle */}
          <GripVertical className="h-3 w-3 text-slate-600 group-hover:text-cyan-400/75 shrink-0 transition" />
          
          <button
            type="button"
            onClick={() => {
              setCompressorEnabled(preset.compressorEnabled);
              setIsNormalized(preset.isNormalized);
              setFadeInDuration(preset.fadeInDuration);
              setFadeOutDuration(preset.fadeOutDuration);
              setNoiseGateThreshold(preset.noiseGateThreshold);
              
              setCompLowThreshold(preset.compLowThreshold);
              setCompLowRatio(preset.compLowRatio);
              setCompLowMakeup(preset.compLowMakeup);
              
              setCompMidThreshold(preset.compMidThreshold);
              setCompMidRatio(preset.compMidRatio);
              setCompMidMakeup(preset.compMidMakeup);
              
              setCompHighThreshold(preset.compHighThreshold);
              setCompHighRatio(preset.compHighRatio);
              setCompHighMakeup(preset.compHighMakeup);

              handleAddLog({
                id: `export-preset-apply-${Date.now()}`,
                timestamp: new Date().toLocaleTimeString(),
                source: "Preset Manager",
                level: "SUCCESS",
                message: language === "de"
                  ? `Export-Preset '${preset.nameDe}' (${translatedCategory}) angewendet.`
                  : `Export preset '${preset.name}' (${translatedCategory}) applied.`
              });
            }}
            className="flex-1 text-left truncate flex items-center gap-1.5 h-full cursor-pointer min-w-0"
            title={language === "de" ? `Klicken zum Laden von '${preset.nameDe}'` : `Click to load '${preset.name}'`}
          >
            {(() => {
              const { bars, thresholdY, hasCompression, fadeIn, fadeOut } = getPresetSparklineData(preset);
              return (
                <div 
                  className="relative h-[26px] w-[46px] bg-slate-950 p-[1px] rounded border border-slate-900 flex-shrink-0 flex items-end justify-between overflow-hidden"
                  title={
                    language === "de"
                      ? `Einp.: ${fadeIn}s • Ausp.: ${fadeOut}s • Komp.: ${hasCompression ? "Aktiv" : "Umgangen"}`
                      : `Fade In: ${fadeIn}s • Fade Out: ${fadeOut}s • Comp: ${hasCompression ? "Active" : "Bypassed"}`
                  }
                >
                  {hasCompression && thresholdY !== null && (
                    <div 
                      className="absolute left-0 right-0 border-t border-rose-500/35 border-dashed z-0 pointer-events-none"
                      style={{ top: `${thresholdY * 0.8}px` }}
                    />
                  )}
                  
                  <div className="flex items-end gap-[1px] w-full h-full z-10">
                    {bars.map((barHeight, idx) => (
                      <div 
                        key={idx} 
                        className={`flex-1 rounded-t-[1px] transition-all duration-300 ${
                          isActive 
                            ? "bg-cyan-400" 
                            : preset.category.startsWith("Technical") 
                              ? "bg-violet-500/75 group-hover:bg-violet-400" 
                              : "bg-emerald-500/75 group-hover:bg-emerald-400"
                        }`}
                        style={{ height: `${barHeight}%` }}
                      />
                    ))}
                  </div>
                </div>
              );
            })()}

            <div className="flex-1 truncate flex flex-col justify-center leading-none min-w-0">
              <span className="truncate block font-bold text-[8.5px]">
                {language === "de" ? preset.nameDe : preset.name}
              </span>
              <span className="text-[6.5px] text-slate-500 group-hover:text-slate-400 truncate mt-0.5">
                {preset.compressorEnabled ? "Comp" : "Bypass"} • {preset.isNormalized ? "Norm" : "Dry"}
              </span>
            </div>
          </button>
        </div>

        {preset.id.startsWith("preset-custom-") && (
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              const updated = exportPresets.filter(p => p.id !== preset.id);
              setExportPresets(updated);
              try {
                localStorage.setItem("fcb_miasanai_export_presets", JSON.stringify(updated));
              } catch (err) {
                console.error(err);
              }
              handleAddLog({
                id: `export-preset-delete-${Date.now()}`,
                timestamp: new Date().toLocaleTimeString(),
                source: "Preset Manager",
                level: "SUCCESS",
                message: language === "de"
                  ? `Preset '${preset.nameDe}' gelöscht.`
                  : `Preset '${preset.name}' deleted.`
              });
            }}
            className="p-1 text-slate-500 hover:text-rose-400 transition cursor-pointer ml-1 shrink-0"
            title={language === "de" ? "Preset lolschen" : "Delete preset"}
          >
            <Trash2 className="h-3 w-3" />
          </button>
        )}
      </div>
    );
  };

  // Helper to render folders recursively
  const renderFolderNode = (node: TreeNode, depth: number = 0): React.ReactNode => {
    return Object.values(node.subfolders).map((subfolder) => {
      const isExpanded = expandedFolders[subfolder.fullPath] !== false; // default to expanded if not set
      const isCreatingSub = inTreeCategoryCreatePath === subfolder.fullPath;

      return (
        <div key={subfolder.fullPath} className="space-y-1">
          {/* Folder row */}
          <div 
            className="group flex items-center justify-between py-1 px-1.5 hover:bg-slate-900/60 rounded border border-transparent hover:border-slate-800/40 transition select-none text-[8.5px] font-mono font-semibold"
            style={{ paddingLeft: `${depth * 10 + 6}px` }}
          >
            <div 
              className="flex items-center gap-1.5 cursor-pointer text-slate-300 flex-1 truncate"
              onClick={() => {
                setExpandedFolders(prev => ({
                  ...prev,
                  [subfolder.fullPath]: !isExpanded
                }));
              }}
            >
              {isExpanded ? (
                <ChevronDown className="h-3 w-3 text-cyan-500 shrink-0" />
              ) : (
                <ChevronRight className="h-3 w-3 text-slate-500 shrink-0" />
              )}
              <Folder className={`h-3 w-3 shrink-0 ${isExpanded ? "text-cyan-400 fill-cyan-400/10" : "text-amber-500 fill-amber-500/10"}`} />
              <span className="truncate text-slate-200">{subfolder.name}</span>
              <span className="text-[7px] text-slate-500 font-normal">
                ({subfolder.presets.length + countAllPresets(subfolder)})
              </span>
            </div>

            {/* Actions */}
            <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition duration-150 shrink-0">
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setInTreeCategoryCreatePath(subfolder.fullPath);
                  setInTreeCategoryInputValue("");
                  setExpandedFolders(prev => ({ ...prev, [subfolder.fullPath]: true }));
                }}
                className="p-0.5 text-slate-400 hover:text-cyan-400 hover:bg-slate-800 rounded transition cursor-pointer"
                title={language === "de" ? "Unterkategorie hinzufügen" : "Add subcategory"}
              >
                <FolderPlus className="h-3 w-3" />
              </button>
              
              {customCategoryPaths.includes(subfolder.fullPath) && (
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    const updatedPaths = customCategoryPaths.filter(p => p !== subfolder.fullPath && !p.startsWith(subfolder.fullPath + "/"));
                    setCustomCategoryPaths(updatedPaths);
                    try {
                      localStorage.setItem("fcb_miasanai_custom_categories", JSON.stringify(updatedPaths));
                    } catch (err) {
                      console.error(err);
                    }
                    
                    const updatedPresets = exportPresets.filter(p => p.category !== subfolder.fullPath && !p.category.startsWith(subfolder.fullPath + "/"));
                    setExportPresets(updatedPresets);
                    try {
                      localStorage.setItem("fcb_miasanai_export_presets", JSON.stringify(updatedPresets));
                    } catch (err) {
                      console.error(err);
                    }

                    handleAddLog({
                      id: `export-category-delete-${Date.now()}`,
                      timestamp: new Date().toLocaleTimeString(),
                      source: "Preset Manager",
                      level: "SUCCESS",
                      message: language === "de"
                        ? `Kategorie-Ordner '${subfolder.name}' gelöscht.`
                        : `Category folder '${subfolder.name}' deleted.`
                    });
                  }}
                  className="p-0.5 text-slate-500 hover:text-rose-400 hover:bg-slate-800 rounded transition cursor-pointer"
                  title={language === "de" ? "Ordner löschen" : "Delete folder"}
                >
                  <Trash2 className="h-3 w-3" />
                </button>
              )}
            </div>
          </div>

          {/* Inline Subfolder Creation */}
          {isCreatingSub && (
            <div 
              className="flex items-center gap-1.5 py-1 px-1.5 bg-slate-900/40 border border-slate-800/60 rounded"
              style={{ marginLeft: `${(depth + 1) * 10 + 6}px` }}
            >
              <input
                type="text"
                value={inTreeCategoryInputValue}
                onChange={(e) => setInTreeCategoryInputValue(e.target.value)}
                placeholder={language === "de" ? "Name..." : "Name..."}
                className="flex-1 bg-slate-950 border border-slate-800 text-slate-300 text-[8px] rounded px-1.5 py-0.5 font-mono outline-none"
                maxLength={18}
                autoFocus
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    handleCreateInTreeCategory(subfolder.fullPath);
                  } else if (e.key === "Escape") {
                    setInTreeCategoryCreatePath(null);
                  }
                }}
              />
              <button
                type="button"
                onClick={() => handleCreateInTreeCategory(subfolder.fullPath)}
                className="p-0.5 text-emerald-400 hover:bg-slate-800 rounded cursor-pointer"
              >
                <Check className="h-3 w-3" />
              </button>
              <button
                type="button"
                onClick={() => setInTreeCategoryCreatePath(null)}
                className="p-0.5 text-rose-400 hover:bg-slate-800 rounded cursor-pointer"
              >
                <X className="h-3 w-3" />
              </button>
            </div>
          )}

          {/* Render contents of expanded folder */}
          {isExpanded && (
            <div className="space-y-1">
              {renderFolderNode(subfolder, depth + 1)}

              {subfolder.presets.length > 0 && (
                <div 
                  className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 pt-0.5"
                  style={{ paddingLeft: `${(depth + 1) * 10 + 6}px` }}
                >
                  {subfolder.presets.map((preset) => renderPresetCard(preset))}
                </div>
              )}
            </div>
          )}
        </div>
      );
    });
  };

  // Keyboard shortcut Ctrl+S for saving Export Preset when modal is open
  React.useEffect(() => {
    if (!showExportSummaryModal) return;

    const handleCtrlS = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && (e.key === "s" || e.key === "S")) {
        e.preventDefault();
        handleSaveExportPreset();
      }
    };

    window.addEventListener("keydown", handleCtrlS);
    return () => {
      window.removeEventListener("keydown", handleCtrlS);
    };
  }, [
    showExportSummaryModal,
    newPresetName,
    presetSaveParentCategory,
    presetSaveNewSubcategory,
    compressorEnabled,
    isNormalized,
    fadeInDuration,
    fadeOutDuration,
    noiseGateThreshold,
    compLowThreshold,
    compLowRatio,
    compLowMakeup,
    compMidThreshold,
    compMidRatio,
    compMidMakeup,
    compHighThreshold,
    compHighRatio,
    compHighMakeup,
    exportPresets,
    language
  ]);

  const activeAutomationPreset = React.useMemo(() => {
    for (const preset of AUTOMATION_PRESETS) {
      const s = preset.settings;
      if (
        Math.abs(fadeInDuration - s.fadeInDuration) < 0.05 &&
        Math.abs(fadeOutDuration - s.fadeOutDuration) < 0.05 &&
        noiseGateThreshold === s.noiseGateThreshold &&
        isNormalized === s.isNormalized &&
        compressorEnabled === s.compressorEnabled &&
        compMidThreshold === s.compMidThreshold &&
        Math.abs(compMidRatio - s.compMidRatio) < 0.05 &&
        compMidMakeup === s.compMidMakeup &&
        compLowThreshold === s.compLowThreshold &&
        Math.abs(compLowRatio - s.compLowRatio) < 0.05 &&
        compLowMakeup === s.compLowMakeup &&
        compHighThreshold === s.compHighThreshold &&
        Math.abs(compHighRatio - s.compHighRatio) < 0.05 &&
        compHighMakeup === s.compHighMakeup
      ) {
        return preset.id;
      }
    }
    return null;
  }, [
    fadeInDuration,
    fadeOutDuration,
    noiseGateThreshold,
    isNormalized,
    compressorEnabled,
    compMidThreshold,
    compMidRatio,
    compMidMakeup,
    compLowThreshold,
    compLowRatio,
    compLowMakeup,
    compHighThreshold,
    compHighRatio,
    compHighMakeup
  ]);

  const applyAutomationPreset = (presetId: string) => {
    if (isTrimLocked) return;
    const preset = AUTOMATION_PRESETS.find(p => p.id === presetId);
    if (!preset) return;

    const s = preset.settings;
    setFadeInDuration(s.fadeInDuration);
    setFadeOutDuration(s.fadeOutDuration);
    setNoiseGateThreshold(s.noiseGateThreshold);
    setIsNormalized(s.isNormalized);
    setCompressorEnabled(s.compressorEnabled);
    
    setCompMidThreshold(s.compMidThreshold);
    setCompMidRatio(s.compMidRatio);
    setCompMidMakeup(s.compMidMakeup);
    
    setCompLowThreshold(s.compLowThreshold);
    setCompLowRatio(s.compLowRatio);
    setCompLowMakeup(s.compLowMakeup);
    
    setCompHighThreshold(s.compHighThreshold);
    setCompHighRatio(s.compHighRatio);
    setCompHighMakeup(s.compHighMakeup);

    handleAddLog({
      id: `automation-preset-${presetId}-${Date.now()}`,
      timestamp: new Date().toLocaleTimeString(),
      level: "SUCCESS",
      source: "Automation Preset",
      message: language === "de" 
        ? `Automations-Preset '${preset.nameDe}' angewendet: Kompression aktiviert, Fade-In: ${s.fadeInDuration}s, Fade-Out: ${s.fadeOutDuration}s, Noise Gate: ${s.noiseGateThreshold}%.`
        : `Applied '${preset.name}' automation preset: Compression engaged, Fade-In: ${s.fadeInDuration}s, Fade-Out: ${s.fadeOutDuration}s, Noise Gate: ${s.noiseGateThreshold}%.`
    });
  };

  const handleCapturedSpeech = (resultText: string) => {
    setTranscript(resultText);
    const duration = parseFloat((Math.random() * 8 + 32).toFixed(1)); // 32.0 to 40.0 seconds
    setAudioDuration(duration);
    setTrimStart(0.0);
    setTrimEnd(duration);
    setCroppedSuccessfully(false);
    setIsPlayingAudio(false);
    setPlayheadProgress(0.0);
    setFadeInDuration(1.0);
    setFadeOutDuration(1.0);
    setIsNormalized(false);
    setNoiseGateThreshold(15);
    setCompressorEnabled(true);
    setCompressorActiveBand("mid");
    setCompLowThreshold(-24);
    setCompLowRatio(2.5);
    setCompLowAttack(30);
    setCompLowRelease(150);
    setCompLowMakeup(2);
    setCompMidThreshold(-16);
    setCompMidRatio(4.0);
    setCompMidAttack(15);
    setCompMidRelease(100);
    setCompMidMakeup(3);
    setCompHighThreshold(-20);
    setCompHighRatio(3.0);
    setCompHighAttack(8);
    setCompHighRelease(80);
    setCompHighMakeup(1);
    setShowShortcutsModal(false);
    setTrimmerHistory([]);
    setHistoryIndex(-1);
  };

  const exportTrimmedAudio = () => {
    const sampleRate = 16000;
    const duration = trimEnd - trimStart;
    if (duration <= 0) return;
    const numSamples = Math.floor(duration * sampleRate);
    const heights = [35, 20, 55, 30, 85, 45, 40, 75, 95, 55, 30, 65, 85, 45, 75, 30, 55, 20, 45, 65, 30, 55, 40, 20];
    const maxVal = Math.max(...heights);
    const normMultiplier = isNormalized ? (100 / maxVal) : 1.0;
    
    // Allocate buffer: 44 bytes header + numSamples * 2 bytes data
    const buffer = new ArrayBuffer(44 + numSamples * 2);
    const view = new DataView(buffer);
    
    // Helper to write ASCII strings to DataView
    const writeString = (offset: number, string: string) => {
      for (let i = 0; i < string.length; i++) {
        view.setUint8(offset + i, string.charCodeAt(i));
      }
    };
    
    // Write WAV Header
    writeString(0, "RIFF");
    view.setUint32(4, 36 + numSamples * 2, true); // File size - 8
    writeString(8, "WAVE");
    writeString(12, "fmt ");
    view.setUint32(16, 16, true); // Chunk size
    view.setUint16(20, 1, true); // PCM format
    view.setUint16(22, 1, true); // Mono
    view.setUint32(24, sampleRate, true); // Sample rate
    view.setUint32(28, sampleRate * 2, true); // Byte rate
    view.setUint16(32, 2, true); // Block align (1 channel * 2 bytes/sample)
    view.setUint16(34, 16, true); // 16-bit
    writeString(36, "data");
    view.setUint32(40, numSamples * 2, true); // Data chunk size
    
    // Write PCM Samples
    let currentLowGain = 1.0;
    let currentMidGain = 1.0;
    let currentHighGain = 1.0;

    for (let i = 0; i < numSamples; i++) {
      const t = i / sampleRate; // time relative to start of trimmed region
      const originalTime = trimStart + t; // original time in full track
      
      // Determine amplitude from corresponding waveform bar
      const barIdx = Math.min(23, Math.floor((originalTime / audioDuration) * 24));
      const barHeightPct = (heights[barIdx] || 0) * normMultiplier;
      
      // Check silence threshold
      let targetVolume = barHeightPct / 100;
      if (barHeightPct < silenceThreshold) {
        targetVolume = targetVolume * 0.15; // Apply significant dampening for silence
      }
      
      // Apply Noise Gate (fully silence background noise below threshold floor)
      if (barHeightPct < noiseGateThreshold) {
        targetVolume = 0;
      }
      
      // Apply Fade In
      if (t < fadeInDuration && fadeInDuration > 0) {
        targetVolume *= (t / fadeInDuration);
      }
      // Apply Fade Out
      else if (t > duration - fadeOutDuration && fadeOutDuration > 0) {
        targetVolume *= ((duration - t) / fadeOutDuration);
      }
      
      // Compute raw band amplitudes
      const ampLow = 0.5 * targetVolume;
      const ampMid = 0.3 * targetVolume;
      const ampHigh = 0.2 * targetVolume;
      
      const getDb = (amp: number) => {
        if (amp <= 0.0001) return -100;
        return 20 * Math.log10(amp);
      };
      
      // Compute target compressor gain reductions
      let targetLowGain = 1.0;
      let targetMidGain = 1.0;
      let targetHighGain = 1.0;
      
      if (compressorEnabled) {
        // Low Band
        const dbLow = getDb(ampLow);
        if (dbLow > compLowThreshold) {
          const excess = dbLow - compLowThreshold;
          const compressedExcess = excess / compLowRatio;
          const reductionDb = compressedExcess - excess;
          targetLowGain = Math.pow(10, (reductionDb + compLowMakeup) / 20);
        } else {
          targetLowGain = Math.pow(10, compLowMakeup / 20);
        }
        
        // Mid Band
        const dbMid = getDb(ampMid);
        if (dbMid > compMidThreshold) {
          const excess = dbMid - compMidThreshold;
          const compressedExcess = excess / compMidRatio;
          const reductionDb = compressedExcess - excess;
          targetMidGain = Math.pow(10, (reductionDb + compMidMakeup) / 20);
        } else {
          targetMidGain = Math.pow(10, compMidMakeup / 20);
        }
        
        // High Band
        const dbHigh = getDb(ampHigh);
        if (dbHigh > compHighThreshold) {
          const excess = dbHigh - compHighThreshold;
          const compressedExcess = excess / compHighRatio;
          const reductionDb = compressedExcess - excess;
          targetHighGain = Math.pow(10, (reductionDb + compHighMakeup) / 20);
        } else {
          targetHighGain = Math.pow(10, compHighMakeup / 20);
        }
      }
      
      // Dynamic response (Attack/Release smoothing)
      if (compressorEnabled) {
        const lowAttackSec = compLowAttack / 1000;
        const lowReleaseSec = compLowRelease / 1000;
        const lowCoeff = targetLowGain < currentLowGain
          ? 1 - Math.exp(-1 / (sampleRate * lowAttackSec))
          : 1 - Math.exp(-1 / (sampleRate * lowReleaseSec));
        currentLowGain += lowCoeff * (targetLowGain - currentLowGain);
        
        const midAttackSec = compMidAttack / 1000;
        const midReleaseSec = compMidRelease / 1000;
        const midCoeff = targetMidGain < currentMidGain
          ? 1 - Math.exp(-1 / (sampleRate * midAttackSec))
          : 1 - Math.exp(-1 / (sampleRate * midReleaseSec));
        currentMidGain += midCoeff * (targetMidGain - currentMidGain);
        
        const highAttackSec = compHighAttack / 1000;
        const highReleaseSec = compHighRelease / 1000;
        const highCoeff = targetHighGain < currentHighGain
          ? 1 - Math.exp(-1 / (sampleRate * highAttackSec))
          : 1 - Math.exp(-1 / (sampleRate * highReleaseSec));
        currentHighGain += highCoeff * (targetHighGain - currentHighGain);
      } else {
        currentLowGain = 1.0;
        currentMidGain = 1.0;
        currentHighGain = 1.0;
      }
      
      // Synthesize multi-band composite wave with applied band compression gains
      const wave = Math.sin(2 * Math.PI * 220 * t) * 0.5 * currentLowGain + 
                   Math.sin(2 * Math.PI * 440 * t) * 0.3 * currentMidGain + 
                   Math.sin(2 * Math.PI * 880 * t) * 0.2 * currentHighGain;
      
      // Final sample value, scaling and rounding to signed 16-bit range [-32768, 32767]
      const sampleVal = Math.max(-32768, Math.min(32767, Math.floor(wave * targetVolume * 28000)));
      view.setInt16(44 + i * 2, sampleVal, true);
    }
    
    // Create Blob and Download
    const blob = new Blob([view], { type: "audio/wav" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `trimmed_voice_command_${(trimEnd - trimStart).toFixed(1)}s.wav`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    handleAddLog({
      id: `export-wav-${Date.now()}`,
      timestamp: new Date().toLocaleTimeString(),
      level: "SUCCESS",
      source: "Audio Exporter",
      message: `Exported trimmed WAV audio file (${duration.toFixed(1)}s) successfully with ${isNormalized ? "normalized peak gain (100% target) and " : ""}applied fade-in/fade-out ramps.`
    });
  };

  // Keyboard Shortcuts Hook for Audio Trimmer and Exporter
  React.useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't trigger if trimmer is not shown
      if (audioDuration <= 0 || !transcript) return;
      
      const activeEl = document.activeElement;
      if (
        activeEl &&
        (activeEl.tagName === "INPUT" ||
          activeEl.tagName === "TEXTAREA" ||
          activeEl.getAttribute("contenteditable") === "true")
      ) {
        return;
      }

      // Space key -> Play / Pause
      if (e.code === "Space") {
        e.preventDefault();
        if (isPlayingAudio) {
          setIsPlayingAudio(false);
        } else {
          setPlayheadProgress(trimStart);
          setIsPlayingAudio(true);
        }
        handleAddLog({
          id: `shortcut-space-${Date.now()}`,
          timestamp: new Date().toLocaleTimeString(),
          level: "INFO",
          source: "Keyboard Shortcut",
          message: isPlayingAudio ? "Paused audio playback via [Space] hotkey." : "Started audio playback from trim start via [Space] hotkey."
        });
      }

      // Left arrow key -> Nudge trim bounds left
      if (e.key === "ArrowLeft") {
        e.preventDefault();
        if (isTrimLocked) {
          handleAddLog({
            id: `shortcut-locked-${Date.now()}`,
            timestamp: new Date().toLocaleTimeString(),
            level: "WARNING",
            source: "Keyboard Shortcut",
            message: language === "de" ? "Zuschnitt gesperrt. Hebe die Sperre oben auf, um die Grenzen anzupassen." : "Cannot nudge trim boundaries. Trimming is currently locked."
          });
          return;
        }
        setTrimStart(prev => {
          const next = Math.max(0, parseFloat((prev - 0.1).toFixed(1)));
          return next;
        });
        setTrimEnd(prev => {
          const next = Math.max(trimStart + 0.5, parseFloat((prev - 0.1).toFixed(1)));
          return next;
        });
        handleAddLog({
          id: `shortcut-left-${Date.now()}`,
          timestamp: new Date().toLocaleTimeString(),
          level: "INFO",
          source: "Keyboard Shortcut",
          message: "Nudged trim boundaries left by 0.1s via [Left Arrow] hotkey."
        });
      }

      // Right arrow key -> Nudge trim bounds right
      if (e.key === "ArrowRight") {
        e.preventDefault();
        if (isTrimLocked) {
          handleAddLog({
            id: `shortcut-locked-${Date.now()}`,
            timestamp: new Date().toLocaleTimeString(),
            level: "WARNING",
            source: "Keyboard Shortcut",
            message: language === "de" ? "Zuschnitt gesperrt. Hebe die Sperre oben auf, um die Grenzen anzupassen." : "Cannot nudge trim boundaries. Trimming is currently locked."
          });
          return;
        }
        setTrimEnd(prev => {
          const next = Math.min(audioDuration, parseFloat((prev + 0.1).toFixed(1)));
          return next;
        });
        setTrimStart(prev => {
          const next = Math.min(trimEnd - 0.5, parseFloat((prev + 0.1).toFixed(1)));
          return next;
        });
        handleAddLog({
          id: `shortcut-right-${Date.now()}`,
          timestamp: new Date().toLocaleTimeString(),
          level: "INFO",
          source: "Keyboard Shortcut",
          message: "Nudged trim boundaries right by 0.1s via [Right Arrow] hotkey."
        });
      }

      // Cmd/Ctrl + E -> Export as WAV
      if ((e.metaKey || e.ctrlKey) && (e.key === "e" || e.key === "E")) {
        e.preventDefault();
        exportTrimmedAudio();
      }

      // Cmd/Ctrl + Z -> Undo
      if ((e.metaKey || e.ctrlKey) && !e.shiftKey && (e.key === "z" || e.key === "Z")) {
        e.preventDefault();
        handleUndo();
      }

      // Cmd/Ctrl + Y or Cmd/Ctrl + Shift + Z -> Redo
      if (
        ((e.metaKey || e.ctrlKey) && (e.key === "y" || e.key === "Y")) ||
        ((e.metaKey || e.ctrlKey) && e.shiftKey && (e.key === "z" || e.key === "Z"))
      ) {
        e.preventDefault();
        handleRedo();
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [audioDuration, transcript, isPlayingAudio, trimStart, trimEnd, isNormalized, isTrimLocked, handleUndo, handleRedo]);

  const simulateVoiceInput = () => {
    setIsListening(true);
    setSpeechError(null);
    setTranscript("");
    setVoiceLog(null);
    setAudioDuration(0);
    
    // Pick a random supported command
    const commands = [
      "Generate post for Harry Kane",
      "Go to Command Center",
      "Search for tactical analysis of Leverkusen match",
      "Wechsle zu RAG Wissensdatenbank",
      "Erstelle Beitrag für Musiala auf TikTok"
    ];
    const chosenCommand = commands[Math.floor(Math.random() * commands.length)];

    setTimeout(() => {
      setIsListening(false);
      handleCapturedSpeech(chosenCommand);
    }, 2500);
  };

  React.useEffect(() => {
    let interval: any = null;
    if (isPlayingAudio) {
      const step = 0.05;
      interval = setInterval(() => {
        setPlayheadProgress(prev => {
          if (prev >= trimEnd) {
            setIsPlayingAudio(false);
            return trimStart;
          }
          return parseFloat((prev + step).toFixed(2));
        });
      }, 50);
    } else {
      if (interval) clearInterval(interval);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isPlayingAudio, trimStart, trimEnd]);

  const [voiceCommandHistory, setVoiceCommandHistory] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem("fcb_miasanai_voice_history");
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return [
      "Generate post for Harry Kane",
      "Suche Allianz Arena",
      "Wechsle zu Kommandozentrale"
    ];
  });

  const recognitionRef = React.useRef<any>(null);
  const executeVoiceCommandRef = React.useRef<any>(null);
  const handleCapturedSpeechRef = React.useRef<any>(null);

  const speakFeedback = (text: string) => {
    if (!speechEnabled) return;
    if ("speechSynthesis" in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = language === "de" ? "de-DE" : "en-US";
      utterance.pitch = 1.0;
      utterance.rate = 1.05;
      window.speechSynthesis.speak(utterance);
    }
  };

  const executeVoiceCommand = (resultText: string) => {
    setTranscript(resultText);
    
    handleAddLog({
      id: `voice-${Date.now()}`,
      timestamp: new Date().toLocaleTimeString(),
      level: "TRIGGER",
      source: "Voice Command",
      message: `Executed: "${resultText}"`
    });

    const processResult = processVoiceCommand(resultText);
    if (processResult.success) {
      setVoiceCommandHistory(prev => {
        const filtered = prev.filter(cmd => cmd.toLowerCase() !== resultText.toLowerCase());
        const updated = [resultText, ...filtered].slice(0, 5);
        try {
          localStorage.setItem("fcb_miasanai_voice_history", JSON.stringify(updated));
        } catch (e) {
          console.error(e);
        }
        return updated;
      });

      if (processResult.action === "navigation") {
        setVoiceLog(
          language === "de"
            ? `Aktion ausgeführt: Navigation zu ${processResult.target}`
            : `Action executed: Navigate to ${processResult.target}`
        );
      } else if (processResult.action === "search") {
        setVoiceLog(
          language === "de"
            ? `Suche ausgeführt nach: "${processResult.target}"`
            : `Search executed for: "${processResult.target}"`
        );
      } else {
        setVoiceLog(
          language === "de"
            ? `Post generiert für ${processResult.player}`
            : `Generated post for ${processResult.player}`
        );
      }
    } else {
      setVoiceLog(
        language === "de"
          ? `Befehl nicht erkannt. Versuchen Sie es mit "Kommandozentrale" oder "Generiere Beitrag für Kane".`
          : `Command not recognized. Try saying "Command Center" or "Generate post for Kane".`
      );
      speakFeedback(
        language === "de"
          ? "Befehl nicht erkannt."
          : "Command not recognized."
      );
    }
  };

  React.useEffect(() => {
    executeVoiceCommandRef.current = executeVoiceCommand;
    handleCapturedSpeechRef.current = handleCapturedSpeech;
  });

  const processVoiceCommand = (rawText: string) => {
    const text = rawText.toLowerCase().trim();
    
    // 1. Navigation Mapping
    if (
      text.includes("dashboard") || 
      text.includes("kommando") || 
      text.includes("system") || 
      text.includes("übersicht") || 
      text.includes("overview") || 
      text.includes("command center")
    ) {
      setActiveTab("dashboard");
      speakFeedback(language === "de" ? "Wechsle zur Kommandozentrale." : "Switching to Command Center.");
      return { success: true, action: "navigation", target: "Dashboard" };
    }
    
    if (
      text.includes("journey") || 
      text.includes("lifecycle") || 
      text.includes("kundenreise") || 
      text.includes("kampagne") || 
      text.includes("ablauf") || 
      text.includes("flow")
    ) {
      setActiveTab("journey");
      speakFeedback(language === "de" ? "Wechsle zur Lifecycle-Engine." : "Switching to Lifecycle Engine.");
      return { success: true, action: "navigation", target: "Lifecycle Engine" };
    }
    
    // Check for trigger post generation
    const isGenerateCommand = 
      text.includes("generier") || 
      text.includes("erstell") || 
      text.includes("schreib") || 
      text.includes("create") || 
      text.includes("generate") || 
      text.includes("content") || 
      text.includes("post");

    if (isGenerateCommand) {
      setActiveTab("generator");
      
      let player = "";
      if (text.includes("kane")) player = "Harry Kane";
      else if (text.includes("müller") || text.includes("muller")) player = "Thomas Müller";
      else if (text.includes("musiala")) player = "Jamal Musiala";
      else if (text.includes("kimmich")) player = "Joshua Kimmich";
      else if (text.includes("neuer")) player = "Manuel Neuer";
      
      let platform = "";
      if (text.includes("instagram")) platform = "Instagram";
      else if (text.includes("twitter") || text.includes(" x ")) platform = "X/Twitter";
      else if (text.includes("tiktok")) platform = "TikTok";
      else if (text.includes("facebook")) platform = "Facebook";
      else if (text.includes("newsletter") || text.includes("app")) platform = "FCB App/Newsletter";
      
      let tone = "";
      if (text.includes("mia san mia") || text.includes("emotional")) tone = "Mia San Mia / Emotional";
      else if (text.includes("witty") || text.includes("spielrisch") || text.includes("lustig")) tone = "Witty / Playful";
      else if (text.includes("tactical") || text.includes("taktisch") || text.includes("analytisch")) tone = "Tactical / Analytical";
      else if (text.includes("hype") || text.includes("energetic") || text.includes("laut")) tone = "Hype / Energetic";

      speakFeedback(
        language === "de" 
          ? `Generiere Beitrag für ${player || "den ausgewählten Spieler"}.` 
          : `Generating post for ${player || "the selected player"}.`
      );

      setTimeout(() => {
        const event = new CustomEvent("miasanai-voice-generate", {
          detail: { player, platform, tone }
        });
        window.dispatchEvent(event);
      }, 300);

      return { 
        success: true, 
        action: "generate", 
        player: player || "Current", 
        platform: platform || "Default" 
      };
    }

    if (
      text.includes("generator") || 
      text.includes("beitrag") || 
      text.includes("post") || 
      text.includes("schreiben")
    ) {
      setActiveTab("generator");
      speakFeedback(language === "de" ? "Wechsle zum Multi-Format-Generator." : "Switching to Multi-Format Generator.");
      return { success: true, action: "navigation", target: "Generator" };
    }

    if (
      text.includes("video") || 
      text.includes("studio") || 
      text.includes("film") || 
      text.includes("runway") || 
      text.includes("director") || 
      text.includes("kamera")
    ) {
      setActiveTab("video");
      speakFeedback(language === "de" ? "Wechsle zum Video-Studio." : "Switching to Runway Video Director.");
      return { success: true, action: "navigation", target: "Video Studio" };
    }

    if (
      text.includes("rag") || 
      text.includes("wissensdatenbank") || 
      text.includes("knowledge") || 
      text.includes("suche") || 
      text.includes("datenbank") || 
      text.includes("hub")
    ) {
      // Check if it's a search command
      const isSearchKeyword = text.includes("suche") || text.includes("search");
      if (isSearchKeyword) {
        const searchQuery = text.replace(/suche\s+|search\s+/, "").trim();
        setActiveTab("rag");
        speakFeedback(
          language === "de" 
            ? `Suche in Wissensdatenbank nach: ${searchQuery}` 
            : `Searching Knowledge Hub for: ${searchQuery}`
        );
        
        setTimeout(() => {
          const event = new CustomEvent("miasanai-voice-search", {
            detail: { query: searchQuery }
          });
          window.dispatchEvent(event);
        }, 300);
        
        return { success: true, action: "search", target: searchQuery };
      }

      setActiveTab("rag");
      speakFeedback(language === "de" ? "Wechsle zur FCB-Wissensdatenbank." : "Switching to FCB Knowledge Hub.");
      return { success: true, action: "navigation", target: "Knowledge Hub" };
    }

    if (
      text.includes("automation") || 
      text.includes("webhook") || 
      text.includes("middleware") || 
      text.includes("connectors") || 
      text.includes("pipeline")
    ) {
      setActiveTab("automation");
      speakFeedback(language === "de" ? "Wechsle zur Webhook-Pipeline." : "Switching to Webhook Middleware Connectors.");
      return { success: true, action: "navigation", target: "Automation Connectors" };
    }

    // Direct search backup (if starting with search or suche)
    if (text.startsWith("suche ") || text.startsWith("search ")) {
      const searchQuery = text.replace(/^suche |^search /, "").trim();
      setActiveTab("rag");
      speakFeedback(
        language === "de" 
          ? `Suche in Wissensdatenbank nach: ${searchQuery}` 
          : `Searching Knowledge Hub for: ${searchQuery}`
      );
      
      setTimeout(() => {
        const event = new CustomEvent("miasanai-voice-search", {
          detail: { query: searchQuery }
        });
        window.dispatchEvent(event);
      }, 300);
      
      return { success: true, action: "search", target: searchQuery };
    }

    return { success: false, text: rawText };
  };

  React.useEffect(() => {
    const SpeechRecognitionAPI = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognitionAPI) {
      setSpeechSupported(true);
      const rec = new SpeechRecognitionAPI();
      rec.continuous = false;
      rec.interimResults = false;
      
      rec.onstart = () => {
        setIsListening(true);
        setSpeechError(null);
        setTranscript("");
      };

      rec.onresult = (event: any) => {
        const resultText = event.results[0][0].transcript;
        if (handleCapturedSpeechRef.current) {
          handleCapturedSpeechRef.current(resultText);
        }
      };

      rec.onerror = (event: any) => {
        console.error("Speech Recognition Error", event);
        if (event.error === "not-allowed") {
          setSpeechError(language === "de" ? "Mikrofonzugriff verweigert." : "Microphone access denied.");
        } else {
          setSpeechError(language === "de" ? `Fehler bei der Erkennung: ${event.error}` : `Recognition error: ${event.error}`);
        }
        setIsListening(false);
      };

      rec.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = rec;
    } else {
      setSpeechSupported(false);
    }
  }, [language]);

  const startListening = () => {
    if (recognitionRef.current) {
      try {
        recognitionRef.current.lang = language === "de" ? "de-DE" : "en-US";
        recognitionRef.current.start();
        setVoiceLog(null);
        setShowAssistantPanel(true);
      } catch (err) {
        console.error("Failed to start speech recognition", err);
      }
    }
  };

  const stopListening = () => {
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch (err) {
        console.error("Failed to stop speech recognition", err);
      }
    }
  };

  const navigationTabs = [
    { id: "dashboard", name: t("tabDashboard"), icon: Layers, description: t("tabDashboardDesc") },
    { id: "journey", name: t("tabJourney"), icon: GitFork, description: t("tabJourneyDesc") },
    { id: "generator", name: t("tabGenerator"), icon: Sparkles, description: t("tabGeneratorDesc") },
    { id: "moderation", name: t("tabModeration"), icon: CheckCircle2, description: t("tabModerationDesc") },
    { id: "video", name: t("tabVideo"), icon: Clapperboard, description: t("tabVideoDesc") },
    { id: "rag", name: t("tabRag"), icon: Database, description: t("tabRagDesc") },
    { id: "automation", name: t("tabAutomation"), icon: Workflow, description: t("tabAutomationDesc") },
    { id: "langgraph", name: t("tabLangGraph"), icon: Network, description: t("tabLangGraphDesc") },
    { id: "analytics", name: language === "de" ? "Analyse-Studio" : "Analytics Studio", icon: BarChart3, description: language === "de" ? "Tableau & Live KPIs" : "Tableau Embed & Live KPIs" },
    { id: "settings", name: t("tabSettings"), icon: Settings, description: t("tabSettingsDesc") }
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-fcb-red selection:text-white">
      
      {/* 1. Global Header branding bar */}
      <header className="sticky top-0 z-50 bg-[#0c0c0f]/85 backdrop-blur-md border-b border-slate-800/80 px-4 sm:px-6 py-4 flex flex-col sm:flex-row items-center justify-between gap-4">
        
        {/* FCB Brand identity */}
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 bg-fcb-red rounded-full flex items-center justify-center border-2 border-white shadow-lg shadow-fcb-red/10 flex-shrink-0">
            <span className="text-white font-extrabold font-display text-xs tracking-tighter">FCB</span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-bold font-display tracking-tight text-white">{t("appName")}</h1>
              <span className="bg-fcb-gold/15 text-fcb-gold text-[9px] font-mono font-bold tracking-wider uppercase px-1.5 py-0.5 rounded border border-fcb-gold/25">
                {t("enterprise")}
              </span>
            </div>
            <p className="text-[11px] text-slate-400 font-medium">{t("subHeader")}</p>
          </div>
        </div>

        {/* Global interactive notification bell banner */}
        <div className="flex items-center gap-4 w-full sm:w-auto justify-end">
          <AnimatePresence mode="wait">
            {notification && (
              <motion.div 
                initial={{ opacity: 0, y: -5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -5 }}
                className="bg-slate-900/60 border border-slate-800/80 px-3 py-1.5 rounded-lg max-w-sm sm:max-w-md text-[11px] text-slate-300 flex items-center gap-2 shadow-inner"
              >
                <Bell className="h-3.5 w-3.5 text-fcb-gold animate-bounce flex-shrink-0" />
                <span className="truncate">{notification}</span>
                <button 
                  onClick={() => setNotification(null)}
                  className="text-slate-500 hover:text-white font-mono ml-1 text-[10px]"
                >
                  [x]
                </button>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Premium Language Switcher Toggle */}
          <div className="flex items-center bg-slate-950 border border-slate-800/80 p-1 rounded-lg">
            <button
              onClick={() => setLanguage("de")}
              className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold transition-all cursor-pointer ${
                language === "de"
                  ? "bg-fcb-red text-white shadow-md shadow-fcb-red/10 font-black"
                  : "text-slate-500 hover:text-slate-300 font-normal"
              }`}
            >
              DE
            </button>
            <button
              onClick={() => setLanguage("en")}
              className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold transition-all cursor-pointer ${
                language === "en"
                  ? "bg-fcb-red text-white shadow-md shadow-fcb-red/10 font-black"
                  : "text-slate-500 hover:text-slate-300 font-normal"
              }`}
            >
              EN
            </button>
          </div>

          {/* Voice Assistant Trigger */}
          <div className="relative">
            <button
              onClick={() => {
                if (isListening) {
                  stopListening();
                } else {
                  startListening();
                }
              }}
              className={`px-2.5 py-1.5 rounded-lg border flex items-center gap-1.5 transition-all text-[11px] font-mono cursor-pointer ${
                isListening
                  ? "bg-red-500/15 border-red-500 text-red-400 shadow-md shadow-red-500/10 font-bold"
                  : "bg-slate-950 border-slate-800 text-slate-400 hover:text-white hover:border-slate-700"
              }`}
              title={language === "de" ? "Sprachsteuerung" : "Voice Command"}
              id="voice-command-trigger"
            >
              {isListening ? (
                <>
                  <Mic className="h-3.5 w-3.5 animate-pulse text-red-500" />
                  <span className="hidden sm:inline font-bold uppercase tracking-wider text-[9px] animate-pulse">
                    {language === "de" ? "Zuhören..." : "Listening..."}
                  </span>
                </>
              ) : (
                <>
                  <Mic className="h-3.5 w-3.5 text-fcb-gold" />
                  <span className="hidden sm:inline font-bold uppercase tracking-wider text-[9px]">
                    {language === "de" ? "Sprachbefehl" : "Voice Assist"}
                  </span>
                </>
              )}
            </button>

            {/* Voice Command Info Popover / Assistant Flyout */}
            <AnimatePresence>
              {showAssistantPanel && (
                <motion.div
                  initial={{ opacity: 0, y: 10, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 10, scale: 0.95 }}
                  className="absolute right-0 mt-2 w-80 bg-slate-900/95 backdrop-blur-md border border-slate-850 rounded-xl shadow-2xl z-50 p-4 space-y-3.5 select-text"
                >
                  <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                    <span className="text-[9px] font-mono text-fcb-gold uppercase tracking-wider font-bold flex items-center gap-1.5">
                      <Volume2 className="h-3.5 w-3.5 text-fcb-gold" />
                      MiaSanAI Voice Command
                    </span>
                    <button
                      onClick={() => setShowAssistantPanel(false)}
                      className="text-slate-500 hover:text-white text-[10px] cursor-pointer font-mono"
                    >
                      [close]
                    </button>
                  </div>

                  {/* Recognition Status / Animation */}
                  <div className="bg-slate-950 rounded-lg p-3 border border-slate-800/60 flex flex-col items-center justify-center min-h-[75px] relative overflow-hidden">
                    {isListening ? (
                      <div className="space-y-2 text-center w-full">
                        <div className="flex items-center justify-center gap-1">
                          <span className="h-3 w-0.5 bg-red-500 animate-bounce rounded-full"></span>
                          <span className="h-5 w-0.5 bg-red-500 animate-bounce rounded-full" style={{ animationDelay: "100ms" }}></span>
                          <span className="h-4 w-0.5 bg-red-500 animate-bounce rounded-full" style={{ animationDelay: "200ms" }}></span>
                          <span className="h-6 w-0.5 bg-red-500 animate-bounce rounded-full" style={{ animationDelay: "150ms" }}></span>
                          <span className="h-3 w-0.5 bg-red-500 animate-bounce rounded-full" style={{ animationDelay: "50ms" }}></span>
                        </div>
                        <span className="text-[9px] font-mono text-red-400 block uppercase tracking-wide">
                          {language === "de" ? "Sprechen Sie jetzt..." : "Speak now..."}
                        </span>
                      </div>
                    ) : (
                      <div className="text-center space-y-2">
                        <MicOff className="h-4 w-4 text-slate-600 mx-auto" />
                        <span className="text-[9px] font-mono text-slate-500 block uppercase tracking-wide">
                          {language === "de" ? "Mikrofon inaktiv" : "Microphone Idle"}
                        </span>
                        <button
                          onClick={simulateVoiceInput}
                          className="px-2 py-1 bg-slate-900 hover:bg-slate-850 border border-slate-800 text-[9px] text-fcb-gold rounded-md font-mono cursor-pointer transition active:scale-95 animate-pulse"
                          id="simulate-mic-trigger"
                        >
                          {language === "de" ? "[Sprachbefehl simulieren]" : "[Simulate Recording]"}
                        </button>
                      </div>
                    )}

                    {/* Live Transcript or Hint */}
                    {transcript && (
                      <div className="mt-2.5 w-full text-center border-t border-slate-900 pt-2 select-text">
                        <span className="text-[8px] font-mono text-slate-500 block uppercase">Captured Transcript:</span>
                        <p className="text-[10px] text-white italic font-medium mt-0.5">"{transcript}"</p>
                      </div>
                    )}

                    {speechError && (
                      <div className="mt-2.5 w-full text-center border-t border-slate-900 pt-2">
                        <p className="text-[10px] text-red-400 font-medium">{speechError}</p>
                      </div>
                    )}

                    {voiceLog && (
                      <div className="mt-2.5 w-full text-center border-t border-slate-900 pt-2 select-text">
                        <p className="text-[10.5px] text-green-400 font-semibold leading-relaxed">{voiceLog}</p>
                      </div>
                    )}
                  </div>

                  {/* Audio Trimmer & Waveform Crop Tool */}
                  {audioDuration > 0 && transcript && (() => {
                    const heights = [35, 20, 55, 30, 85, 45, 40, 75, 95, 55, 30, 65, 85, 45, 75, 30, 55, 20, 45, 65, 30, 55, 40, 20];
                    const maxVal = Math.max(...heights);
                    const normMultiplier = isNormalized ? (100 / maxVal) : 1.0;
                    const processedHeights = heights.map(h => Math.min(100, Math.round(h * normMultiplier)));

                    const optStartIdx = processedHeights.findIndex(h => h >= silenceThreshold);
                    const optEndIdx = 23 - [...processedHeights].reverse().findIndex(h => h >= silenceThreshold);
                    
                    const suggestedStartS = optStartIdx >= 0 ? parseFloat((optStartIdx * (audioDuration / 24)).toFixed(1)) : 0.0;
                    const suggestedEndS = optEndIdx >= 0 && optEndIdx < 24 ? parseFloat(((optEndIdx + 1) * (audioDuration / 24)).toFixed(1)) : audioDuration;

                    return (
                      <div className="bg-slate-950 p-3 rounded-lg border border-slate-850/60 space-y-3 relative overflow-hidden" id="audio-trimmer-visualization">
                        <div className="flex items-center justify-between border-b border-slate-900 pb-1.5">
                          <span className="text-[9px] font-mono text-cyan-400 font-bold uppercase tracking-wide flex items-center gap-1">
                            <Scissors className="h-3 w-3 animate-pulse" />
                            {language === "de" ? "Audio-Zuschnitt & Lautstärkeverlauf" : "Audio Crop, Trim & Fades"}
                          </span>
                          <div className="flex items-center gap-2">
                            {/* Undo / Redo controls */}
                            <div className="flex items-center gap-1 bg-slate-900 px-1 py-0.5 rounded border border-slate-800 text-slate-400">
                              <button
                                onClick={handleUndo}
                                disabled={historyIndex <= 0}
                                className="p-1 hover:bg-slate-805 disabled:opacity-20 disabled:hover:bg-transparent text-slate-300 hover:text-white disabled:text-slate-600 rounded cursor-pointer transition flex items-center justify-center"
                                title={language === "de" ? "Rückgängig (Strg+Z)" : "Undo change (Ctrl+Z)"}
                                id="trimmer-undo-btn"
                              >
                                <Undo className="h-2.5 w-2.5" />
                              </button>
                              <button
                                onClick={handleRedo}
                                disabled={historyIndex >= trimmerHistory.length - 1}
                                className="p-1 hover:bg-slate-805 disabled:opacity-20 disabled:hover:bg-transparent text-slate-300 hover:text-white disabled:text-slate-600 rounded cursor-pointer transition flex items-center justify-center"
                                title={language === "de" ? "Wiederholen (Strg+Y)" : "Redo change (Ctrl+Y)"}
                                id="trimmer-redo-btn"
                              >
                                <Redo className="h-2.5 w-2.5" />
                              </button>
                            </div>

                            <button
                              id="lock-trim-toggle"
                              onClick={() => {
                                const newLocked = !isTrimLocked;
                                setIsTrimLocked(newLocked);
                                handleAddLog({
                                  id: `lock-toggle-${Date.now()}`,
                                  timestamp: new Date().toLocaleTimeString(),
                                  level: "INFO",
                                  source: "Audio Trimmer",
                                  message: newLocked
                                    ? (language === "de"
                                      ? "Zuschnittgrenzen gesperrt. Drag-and-Drop-Griffe und Hotkey-Anpassungen sind deaktiviert."
                                      : "Trimming boundaries locked. Accidental drag-and-drop handles and hotkey adjustments are now disabled.")
                                    : (language === "de"
                                      ? "Zuschnittgrenzen entsperrt. Präzisions-Feineinstellungen aktiviert."
                                      : "Trimming boundaries unlocked. Precision adjustments enabled.")
                                });
                              }}
                              className={`px-1.5 py-0.5 border text-[8px] font-mono rounded cursor-pointer transition flex items-center gap-1 ${
                                isTrimLocked
                                  ? "bg-rose-500/20 hover:bg-rose-500/30 border-rose-500/40 text-rose-400 font-bold"
                                  : "bg-slate-900 hover:bg-slate-850 border-slate-800 text-slate-400 hover:text-slate-200"
                              }`}
                              title={isTrimLocked ? (language === "de" ? "Auswahl entsperren" : "Unlock Selection") : (language === "de" ? "Auswahl sperren" : "Lock Selection")}
                            >
                              {isTrimLocked ? (
                                <>
                                  <Lock className="h-2.5 w-2.5 text-rose-400" />
                                  <span>{language === "de" ? "Gesperrt" : "Locked"}</span>
                                </>
                              ) : (
                                <>
                                  <Unlock className="h-2.5 w-2.5" />
                                  <span>{language === "de" ? "Sperren" : "Lock"}</span>
                                </>
                              )}
                            </button>

                            <button
                              id="keyboard-shortcuts-btn"
                              onClick={() => setShowShortcutsModal(true)}
                              className="px-1.5 py-0.5 bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 text-slate-400 hover:text-white text-[8px] font-mono rounded cursor-pointer transition flex items-center gap-1"
                              title={language === "de" ? "Tastaturkürzel anzeigen" : "Show keyboard shortcuts"}
                            >
                              <Keyboard className="h-2.5 w-2.5" />
                              <span>{language === "de" ? "Shortcuts" : "Shortcuts"}</span>
                            </button>

                            <button
                              id="show-export-summary-btn"
                              onClick={() => setShowExportSummaryModal(true)}
                              className="px-1.5 py-0.5 bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 text-slate-400 hover:text-white text-[8px] font-mono rounded cursor-pointer transition flex items-center gap-1"
                              title={language === "de" ? "Export-Zusammenfassung anzeigen" : "Show Export Summary"}
                            >
                              <Info className="h-2.5 w-2.5 text-cyan-400" />
                              <span>{language === "de" ? "Export-Zusammenfassung" : "Export Summary"}</span>
                            </button>
                            <span className="text-[9px] font-mono text-slate-400">
                              {trimStart.toFixed(1)}s - {trimEnd.toFixed(1)}s / {audioDuration.toFixed(1)}s
                            </span>
                          </div>
                        </div>

                        {/* Quick Trimming Presets Section */}
                        <div className="space-y-1">
                          <span className="text-[8px] font-mono text-slate-500 uppercase tracking-wider block">
                            {language === "de" ? "Schnell-Zuschnitt-Presets:" : "Quick Trimming Presets:"}
                          </span>
                          <div className="grid grid-cols-4 gap-1">
                            {[5, 10, 30].map((presetVal) => {
                              const isAvailable = audioDuration >= presetVal;
                              return (
                                <button
                                  key={presetVal}
                                  disabled={!isAvailable || isTrimLocked}
                                  onClick={() => {
                                    const targetEnd = Math.min(presetVal, audioDuration);
                                    setTrimStart(0);
                                    setTrimEnd(targetEnd);
                                    setPlayheadProgress(0);
                                    // Adjust fades if they exceed new bounds
                                    const maxAllowedFade = Math.min(1.0, parseFloat((targetEnd / 2).toFixed(1)));
                                    setFadeInDuration(maxAllowedFade);
                                    setFadeOutDuration(maxAllowedFade);
                                    setCroppedSuccessfully(false);
                                    handleAddLog({
                                      id: `preset-${presetVal}-${Date.now()}`,
                                      timestamp: new Date().toLocaleTimeString(),
                                      level: "INFO",
                                      source: "Audio Trimmer",
                                      message: `Applied standard speech crop preset: [0.0s - ${targetEnd.toFixed(1)}s] (${presetVal}s window).`
                                    });
                                  }}
                                  className={`py-1 rounded text-[9px] font-mono border cursor-pointer transition text-center disabled:opacity-35 disabled:cursor-not-allowed ${
                                    trimStart === 0 && Math.abs(trimEnd - Math.min(presetVal, audioDuration)) < 0.1
                                      ? "bg-fcb-red/20 border-fcb-red text-white font-bold animate-pulse"
                                      : "bg-slate-900 hover:bg-slate-850 border-slate-800 text-slate-400 hover:text-slate-200"
                                  }`}
                                >
                                  {presetVal}s
                                </button>
                              );
                            })}
                            <button
                              disabled={isTrimLocked}
                              onClick={() => {
                                setTrimStart(0);
                                setTrimEnd(audioDuration);
                                setPlayheadProgress(0);
                                setFadeInDuration(1.0);
                                setFadeOutDuration(1.0);
                                setCroppedSuccessfully(false);
                                handleAddLog({
                                  id: `preset-reset-${Date.now()}`,
                                  timestamp: new Date().toLocaleTimeString(),
                                  level: "INFO",
                                  source: "Audio Trimmer",
                                  message: `Reset trimming boundaries to original speech signal duration of ${audioDuration.toFixed(1)}s.`
                                });
                              }}
                              className={`py-1 rounded text-[9px] font-mono border cursor-pointer transition text-center disabled:opacity-35 disabled:cursor-not-allowed ${
                                trimStart === 0 && Math.abs(trimEnd - audioDuration) < 0.1
                                  ? "bg-fcb-gold/20 border-fcb-gold text-white font-bold"
                                  : "bg-slate-900 hover:bg-slate-850 border-slate-800 text-slate-400 hover:text-slate-200"
                              }`}
                            >
                              {language === "de" ? "Gesamt" : "Full Reset"}
                            </button>
                          </div>
                        </div>

                        {/* Automation Presets Section */}
                        <div id="automation-presets-panel" className="space-y-1.5 p-2 rounded border border-slate-900 bg-slate-900/40">
                          <div className="flex items-center justify-between gap-2 border-b border-slate-950 pb-1.5">
                            <span className="text-[8px] font-mono text-cyan-400 font-bold uppercase tracking-wider block flex items-center gap-1">
                              <Sliders className="h-3 w-3 text-cyan-500 animate-pulse" />
                              {language === "de" ? "Automations-Presets (Lautstärke & Kompression):" : "Automation Presets (Gain & Compression):"}
                            </span>
                            <div className="flex items-center gap-1.5">
                              <span className="text-[7.5px] font-mono text-slate-500 uppercase tracking-wider">
                                {language === "de" ? "Kategorie:" : "Category:"}
                              </span>
                              <select
                                id="preset-category-dropdown"
                                value={selectedPresetCategory}
                                onChange={(e) => setSelectedPresetCategory(e.target.value)}
                                className="bg-slate-950 border border-slate-800 text-slate-300 rounded px-1.5 py-0.5 text-[8.5px] font-mono outline-none transition cursor-pointer"
                              >
                                <option value="All">{language === "de" ? "Alle" : "All"}</option>
                                <option value="Podcast">Podcast</option>
                                <option value="Short-form Social">Short-form Social</option>
                                <option value="System Voice">System Voice</option>
                              </select>
                            </div>
                          </div>
                          <p className="text-[8px] text-slate-500 leading-normal font-mono">
                            {language === "de"
                              ? "Kompressions- und Fade-Kurven sofort für gängige Audio-Typen optimieren."
                              : "Instantly apply standard compression & fade curves optimized for specific speech types."}
                          </p>
                          <div className="grid grid-cols-3 gap-1.5">
                            {AUTOMATION_PRESETS
                              .filter((p) => selectedPresetCategory === "All" || p.category === selectedPresetCategory)
                              .map((preset) => {
                                const isActive = activeAutomationPreset === preset.id;
                                const desc = language === "de" ? preset.descriptionDe : preset.description;
                                return (
                                  <button
                                    key={preset.id}
                                    disabled={isTrimLocked}
                                    onClick={() => {
                                      applyAutomationPreset(preset.id);
                                    }}
                                    className={`p-1.5 rounded text-[9.5px] font-mono border cursor-pointer transition text-left flex flex-col justify-between h-[52px] group disabled:opacity-35 disabled:cursor-not-allowed ${
                                      isActive
                                        ? preset.activeBg
                                        : "bg-slate-950 hover:bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200"
                                    }`}
                                    title={desc}
                                  >
                                    <div className="flex items-center justify-between w-full">
                                      <span className="font-bold truncate">{language === "de" ? preset.nameDe : preset.name}</span>
                                      <span className="text-[10px] group-hover:scale-110 transition-transform">{preset.icon}</span>
                                    </div>
                                    <span className="text-[7.5px] text-slate-500 group-hover:text-slate-400 truncate w-full block">
                                      {desc}
                                    </span>
                                  </button>
                                );
                              })}
                          </div>
                        </div>

                        {/* Silence Detection and Highlights Section */}
                        <div className="bg-slate-900/40 p-2 rounded border border-slate-900/60 space-y-2">
                          <div className="grid grid-cols-2 gap-3 pb-1.5 border-b border-slate-950/50">
                            {/* Column 1: Silence Suggestions */}
                            <div className="space-y-1">
                              <div className="flex items-center justify-between">
                                <span className="text-[9px] font-mono text-amber-400 font-bold uppercase tracking-wider flex items-center gap-1">
                                  <AlertCircle className="h-3 w-3 text-amber-500 animate-pulse" />
                                  {language === "de" ? "Stille-Analysator" : "Silence Suggestion"}
                                </span>
                              </div>
                              <div className="flex items-center gap-1.5">
                                <input
                                  type="range"
                                  min="10"
                                  max="55"
                                  step="5"
                                  value={silenceThreshold}
                                  onChange={(e) => {
                                    setSilenceThreshold(parseInt(e.target.value));
                                  }}
                                  className="flex-1 accent-amber-500 bg-slate-950 h-1 rounded cursor-pointer"
                                />
                                <span className="text-[9px] font-mono text-slate-300 font-bold min-w-[20px] text-right">
                                  {silenceThreshold}%
                                </span>
                              </div>
                            </div>

                            {/* Column 2: Noise Gate Threshold */}
                            <div className="space-y-1">
                              <div className="flex items-center justify-between">
                                <span className="text-[9px] font-mono text-rose-400 font-bold uppercase tracking-wider flex items-center gap-1">
                                  <Volume2 className="h-3 w-3 text-rose-500" />
                                  {language === "de" ? "Noise Gate" : "Noise Gate"}
                                </span>
                              </div>
                              <div className="flex items-center gap-1.5">
                                <input
                                  id="noise-gate-slider"
                                  type="range"
                                  min="0"
                                  max="40"
                                  step="2"
                                  value={noiseGateThreshold}
                                  onChange={(e) => {
                                    const val = parseInt(e.target.value);
                                    setNoiseGateThreshold(val);
                                    handleAddLog({
                                      id: `noise-gate-${Date.now()}`,
                                      timestamp: new Date().toLocaleTimeString(),
                                      level: "INFO",
                                      source: "Audio Engine",
                                      message: `Noise gate threshold floor adjusted to ${val}%. Waveform segments below ${val}% amplitude will be programmatically attenuated to 0% volume.`
                                    });
                                  }}
                                  className="flex-1 accent-rose-500 bg-slate-950 h-1 rounded cursor-pointer"
                                />
                                <span className="text-[9px] font-mono text-slate-300 font-bold min-w-[20px] text-right">
                                  {noiseGateThreshold}%
                                </span>
                              </div>
                            </div>
                          </div>

                          <div className="flex items-center justify-between pt-1 text-[9px] font-mono">
                            <span className="text-slate-400">{language === "de" ? "Lautstärke normalisieren:" : "Normalize Audio Volume:"}</span>
                            <button
                              id="normalize-volume-btn"
                              onClick={() => {
                                const newNormalized = !isNormalized;
                                setIsNormalized(newNormalized);
                                handleAddLog({
                                  id: `normalize-${Date.now()}`,
                                  timestamp: new Date().toLocaleTimeString(),
                                  level: "INFO",
                                  source: "Audio Engine",
                                  message: newNormalized 
                                    ? `Volume normalization enabled. Programmatically adjusting peak levels of the buffer to 100% (Gain multiplier: x${(100 / Math.max(...heights)).toFixed(2)}).`
                                    : "Volume normalization disabled. Reverting to raw speech input amplitude levels."
                                });
                              }}
                              className={`px-2 py-0.5 rounded cursor-pointer transition text-[9px] font-mono border ${
                                isNormalized 
                                  ? "bg-emerald-500/20 border-emerald-500/40 text-emerald-400 font-bold"
                                  : "bg-slate-950 hover:bg-slate-900 border-slate-800 text-slate-400"
                              }`}
                            >
                              {isNormalized ? (language === "de" ? "AKTIV" : "ENABLED") : (language === "de" ? "INAKTIV" : "DISABLED")}
                            </button>
                          </div>

                          <div className="flex items-center justify-between gap-1.5 bg-slate-950/75 p-1.5 rounded border border-slate-900 text-[9px] font-mono text-slate-300">
                            <div className="space-y-0.5">
                              <span className="text-[8px] text-slate-500 block uppercase">{language === "de" ? "Empfohlenes Sprachsegment:" : "Suggested Speech Window:"}</span>
                              <span className="text-amber-400 font-bold font-mono">
                                {suggestedStartS.toFixed(1)}s - {suggestedEndS.toFixed(1)}s 
                                <span className="text-slate-400 font-normal ml-1">({(suggestedEndS - suggestedStartS).toFixed(1)}s)</span>
                              </span>
                            </div>
                            <button
                              disabled={isTrimLocked}
                              onClick={() => {
                                setTrimStart(suggestedStartS);
                                setTrimEnd(suggestedEndS);
                                setPlayheadProgress(suggestedStartS);
                                setCroppedSuccessfully(false);
                                handleAddLog({
                                  id: `silence-crop-${Date.now()}`,
                                  timestamp: new Date().toLocaleTimeString(),
                                  level: "SUCCESS",
                                  source: "Silence Detection",
                                  message: `Applied optimal crop suggestion: [${suggestedStartS.toFixed(1)}s - ${suggestedEndS.toFixed(1)}s] based on ${silenceThreshold}% amplitude threshold.`
                                });
                              }}
                              className="px-1.5 py-0.5 bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/30 hover:border-amber-500/50 text-amber-400 text-[9px] font-mono rounded cursor-pointer transition active:scale-95 whitespace-nowrap disabled:opacity-35 disabled:cursor-not-allowed"
                            >
                              {language === "de" ? "Vorschlag anwenden" : "Apply Suggestion"}
                            </button>
                          </div>
                        </div>

                        {/* Multi-Band Dynamic Range Compressor Panel */}
                        <div id="multi-band-compressor-panel" className="bg-slate-900/50 p-2.5 rounded border border-slate-900/80 space-y-2.5">
                          {/* Header Block */}
                          <div className="flex items-center justify-between border-b border-slate-950/60 pb-2">
                            <div className="flex items-center gap-1.5">
                              <Sliders className={`h-3.5 w-3.5 ${compressorEnabled ? "text-violet-400 animate-pulse" : "text-slate-500"}`} />
                              <span className="text-[10px] font-mono text-slate-200 uppercase tracking-wider font-bold">
                                {language === "de" ? "Multi-Band Dynamik-Kompressor" : "Multi-Band Dynamic Compressor"}
                              </span>
                            </div>
                            
                            {/* Master Toggle */}
                            <div className="flex items-center gap-2">
                              <span className="text-[8px] font-mono text-slate-400">
                                {compressorEnabled ? (language === "de" ? "AKTIVIERT" : "COMPRESSION ACTIVE") : (language === "de" ? "BYPASS" : "BYPASS")}
                              </span>
                              <button
                                onClick={() => {
                                  const newVal = !compressorEnabled;
                                  setCompressorEnabled(newVal);
                                  handleAddLog({
                                    id: `comp-toggle-${Date.now()}`,
                                    timestamp: new Date().toLocaleTimeString(),
                                    level: newVal ? "SUCCESS" : "WARNING",
                                    source: "Audio Engine",
                                    message: newVal 
                                      ? "Multi-band dynamic range compressor engaged. Low, Mid, and High band signal levels will be compressed above thresholds to professional standards."
                                      : "Multi-band compressor bypassed. Reverting to linear raw audio dynamics."
                                  });
                                }}
                                className={`w-8 h-4 rounded-full p-0.5 transition-colors cursor-pointer ${compressorEnabled ? "bg-violet-500" : "bg-slate-950 border border-slate-800"}`}
                              >
                                <div className={`w-2.5 h-2.5 rounded-full bg-white transition-transform ${compressorEnabled ? "translate-x-4.5" : "translate-x-0.5"}`} />
                              </button>
                            </div>
                          </div>

                          {/* 3-Band Selector Tabs */}
                          <div className="grid grid-cols-3 gap-1.5 p-1 bg-slate-950/80 rounded border border-slate-900">
                            {[
                              { id: "low", label: language === "de" ? "Bass (Tiefen)" : "Low Band (<250Hz)", color: "border-emerald-500/30 text-emerald-400" },
                              { id: "mid", label: language === "de" ? "Mitten (Sprache)" : "Mid Band (Speech)", color: "border-cyan-500/30 text-cyan-400" },
                              { id: "high", label: language === "de" ? "Sibilanz (Höhen)" : "High Band (>4kHz)", color: "border-purple-500/30 text-purple-400" }
                            ].map((band) => {
                              const isActive = compressorActiveBand === band.id;
                              return (
                                <button
                                  key={band.id}
                                  onClick={() => setCompressorActiveBand(band.id as any)}
                                  className={`py-1 px-1.5 rounded text-[8px] font-mono font-bold tracking-tight cursor-pointer transition text-center border ${
                                    isActive 
                                      ? "bg-slate-900 border-violet-500/80 text-violet-300 shadow-sm"
                                      : "bg-transparent border-transparent text-slate-500 hover:text-slate-300"
                                  }`}
                                >
                                  {band.label}
                                </button>
                              );
                            })}
                          </div>

                          {/* Active Band Sliders and Gain Reduction Indicator */}
                          <div className="bg-slate-950/50 p-2 rounded border border-slate-950/80 grid grid-cols-1 md:grid-cols-3 gap-3">
                            {/* Controls Column */}
                            <div className="space-y-2">
                              {/* Row 1: Ratio Slider */}
                              <div className="space-y-1">
                                <div className="flex items-center justify-between text-[8px] font-mono">
                                  <span className="text-slate-400">{language === "de" ? "Verhältnis (Ratio):" : "Compression Ratio:"}</span>
                                  <span className="text-violet-400 font-bold">
                                    {compressorActiveBand === "low" ? compLowRatio.toFixed(1) : compressorActiveBand === "mid" ? compMidRatio.toFixed(1) : compHighRatio.toFixed(1)}:1
                                  </span>
                                </div>
                                <div className="flex items-center gap-1.5">
                                  <input
                                    type="range"
                                    min="1.0"
                                    max="20.0"
                                    step="0.5"
                                    value={compressorActiveBand === "low" ? compLowRatio : compressorActiveBand === "mid" ? compMidRatio : compHighRatio}
                                    onChange={(e) => {
                                      const val = parseFloat(e.target.value);
                                      if (compressorActiveBand === "low") setCompLowRatio(val);
                                      else if (compressorActiveBand === "mid") setCompMidRatio(val);
                                      else setCompHighRatio(val);
                                    }}
                                    disabled={!compressorEnabled}
                                    className="flex-1 accent-violet-500 bg-slate-950 h-1 rounded cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed"
                                  />
                                </div>
                              </div>

                              {/* Row 2: Threshold Slider */}
                              <div className="space-y-1">
                                <div className="flex items-center justify-between text-[8px] font-mono">
                                  <span className="text-slate-400">{language === "de" ? "Schwelle (Threshold):" : "Threshold:"}</span>
                                  <span className="text-violet-400 font-bold">
                                    {compressorActiveBand === "low" ? compLowThreshold : compressorActiveBand === "mid" ? compMidThreshold : compHighThreshold} dB
                                  </span>
                                </div>
                                <div className="flex items-center gap-1.5">
                                  <input
                                    type="range"
                                    min="-40"
                                    max="0"
                                    step="1"
                                    value={compressorActiveBand === "low" ? compLowThreshold : compressorActiveBand === "mid" ? compMidThreshold : compHighThreshold}
                                    onChange={(e) => {
                                      const val = parseInt(e.target.value);
                                      if (compressorActiveBand === "low") setCompLowThreshold(val);
                                      else if (compressorActiveBand === "mid") setCompMidThreshold(val);
                                      else setCompHighThreshold(val);
                                    }}
                                    disabled={!compressorEnabled}
                                    className="flex-1 accent-violet-500 bg-slate-950 h-1 rounded cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed"
                                  />
                                </div>
                              </div>

                              {/* Row 3: Makeup Gain Slider */}
                              <div className="space-y-1">
                                <div className="flex items-center justify-between text-[8px] font-mono">
                                  <span className="text-slate-400">{language === "de" ? "Aufholverstärkung (Makeup):" : "Makeup Gain:"}</span>
                                  <span className="text-emerald-400 font-bold">
                                    +{compressorActiveBand === "low" ? compLowMakeup : compressorActiveBand === "mid" ? compMidMakeup : compHighMakeup} dB
                                  </span>
                                </div>
                                <div className="flex items-center gap-1.5">
                                  <input
                                    type="range"
                                    min="0"
                                    max="12"
                                    step="0.5"
                                    value={compressorActiveBand === "low" ? compLowMakeup : compressorActiveBand === "mid" ? compMidMakeup : compHighMakeup}
                                    onChange={(e) => {
                                      const val = parseFloat(e.target.value);
                                      if (compressorActiveBand === "low") setCompLowMakeup(val);
                                      else if (compressorActiveBand === "mid") setCompMidMakeup(val);
                                      else setCompHighMakeup(val);
                                    }}
                                    disabled={!compressorEnabled}
                                    className="flex-1 accent-emerald-500 bg-slate-950 h-1 rounded cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed"
                                  />
                                </div>
                              </div>
                            </div>

                            {/* Envelopes & Response Column */}
                            <div className="space-y-2 flex flex-col justify-between">
                              <div className="grid grid-cols-2 gap-2">
                                {/* Attack setting */}
                                <div className="space-y-1">
                                  <span className="text-[8px] font-mono text-slate-400 block">{language === "de" ? "Ansprechzeit (Attack):" : "Attack:"}</span>
                                  <div className="flex items-center gap-1 bg-slate-950/70 p-1 rounded border border-slate-900">
                                    <input
                                      type="range"
                                      min="5"
                                      max="100"
                                      step="5"
                                      value={compressorActiveBand === "low" ? compLowAttack : compressorActiveBand === "mid" ? compMidAttack : compHighAttack}
                                      onChange={(e) => {
                                        const val = parseInt(e.target.value);
                                        if (compressorActiveBand === "low") setCompLowAttack(val);
                                        else if (compressorActiveBand === "mid") setCompMidAttack(val);
                                        else setCompHighAttack(val);
                                      }}
                                      disabled={!compressorEnabled}
                                      className="flex-1 accent-violet-500 bg-slate-900 h-1 cursor-pointer"
                                    />
                                    <span className="text-[8px] font-mono text-slate-300 font-bold w-7 text-right">
                                      {compressorActiveBand === "low" ? compLowAttack : compressorActiveBand === "mid" ? compMidAttack : compHighAttack}ms
                                    </span>
                                  </div>
                                </div>

                                {/* Release setting */}
                                <div className="space-y-1">
                                  <span className="text-[8px] font-mono text-slate-400 block">{language === "de" ? "Abfallzeit (Release):" : "Release:"}</span>
                                  <div className="flex items-center gap-1 bg-slate-950/70 p-1 rounded border border-slate-900">
                                    <input
                                      type="range"
                                      min="50"
                                      max="500"
                                      step="10"
                                      value={compressorActiveBand === "low" ? compLowRelease : compressorActiveBand === "mid" ? compMidRelease : compHighRelease}
                                      onChange={(e) => {
                                        const val = parseInt(e.target.value);
                                        if (compressorActiveBand === "low") setCompLowRelease(val);
                                        else if (compressorActiveBand === "mid") setCompMidRelease(val);
                                        else setCompHighRelease(val);
                                      }}
                                      disabled={!compressorEnabled}
                                      className="flex-1 accent-violet-500 bg-slate-900 h-1 cursor-pointer"
                                    />
                                    <span className="text-[8px] font-mono text-slate-300 font-bold w-8 text-right">
                                      {compressorActiveBand === "low" ? compLowRelease : compressorActiveBand === "mid" ? compMidRelease : compHighRelease}ms
                                    </span>
                                  </div>
                                </div>
                              </div>

                              {/* Live Compression Gain Reduction (GR) Meter */}
                              <div className="bg-slate-950/80 p-2 rounded border border-slate-900 space-y-1">
                                <div className="text-[8px] font-mono text-slate-400 uppercase tracking-wider">{language === "de" ? "Pegelabschwächung (GR):" : "Gain Reduction (GR):"}</div>
                                {(() => {
                                  // Calculate simulated attenuation for GR meter
                                  const currentBarIdx = Math.min(23, Math.floor((playheadProgress / audioDuration) * 24));
                                  const rawBarHeight = processedHeights[currentBarIdx] || 0;
                                  
                                  let activeReduction = 0;
                                  if (isPlayingAudio && compressorEnabled && rawBarHeight > noiseGateThreshold) {
                                    const testAmp = rawBarHeight;
                                    let bandAmp = 0;
                                    let bandThreshold = 0;
                                    let bandRatio = 1.0;
                                    
                                    if (compressorActiveBand === "low") {
                                      bandAmp = 0.5 * testAmp;
                                      bandThreshold = compLowThreshold;
                                      bandRatio = compLowRatio;
                                    } else if (compressorActiveBand === "mid") {
                                      bandAmp = 0.3 * testAmp;
                                      bandThreshold = compMidThreshold;
                                      bandRatio = compMidRatio;
                                    } else {
                                      bandAmp = 0.2 * testAmp;
                                      bandThreshold = compHighThreshold;
                                      bandRatio = compHighRatio;
                                    }
                                    
                                    const getDb = (amp: number) => {
                                      if (amp <= 0.001) return -100;
                                      return 20 * Math.log10(amp / 100);
                                    };
                                    
                                    const bandDb = getDb(bandAmp);
                                    if (bandDb > bandThreshold) {
                                      activeReduction = bandDb - (bandThreshold + (bandDb - bandThreshold) / bandRatio);
                                    }
                                  }
                                  
                                  const widthPct = Math.min(100, (activeReduction / 12) * 100);
                                  
                                  return (
                                    <div className="flex items-center gap-1.5 w-full mt-0.5">
                                      {/* GR Bar starts from right and goes left */}
                                      <div className="flex-1 h-2 bg-slate-900 rounded-[1px] relative overflow-hidden flex justify-end">
                                        <div 
                                          className="h-full bg-amber-500/80 transition-all duration-75"
                                          style={{ width: `${isPlayingAudio ? widthPct : 0}%` }}
                                        />
                                      </div>
                                      <span className="text-[8px] text-amber-400 font-bold font-mono min-w-[32px] text-right">
                                        {isPlayingAudio && activeReduction > 0 ? `-${activeReduction.toFixed(1)} dB` : "0.0 dB"}
                                      </span>
                                    </div>
                                  );
                                })()}
                              </div>
                            </div>

                            {/* Column 3: Compression Curve Visual Chart */}
                            {(() => {
                              const T = compressorActiveBand === "low" ? compLowThreshold : compressorActiveBand === "mid" ? compMidThreshold : compHighThreshold;
                              const R = compressorActiveBand === "low" ? compLowRatio : compressorActiveBand === "mid" ? compMidRatio : compHighRatio;
                              const M = compressorActiveBand === "low" ? compLowMakeup : compressorActiveBand === "mid" ? compMidMakeup : compHighMakeup;

                              const clampY = (yVal: number) => Math.max(5, Math.min(95, yVal));
                              const pyA = clampY(90 - (M / 52) * 80);
                              const pyB = clampY(90 - ((T + M + 40) / 52) * 80);
                              const pyC = clampY(90 - ((T - T / R + M + 40) / 52) * 80);
                              const pxB = 10 + ((T + 40) / 40) * 80;

                              // Live input / output coordinates
                              const currentBarIdx = Math.min(23, Math.floor((playheadProgress / audioDuration) * 24));
                              const rawBarHeight = processedHeights[currentBarIdx] || 0;
                              
                              let livePoint = null;
                              if (isPlayingAudio && rawBarHeight > noiseGateThreshold) {
                                const testAmp = rawBarHeight;
                                let bandAmp = 0;
                                if (compressorActiveBand === "low") {
                                  bandAmp = 0.5 * testAmp;
                                } else if (compressorActiveBand === "mid") {
                                  bandAmp = 0.3 * testAmp;
                                } else {
                                  bandAmp = 0.2 * testAmp;
                                }
                                
                                const getDb = (amp: number) => {
                                  if (amp <= 0.001) return -100;
                                  return 20 * Math.log10(amp / 100);
                                };
                                
                                const inputDb = Math.max(-40, Math.min(0, getDb(bandAmp)));
                                let outputDb = inputDb;
                                if (inputDb > T) {
                                  outputDb = T + (inputDb - T) / R;
                                }
                                outputDb += M;
                                
                                const livePx = 10 + ((inputDb + 40) / 40) * 80;
                                const livePy = clampY(90 - ((outputDb + 40) / 52) * 80);
                                livePoint = { px: livePx, py: livePy };
                              }

                              return (
                                <div id="compressor-curve-chart" className="space-y-1.5 flex flex-col justify-between">
                                  <div className="text-[8px] font-mono text-slate-400 uppercase tracking-wider flex items-center justify-between">
                                    <span>{language === "de" ? "Kompressionskurve:" : "Compression Curve:"}</span>
                                    <span className="text-violet-400 font-bold uppercase">{compressorActiveBand} band</span>
                                  </div>
                                  
                                  <div className="flex-1 bg-slate-950 rounded border border-slate-900/60 p-1 flex items-center justify-center relative min-h-[110px]">
                                    <svg viewBox="0 0 100 100" className="w-full h-full max-h-[120px] select-none">
                                      {/* Background Grid */}
                                      {/* -20dB Vertical */}
                                      <line x1={50} y1={10} x2={50} y2={90} stroke="#1e293b" strokeWidth="0.5" strokeDasharray="1,2" />
                                      <text x={50} y={97} fill="#475569" fontSize="5" textAnchor="middle" fontFamily="monospace">-20dB IN</text>

                                      {/* Input Axis Labels */}
                                      <text x={11} y={97} fill="#475569" fontSize="5" textAnchor="start" fontFamily="monospace">-40dB</text>
                                      <text x={89} y={97} fill="#475569" fontSize="5" textAnchor="end" fontFamily="monospace">0dB</text>

                                      {/* -20dB Horizontal */}
                                      <line x1={10} y1={59.23} x2={90} y2={59.23} stroke="#1e293b" strokeWidth="0.5" strokeDasharray="1,2" />
                                      <text x={8} y={60.5} fill="#475569" fontSize="5" textAnchor="end" fontFamily="monospace">-20</text>

                                      {/* 0dB Horizontal */}
                                      <line x1={10} y1={28.46} x2={90} y2={28.46} stroke="#334155" strokeWidth="0.5" strokeDasharray="1,1" />
                                      <text x={8} y={30} fill="#64748b" fontSize="5" textAnchor="end" fontFamily="monospace">0dB</text>

                                      {/* +12dB Horizontal Top */}
                                      <text x={8} y={12} fill="#475569" fontSize="5" textAnchor="end" fontFamily="monospace">+12</text>
                                      
                                      {/* -40dB Horizontal Bottom */}
                                      <text x={8} y={91.5} fill="#475569" fontSize="5" textAnchor="end" fontFamily="monospace">-40</text>

                                      {/* Unity Line (Reference) */}
                                      <line x1={10} y1={90} x2={90} y2={28.46} stroke="#1e293b" strokeWidth="0.75" strokeDasharray="2,2" />

                                      {/* Active Compression Curve Path */}
                                      <path 
                                        d={`M 10 ${pyA} L ${pxB} ${pyB} L 90 ${pyC}`} 
                                        fill="none" 
                                        stroke={compressorEnabled ? "#8b5cf6" : "#475569"} 
                                        strokeWidth={compressorEnabled ? "1.5" : "1"} 
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                      />

                                      {/* Knee Point Marker */}
                                      <circle 
                                        cx={pxB} 
                                        cy={pyB} 
                                        r="2" 
                                        fill={compressorEnabled ? "#a78bfa" : "#64748b"} 
                                        className={compressorEnabled ? "stroke-violet-900 stroke-[1px]" : ""}
                                      />
                                      
                                      {/* Live Point Indicator */}
                                      {livePoint && (
                                        <>
                                          {/* Horizontal guide */}
                                          <line 
                                            x1={10} 
                                            y1={livePoint.py} 
                                            x2={livePoint.px} 
                                            y2={livePoint.py} 
                                            stroke="rgba(139, 92, 246, 0.25)" 
                                            strokeWidth="0.5" 
                                            strokeDasharray="1,1" 
                                          />
                                          {/* Vertical guide */}
                                          <line 
                                            x1={livePoint.px} 
                                            y1={90} 
                                            x2={livePoint.px} 
                                            y2={livePoint.py} 
                                            stroke="rgba(139, 92, 246, 0.25)" 
                                            strokeWidth="0.5" 
                                            strokeDasharray="1,1" 
                                          />
                                          {/* Glowing point */}
                                          <circle 
                                            cx={livePoint.px} 
                                            cy={livePoint.py} 
                                            r="3" 
                                            className="fill-violet-400 opacity-60 animate-ping" 
                                          />
                                          <circle 
                                            cx={livePoint.px} 
                                            cy={livePoint.py} 
                                            r="1.75" 
                                            fill="#c084fc" 
                                            stroke="#ffffff" 
                                            strokeWidth="0.5" 
                                          />
                                        </>
                                      )}
                                    </svg>
                                  </div>
                                </div>
                              );
                            })()}
                          </div>
                        </div>

                        {/* Waveform Visualization + Vertical Peak DB Meter */}
                        <div className="flex gap-2.5 items-stretch h-14 w-full">
                          {/* Left: Waveform Visualization Wrapper */}
                          <div className="flex-1 relative">
                            {/* Floating Video Frame Preview Card */}
                            {(() => {
                              let activePreviewTime = playheadProgress;
                              let previewPositionPct = (playheadProgress / audioDuration) * 100;
                              let isPreviewVisible = isPlayingAudio; // visible when playing

                              if (activeDragHandle === "start") {
                                activePreviewTime = trimStart;
                                previewPositionPct = (trimStart / audioDuration) * 100;
                                isPreviewVisible = true;
                              } else if (activeDragHandle === "end") {
                                activePreviewTime = trimEnd;
                                previewPositionPct = (trimEnd / audioDuration) * 100;
                                isPreviewVisible = true;
                              } else if (isHoveringWaveform && hoveredTime !== null) {
                                activePreviewTime = hoveredTime;
                                previewPositionPct = (hoveredTime / audioDuration) * 100;
                                isPreviewVisible = true;
                              }

                              const activeFrame = getCapturedFrame(activePreviewTime, audioDuration);
                              let previewSource = language === "de" ? "ABSPIELEN" : "PLAYBACK";
                              if (activeDragHandle === "start") {
                                previewSource = language === "de" ? "ZUSCHNITT ANFANG" : "TRIM START";
                              } else if (activeDragHandle === "end") {
                                previewSource = language === "de" ? "ZUSCHNITT ENDE" : "TRIM END";
                              } else if (isHoveringWaveform) {
                                previewSource = language === "de" ? "SUCHEN" : "SCRUBBING";
                              }

                              return (
                                <AnimatePresence>
                                  {isPreviewVisible && (
                                    <motion.div
                                      initial={{ opacity: 0, y: -8, scale: 0.95 }}
                                      animate={{ opacity: 1, y: -4, scale: 1 }}
                                      exit={{ opacity: 0, y: -8, scale: 0.95 }}
                                      transition={{ duration: 0.12 }}
                                      className="absolute bottom-full mb-1.5 z-50 pointer-events-none select-none"
                                      style={{
                                        left: `${previewPositionPct}%`,
                                        transform: "translateX(-50%)",
                                      }}
                                    >
                                      {/* Triangle Arrow pointing down */}
                                      <div className="absolute bottom-[-5px] left-1/2 -translate-x-1/2 w-2.5 h-2.5 rotate-45 bg-slate-900 border-r border-b border-slate-800 z-10" />

                                      {/* Preview Frame Box */}
                                      <div className="w-56 bg-slate-900/95 border border-slate-800 rounded-lg shadow-[0_12px_30px_rgba(0,0,0,0.8)] overflow-hidden backdrop-blur-md text-[10px] text-slate-200">
                                        {/* Video Aspect Screen (16:10 for extra height) */}
                                        <div className="relative w-full aspect-[16/10] bg-slate-950 overflow-hidden border-b border-slate-800">
                                          <img 
                                            src={activeFrame.imageUrl} 
                                            alt={activeFrame.title} 
                                            className="w-full h-full object-cover opacity-90"
                                            referrerPolicy="no-referrer"
                                          />
                                          {/* Video overlays */}
                                          {/* Top left indicator */}
                                          <div className="absolute top-1.5 left-2 flex items-center gap-1 bg-slate-950/75 backdrop-blur-[2px] px-1.5 py-0.5 rounded-full border border-slate-800/45">
                                            <span className={`h-1.5 w-1.5 rounded-full ${previewSource.includes("PLAY") || previewSource.includes("ABSP") ? "bg-red-500 animate-pulse" : "bg-cyan-400 animate-ping"}`} />
                                            <span className="text-[7.5px] font-mono font-bold tracking-wider text-white uppercase">{previewSource}</span>
                                          </div>

                                          {/* Top right camera indicator */}
                                          <div className="absolute top-1.5 right-2 bg-slate-950/70 backdrop-blur-[2px] px-1 py-0.5 rounded text-[7px] font-mono text-slate-400">
                                            {activeFrame.cameraInfo}
                                          </div>

                                          {/* Camera viewfinder grids/corner brackets */}
                                          <div className="absolute inset-2 border-l border-t border-white/20 w-1.5 h-1.5 pointer-events-none" />
                                          <div className="absolute inset-y-2 right-2 border-r border-t border-white/20 w-1.5 h-1.5 pointer-events-none" />
                                          <div className="absolute inset-x-2 bottom-2 border-l border-b border-white/20 w-1.5 h-1.5 pointer-events-none" />
                                          <div className="absolute bottom-2 right-2 border-r border-b border-white/20 w-1.5 h-1.5 pointer-events-none" />

                                          {/* Timecode overlay centered at bottom */}
                                          <div className="absolute bottom-1.5 left-1/2 -translate-x-1/2 bg-slate-950/80 backdrop-blur-[2px] px-2 py-0.5 rounded border border-slate-800 text-[8px] font-mono text-fcb-gold tracking-widest font-bold shadow">
                                            {activeFrame.timecode}
                                          </div>
                                        </div>

                                        {/* Text Info Area */}
                                        <div className="p-2 space-y-0.5 bg-slate-950/50">
                                          <div className="flex items-center justify-between">
                                            <h4 className="font-bold text-white text-[10.5px] truncate max-w-[130px]">{activeFrame.title}</h4>
                                            <span className="text-[8px] font-mono text-slate-400">FR: {activeFrame.frameNo}</span>
                                          </div>
                                          <p className="text-[8px] font-mono text-fcb-gold font-bold uppercase tracking-wide">{activeFrame.subtitle}</p>
                                          <p className="text-[8.5px] text-slate-400 leading-snug font-sans line-clamp-2 pt-0.5 border-t border-slate-900/60 mt-0.5">
                                            {activeFrame.description}
                                          </p>
                                        </div>
                                      </div>
                                    </motion.div>
                                  )}
                                </AnimatePresence>
                              );
                            })()}

                            {/* Waveform Area */}
                            <div
                              ref={visualizerRef}
                              className="w-full h-full relative bg-slate-900/60 rounded border border-slate-900/80 overflow-hidden flex items-end justify-between px-2 py-1 select-none"
                              onMouseMove={handleWaveformMouseMove}
                              onMouseEnter={handleWaveformMouseEnter}
                              onMouseLeave={handleWaveformMouseLeave}
                            >
                              {/* 24-Bar Custom Waveform */}
                              {processedHeights.map((heightPct, idx) => {
                                const barTime = (idx / 24) * audioDuration;
                                const isInRange = barTime >= trimStart && barTime <= trimEnd;
                                const isPlayed = isPlayingAudio && playheadProgress >= barTime;
                                
                                // Check if bar falls into Fade In or Fade Out zone
                                const isFadeInZone = isInRange && barTime <= (trimStart + fadeInDuration);
                                const isFadeOutZone = isInRange && barTime >= (trimEnd - fadeOutDuration);

                                const isGated = heightPct < noiseGateThreshold;
                                const isSilent = heightPct < silenceThreshold;

                                let barColor = "#1e293b"; // Slate (Out of crop)
                                let opacity = "1.0";
                                
                                if (isGated) {
                                  barColor = "#475569"; // Gated slate gray
                                  opacity = isInRange ? "0.15" : "0.05";
                                } else if (isPlayed) {
                                  barColor = "#eab308"; // Gold (Playhead passed)
                                } else if (isInRange) {
                                  if (isSilent) {
                                    barColor = "#f59e0b"; // Warning amber/orange for active silence
                                    opacity = "0.4"; // dimmer opacity to represent silence
                                  } else if (isFadeInZone) {
                                    barColor = "#06b6d4"; // Cyan (Fade In volume ramp)
                                  } else if (isFadeOutZone) {
                                    barColor = "#a855f7"; // Purple/Magenta (Fade Out volume ramp)
                                  } else {
                                    barColor = "#dc2626"; // Red (Peak fully-unfaded volume)
                                  }
                                } else {
                                  // Out of active trim range
                                  if (isSilent) {
                                    opacity = "0.2";
                                  }
                                }

                                return (
                                  <div
                                    key={idx}
                                    className="w-[3%] rounded-t transition-colors duration-150 relative group"
                                    style={{
                                      height: `${heightPct}%`,
                                      backgroundColor: barColor,
                                      opacity: opacity
                                    }}
                                  >
                                    <span className="absolute bottom-full left-1/2 transform -translate-x-1/2 bg-slate-900 border border-slate-800 text-slate-300 text-[8px] font-mono px-1.5 py-0.5 rounded opacity-0 group-hover:opacity-100 transition pointer-events-none mb-1 z-30 whitespace-nowrap shadow-md">
                                      {heightPct}%{isGated ? " (GATED)" : isSilent ? " (SILENT)" : ""}
                                    </span>
                                  </div>
                                );
                              })}

                              {/* Moving Playhead Marker */}
                              {isPlayingAudio && (
                                <div
                                  className="absolute top-0 bottom-0 w-[1.5px] bg-fcb-gold z-10 transition-all duration-75"
                                  style={{
                                    left: `${(playheadProgress / audioDuration) * 100}%`
                                  }}
                                />
                              )}

                              {/* Left Trim Handle Visual Cover */}
                              <div
                                className="absolute left-0 top-0 bottom-0 bg-slate-950/70 border-r border-slate-800 pointer-events-none"
                                style={{
                                  width: `${(trimStart / audioDuration) * 100}%`
                                }}
                              />

                              {/* Right Trim Handle Visual Cover */}
                              <div
                                className="absolute right-0 top-0 bottom-0 bg-slate-950/70 border-l border-slate-800 pointer-events-none"
                                style={{
                                  width: `${(1 - trimEnd / audioDuration) * 100}%`
                                }}
                              />

                              {/* Draggable Left Handle (trimStart) */}
                              <div
                                className={`absolute top-0 bottom-0 w-5 -ml-2.5 z-40 group flex items-center justify-center ${
                                  isTrimLocked ? "cursor-not-allowed" : "cursor-ew-resize"
                                }`}
                                style={{
                                  left: `${(trimStart / audioDuration) * 100}%`
                                }}
                                onMouseDown={handleStartDrag}
                                onTouchStart={handleStartDrag}
                                title={
                                  isTrimLocked
                                    ? language === "de"
                                      ? "Zuschnitt gesperrt (Sperre oben aufheben)"
                                      : "Trim locked (Unlock above to adjust)"
                                    : language === "de"
                                    ? "Zuschnitt-Anfang ziehen"
                                    : "Drag Trim Start"
                                }
                                id="trimmer-handle-start"
                              >
                                {/* Glowing Vertical Line */}
                                <div className={`w-[2px] h-full transition-colors ${
                                  isTrimLocked 
                                    ? "bg-slate-600 shadow-none" 
                                    : "bg-cyan-400 group-hover:bg-cyan-300 shadow-[0_0_6px_rgba(34,211,238,0.7)]"
                                }`} />
                                {/* Grab Handle Pill */}
                                <div className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-2.5 h-6 rounded border flex flex-col gap-[1.5px] items-center justify-center shadow-lg transition-colors ${
                                  isTrimLocked
                                    ? "bg-slate-700 border-slate-800"
                                    : "bg-cyan-500 hover:bg-cyan-400 border-slate-950"
                                }`}>
                                  <span className={`w-0.5 h-1.5 rounded-full ${isTrimLocked ? "bg-slate-900/45" : "bg-slate-950/60"}`} />
                                  <span className={`w-0.5 h-1.5 rounded-full ${isTrimLocked ? "bg-slate-900/45" : "bg-slate-950/60"}`} />
                                </div>
                              </div>

                              {/* Draggable Right Handle (trimEnd) */}
                              <div
                                className={`absolute top-0 bottom-0 w-5 -ml-2.5 z-40 group flex items-center justify-center ${
                                  isTrimLocked ? "cursor-not-allowed" : "cursor-ew-resize"
                                }`}
                                style={{
                                  left: `${(trimEnd / audioDuration) * 100}%`
                                }}
                                onMouseDown={handleEndDrag}
                                onTouchStart={handleEndDrag}
                                title={
                                  isTrimLocked
                                    ? language === "de"
                                      ? "Zuschnitt gesperrt (Sperre oben aufheben)"
                                      : "Trim locked (Unlock above to adjust)"
                                    : language === "de"
                                    ? "Zuschnitt-Ende ziehen"
                                    : "Drag Trim End"
                                }
                                id="trimmer-handle-end"
                              >
                                {/* Glowing Vertical Line */}
                                <div className={`w-[2px] h-full transition-colors ${
                                  isTrimLocked
                                    ? "bg-slate-600 shadow-none"
                                    : "bg-purple-400 group-hover:bg-purple-300 shadow-[0_0_6px_rgba(168,85,247,0.7)]"
                                }`} />
                                {/* Grab Handle Pill */}
                                <div className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-2.5 h-6 rounded border flex flex-col gap-[1.5px] items-center justify-center shadow-lg transition-colors ${
                                  isTrimLocked
                                    ? "bg-slate-700 border-slate-800"
                                    : "bg-purple-500 hover:bg-purple-400 border-slate-950"
                                }`}>
                                  <span className={`w-0.5 h-1.5 rounded-full ${isTrimLocked ? "bg-slate-900/45" : "bg-slate-950/60"}`} />
                                  <span className={`w-0.5 h-1.5 rounded-full ${isTrimLocked ? "bg-slate-900/45" : "bg-slate-950/60"}`} />
                                </div>
                              </div>

                              {/* Visual Fade-In End Marker Line (Dashed Cyan) */}
                              {trimStart + fadeInDuration < trimEnd && (
                                <div
                                  className="absolute top-0 bottom-0 border-r border-dashed border-cyan-400/80 z-20 pointer-events-none flex flex-col justify-start"
                                  style={{
                                    left: `${((trimStart + fadeInDuration) / audioDuration) * 100}%`
                                  }}
                                >
                                  <span className="text-[7px] text-cyan-400 font-mono px-1 py-0.5 bg-slate-950/90 rounded border border-cyan-500/20 mt-1 whitespace-nowrap scale-90 origin-left">
                                    ▲ {language === "de" ? "Fade-In Ende" : "Fade End"}
                                  </span>
                                </div>
                              )}

                              {/* Visual Fade-Out Start Marker Line (Dashed Purple) */}
                              {trimEnd - fadeOutDuration > trimStart && (
                                <div
                                  className="absolute top-0 bottom-0 border-l border-dashed border-purple-400/80 z-20 pointer-events-none flex flex-col justify-start"
                                  style={{
                                    left: `${((trimEnd - fadeOutDuration) / audioDuration) * 100}%`
                                  }}
                                >
                                  <span className="text-[7px] text-purple-400 font-mono px-1 py-0.5 bg-slate-950/90 rounded border border-purple-500/20 mt-1 whitespace-nowrap scale-90 origin-right ml-[-45px]">
                                    ▼ {language === "de" ? "Fade-Out Start" : "Fade Start"}
                                  </span>
                                </div>
                              )}

                              {/* Visual Suggested Start Line (Dotted Amber) */}
                              {suggestedStartS > 0 && suggestedStartS < audioDuration && (
                                <div
                                  className="absolute top-0 bottom-0 border-r-2 border-dotted border-amber-500/50 z-20 pointer-events-none flex flex-col justify-end"
                                  style={{
                                    left: `${(suggestedStartS / audioDuration) * 100}%`
                                  }}
                                >
                                  <span className="text-[6.5px] text-amber-400 font-mono px-1 py-0.5 bg-slate-950/90 rounded border border-amber-500/20 mb-1 whitespace-nowrap scale-90 origin-left">
                                    ✂ {language === "de" ? "Opt. Start" : "Opt. Start"} ({suggestedStartS.toFixed(1)}s)
                                  </span>
                                </div>
                              )}

                              {/* Visual Suggested End Line (Dotted Amber) */}
                              {suggestedEndS > 0 && suggestedEndS < audioDuration && (
                                <div
                                  className="absolute top-0 bottom-0 border-l-2 border-dotted border-amber-500/50 z-20 pointer-events-none flex flex-col justify-end"
                                  style={{
                                    left: `${(suggestedEndS / audioDuration) * 100}%`
                                  }}
                                >
                                  <span className="text-[6.5px] text-amber-400 font-mono px-1 py-0.5 bg-slate-950/90 rounded border border-amber-500/20 mb-1 whitespace-nowrap scale-90 origin-right ml-[-45px]">
                                    ✂ {language === "de" ? "Opt. Ende" : "Opt. End"} ({suggestedEndS.toFixed(1)}s)
                                  </span>
                                </div>
                              )}
                            </div>
                          </div>

                          {/* Right: Vertical Decibel Peak Meter */}
                          {(() => {
                            const currentBarIdx = Math.min(23, Math.floor((playheadProgress / audioDuration) * 24));
                            const currentBarHeight = processedHeights[currentBarIdx] || 0;

                            let realTimeAmp = 0;
                            if (isPlayingAudio) {
                              const elapsedInTrim = playheadProgress - trimStart;
                              const trimDuration = trimEnd - trimStart;
                              let envelopeMultiplier = 1.0;
                              
                              if (elapsedInTrim < fadeInDuration && fadeInDuration > 0) {
                                envelopeMultiplier = elapsedInTrim / fadeInDuration;
                              } else if (elapsedInTrim > trimDuration - fadeOutDuration && fadeOutDuration > 0) {
                                envelopeMultiplier = (trimDuration - elapsedInTrim) / fadeOutDuration;
                              }
                              
                              // Apply Noise Gate
                              if (currentBarHeight < noiseGateThreshold) {
                                realTimeAmp = 0;
                              } else {
                                realTimeAmp = currentBarHeight;
                                // Apply Silence dampening
                                if (currentBarHeight < silenceThreshold) {
                                  realTimeAmp *= 0.15;
                                }
                                realTimeAmp *= envelopeMultiplier;

                                if (compressorEnabled) {
                                  // Split realTimeAmp into simulated Low/Mid/High band components
                                  const ampLow = 0.5 * realTimeAmp;
                                  const ampMid = 0.3 * realTimeAmp;
                                  const ampHigh = 0.2 * realTimeAmp;
                                  
                                  const getDb = (amp: number) => {
                                    if (amp <= 0.001) return -100;
                                    return 20 * Math.log10(amp / 100); // normalized against 100% full scale
                                  };
                                  
                                  // Compute compressed amplitudes
                                  let finalLow = ampLow;
                                  const dbLow = getDb(ampLow);
                                  if (dbLow > compLowThreshold) {
                                    const excess = dbLow - compLowThreshold;
                                    const compressedExcess = excess / compLowRatio;
                                    finalLow = Math.pow(10, (compLowThreshold + compressedExcess + compLowMakeup) / 20) * 100;
                                  } else {
                                    finalLow = ampLow * Math.pow(10, compLowMakeup / 20);
                                  }
                                  
                                  let finalMid = ampMid;
                                  const dbMid = getDb(ampMid);
                                  if (dbMid > compMidThreshold) {
                                    const excess = dbMid - compMidThreshold;
                                    const compressedExcess = excess / compMidRatio;
                                    finalMid = Math.pow(10, (compMidThreshold + compressedExcess + compMidMakeup) / 20) * 100;
                                  } else {
                                    finalMid = ampMid * Math.pow(10, compMidMakeup / 20);
                                  }
                                  
                                  let finalHigh = ampHigh;
                                  const dbHigh = getDb(ampHigh);
                                  if (dbHigh > compHighThreshold) {
                                    const excess = dbHigh - compHighThreshold;
                                    const compressedExcess = excess / compHighRatio;
                                    finalHigh = Math.pow(10, (compHighThreshold + compressedExcess + compHighMakeup) / 20) * 100;
                                  } else {
                                    finalHigh = ampHigh * Math.pow(10, compHighMakeup / 20);
                                  }
                                  
                                  realTimeAmp = finalLow + finalMid + finalHigh;
                                }
                              }
                            }

                            // Convert to decibels (0 to 100 max scale)
                            const currentDb = realTimeAmp > 0 ? 20 * Math.log10(realTimeAmp / 100) : -40; // -40dB floor
                            const meterFillPct = Math.max(0, Math.min(100, ((currentDb - (-40)) / 40) * 100));

                            return (
                              <div 
                                id="decibel-peak-meter"
                                className="w-14 bg-slate-900/40 border border-slate-900/80 rounded p-1 flex items-center gap-1.5 justify-between relative select-none"
                                title={language === "de" ? "Echtzeit-Pegelanzeige (dB)" : "Real-time Decibel Peak Meter"}
                              >
                                {/* DB Ticks & Labels */}
                                <div className="flex flex-col justify-between h-full text-[6.5px] font-mono text-slate-500 text-right leading-none py-0.5 w-[14px]">
                                  <span>0dB</span>
                                  <span>-12</span>
                                  <span>-24</span>
                                  <span>-40</span>
                                </div>

                                {/* Meter Bar Track */}
                                <div className="flex-1 h-full bg-slate-950/80 rounded-[2px] border border-slate-900 relative overflow-hidden flex flex-col justify-end">
                                  {/* LED Meter Fill */}
                                  <div 
                                    className="w-full bg-gradient-to-t from-emerald-500 via-amber-400 to-rose-500 rounded-b-[1px] transition-all duration-75 origin-bottom"
                                    style={{ height: `${isPlayingAudio ? meterFillPct : 0}%` }}
                                  />
                                  {/* Peak Floating Tick */}
                                  {isPlayingAudio && meterFillPct > 0 && (
                                    <div 
                                      className="absolute left-0 right-0 h-[1.5px] bg-white shadow-sm z-10"
                                      style={{ bottom: `calc(${meterFillPct}% - 1.5px)` }}
                                    />
                                  )}
                                </div>
                              </div>
                            );
                          })()}
                        </div>

                        {/* Waveform Color Legend */}
                        <div className="flex flex-wrap items-center justify-between gap-x-2 gap-y-1 bg-slate-950 p-1.5 rounded border border-slate-900/60 text-[8px] font-mono text-slate-400">
                          <div className="flex items-center gap-1">
                            <span className="h-1.5 w-1.5 rounded-full bg-red-600" />
                            <span>{language === "de" ? "Peak-Signal" : "Peak Signal"}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <span className="h-1.5 w-1.5 rounded-full bg-cyan-400" />
                            <span>Fade In</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <span className="h-1.5 w-1.5 rounded-full bg-purple-500" />
                            <span>Fade Out</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <span className="h-1.5 w-1.5 rounded-full bg-amber-500 opacity-40" />
                            <span>{language === "de" ? "Detektierte Stille" : "Silent Zones"}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <span className="h-1.5 w-1.5 rounded-full bg-yellow-400" />
                            <span>{language === "de" ? "Wiedergabe" : "Playhead"}</span>
                          </div>
                        </div>

                        {/* Trimming Sliders */}
                        <div className="space-y-2 text-[10px] border-b border-slate-900 pb-2">
                          <div className="space-y-0.5">
                            <div className="flex justify-between text-slate-500 font-mono text-[9px]">
                              <span>{language === "de" ? "Startzeit" : "Trim Start"}</span>
                              <span className="text-slate-300 font-bold">{trimStart.toFixed(1)}s</span>
                            </div>
                            <input
                              type="range"
                              min="0"
                              max={(trimEnd - 0.5).toFixed(1)}
                              step="0.1"
                              value={trimStart}
                              onChange={(e) => {
                                const val = parseFloat(parseFloat(e.target.value).toFixed(1));
                                setTrimStart(val);
                                setPlayheadProgress(val);
                              }}
                              className="w-full accent-fcb-red bg-slate-900 h-1 rounded cursor-pointer"
                            />
                          </div>

                          <div className="space-y-0.5">
                            <div className="flex justify-between text-slate-500 font-mono text-[9px]">
                              <span>{language === "de" ? "Endzeit" : "Trim End"}</span>
                              <span className="text-slate-300 font-bold">{trimEnd.toFixed(1)}s</span>
                            </div>
                            <input
                              type="range"
                              min={(trimStart + 0.5).toFixed(1)}
                              max={audioDuration.toFixed(1)}
                              step="0.1"
                              value={trimEnd}
                              onChange={(e) => {
                                const val = parseFloat(parseFloat(e.target.value).toFixed(1));
                                setTrimEnd(val);
                                if (playheadProgress > val) {
                                  setPlayheadProgress(trimStart);
                                }
                              }}
                              className="w-full accent-fcb-red bg-slate-900 h-1 rounded cursor-pointer"
                            />
                          </div>
                        </div>

                        {/* Fade Settings Controllers */}
                        <div className="bg-slate-950/40 p-2 rounded border border-slate-900 grid grid-cols-2 gap-3">
                          <div className="space-y-1">
                            <div className="flex justify-between text-slate-400 font-mono text-[8.5px]">
                              <span className="flex items-center gap-1">
                                <span className="h-1.5 w-1.5 rounded-full bg-cyan-400" />
                                {language === "de" ? "Einblendung" : "Fade-In Duration"}
                              </span>
                              <span className="text-cyan-400 font-bold font-mono">{fadeInDuration.toFixed(1)}s</span>
                            </div>
                            <input
                              type="range"
                              min="0.0"
                              max={Math.min(3.0, parseFloat(((trimEnd - trimStart) / 2).toFixed(1)))}
                              step="0.1"
                              value={fadeInDuration}
                              onChange={(e) => {
                                setFadeInDuration(parseFloat(parseFloat(e.target.value).toFixed(1)));
                              }}
                              className="w-full accent-cyan-400 bg-slate-900 h-1 rounded cursor-pointer"
                            />
                          </div>

                          <div className="space-y-1">
                            <div className="flex justify-between text-slate-400 font-mono text-[8.5px]">
                              <span className="flex items-center gap-1">
                                <span className="h-1.5 w-1.5 rounded-full bg-purple-400" />
                                {language === "de" ? "Ausblendung" : "Fade-Out Duration"}
                              </span>
                              <span className="text-purple-400 font-bold font-mono">{fadeOutDuration.toFixed(1)}s</span>
                            </div>
                            <input
                              type="range"
                              min="0.0"
                              max={Math.min(3.0, parseFloat(((trimEnd - trimStart) / 2).toFixed(1)))}
                              step="0.1"
                              value={fadeOutDuration}
                              onChange={(e) => {
                                setFadeOutDuration(parseFloat(parseFloat(e.target.value).toFixed(1)));
                              }}
                              className="w-full accent-purple-400 bg-slate-900 h-1 rounded cursor-pointer"
                            />
                          </div>
                        </div>

                        {/* Audio Export Metadata Panel */}
                        {(() => {
                          const estBytes = 44 + Math.floor((trimEnd - trimStart) * 16000) * 2;
                          const estSizeStr = estBytes >= 1024 * 1024 
                            ? `${(estBytes / (1024 * 1024)).toFixed(2)} MB`
                            : `${(estBytes / 1024).toFixed(2)} KB`;
                          
                          return (
                            <div 
                              id="trimmer-metadata-panel"
                              className="bg-slate-950/70 border border-slate-900 rounded p-2 text-[9px] font-mono text-slate-400 space-y-1"
                            >
                              <div className="text-[8px] text-slate-500 font-bold uppercase tracking-wider border-b border-slate-900 pb-1 mb-1 flex items-center justify-between">
                                <span>{language === "de" ? "Signal-Metadaten" : "Signal & File Metadata"}</span>
                                <span className="text-cyan-400">WAV PCM</span>
                              </div>
                              <div className="grid grid-cols-2 gap-x-3 gap-y-1">
                                <div className="flex justify-between">
                                  <span>{language === "de" ? "Abtastrate:" : "Sample Rate:"}</span>
                                  <span className="text-slate-200 font-bold">16,000 Hz</span>
                                </div>
                                <div className="flex justify-between">
                                  <span>{language === "de" ? "Bittiefe:" : "Bit Depth:"}</span>
                                  <span className="text-slate-200 font-bold">16-bit Mono</span>
                                </div>
                                <div className="flex justify-between col-span-2 border-t border-slate-900/40 pt-1 mt-0.5">
                                  <span>{language === "de" ? "Berechnete Größe:" : "Est. File Size:"}</span>
                                  <span className="text-amber-400 font-bold">{estSizeStr} <span className="text-slate-500 font-normal">({estBytes.toLocaleString()} Bytes)</span></span>
                                </div>
                              </div>
                            </div>
                          );
                        })()}

                        {/* Playback & Action Buttons */}
                        <div className="grid grid-cols-4 gap-1 pt-0.5">
                          <button
                            onClick={() => {
                              if (isPlayingAudio) {
                                setIsPlayingAudio(false);
                              } else {
                                setPlayheadProgress(trimStart);
                                setIsPlayingAudio(true);
                              }
                            }}
                            className="py-1 bg-slate-900 hover:bg-slate-850 border border-slate-800 rounded-md text-[9.5px] font-mono text-slate-300 hover:text-white flex items-center justify-center gap-1 cursor-pointer transition"
                          >
                            {isPlayingAudio ? (
                              <>
                                <div className="h-2 w-2 bg-yellow-500 rounded-sm animate-pulse" />
                                <span>{language === "de" ? "Pause" : "Pause"}</span>
                              </>
                            ) : (
                              <>
                                <Play className="h-3 w-3 text-fcb-gold" />
                                <span>{language === "de" ? "Spielen" : "Play Trim"}</span>
                              </>
                            )}
                          </button>

                          <button
                            id="replay-selection-btn"
                            onClick={() => {
                              setPlayheadProgress(trimStart);
                              setIsPlayingAudio(true);
                              handleAddLog({
                                id: `replay-${Date.now()}`,
                                timestamp: new Date().toLocaleTimeString(),
                                level: "INFO",
                                source: "Audio Engine",
                                message: `Replay selection triggered: playback instantly reset to start of trim bounds (${trimStart.toFixed(1)}s) and playing to ${trimEnd.toFixed(1)}s.`
                              });
                            }}
                            className="py-1 bg-slate-900 hover:bg-slate-850 border border-slate-800 rounded-md text-[9.5px] font-mono text-slate-300 hover:text-white flex items-center justify-center gap-1 cursor-pointer transition"
                            title={language === "de" ? "Wiederholen von Trim-Anfang" : "Replay from Trim Start"}
                          >
                            <RotateCcw className="h-3 w-3 text-cyan-400" />
                            <span>{language === "de" ? "Wdh." : "Replay"}</span>
                          </button>

                          <button
                            onClick={() => {
                              setCroppedSuccessfully(true);
                              setIsPlayingAudio(false);
                              handleAddLog({
                                id: `trim-${Date.now()}`,
                                timestamp: new Date().toLocaleTimeString(),
                                level: "SUCCESS",
                                source: "Audio Trimmer",
                                message: `Grounded speech signal cropped with fades applied: Trimmed to ${(trimEnd - trimStart).toFixed(1)}s window. Fade-in: ${fadeInDuration.toFixed(1)}s, Fade-out: ${fadeOutDuration.toFixed(1)}s.`
                              });
                            }}
                            className={`py-1 border border-slate-800 rounded-md text-[9.5px] font-mono flex items-center justify-center gap-1 cursor-pointer transition ${
                              croppedSuccessfully 
                                ? "bg-emerald-950/40 border-emerald-500/30 text-emerald-400"
                                : "bg-slate-900 hover:bg-slate-850 text-slate-300 hover:text-white"
                            }`}
                          >
                            <Scissors className="h-3 w-3 text-cyan-400" />
                            <span>{croppedSuccessfully ? (language === "de" ? "Beschnitten" : "Cropped!") : (language === "de" ? "Zuschneiden" : "Crop")}</span>
                          </button>

                          <button
                            id="export-trimmed-audio-btn"
                            onClick={exportTrimmedAudio}
                            className="py-1 bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-amber-500/30 text-slate-300 hover:text-white rounded-md text-[9.5px] font-mono flex items-center justify-center gap-1 cursor-pointer transition"
                            title={language === "de" ? "Als .wav-Datei exportieren" : "Export as .wav file"}
                          >
                            <Download className="h-3 w-3 text-amber-500" />
                            <span>{language === "de" ? "Exportieren" : "Export WAV"}</span>
                          </button>
                        </div>

                        {/* Apply & Execute */}
                        <button
                          onClick={() => {
                            handleAddLog({
                              id: `voice-run-${Date.now()}`,
                              timestamp: new Date().toLocaleTimeString(),
                              level: "INFO",
                              source: "Audio Engine",
                              message: `Compiling cropped speech signal... Running voice parser on [${trimStart.toFixed(1)}s - ${trimEnd.toFixed(1)}s] window with volume ramps: Fade In (${fadeInDuration.toFixed(1)}s), Fade Out (${fadeOutDuration.toFixed(1)}s).`
                            });
                            executeVoiceCommand(transcript);
                            
                            // Reset state
                            setAudioDuration(0);
                            setTranscript("");
                            setCroppedSuccessfully(false);
                          }}
                          className="w-full py-1.5 bg-gradient-to-r from-fcb-red to-red-600 hover:from-red-600 hover:to-red-700 text-white font-mono text-[9px] font-bold uppercase tracking-wider rounded-lg flex items-center justify-center gap-1 cursor-pointer active:scale-98 transition"
                        >
                          <Check className="h-3 w-3" />
                          <span>{language === "de" ? "Zuschnitt anwenden & Starten" : "Apply & Execute"}</span>
                        </button>

                        {/* Keyboard Shortcuts Helper Modal (contained within trimmer container) */}
                        <AnimatePresence>
                          {showShortcutsModal && (
                            <motion.div
                              initial={{ opacity: 0, scale: 0.95 }}
                              animate={{ opacity: 1, scale: 1 }}
                              exit={{ opacity: 0, scale: 0.95 }}
                              transition={{ duration: 0.15 }}
                              className="absolute inset-0 bg-slate-950/95 backdrop-blur-xs z-40 p-4 flex flex-col justify-between border border-slate-800 rounded-lg"
                            >
                              <div>
                                <div className="flex items-center justify-between border-b border-slate-900 pb-2 mb-3">
                                  <span className="text-[10px] font-mono font-bold text-fcb-gold flex items-center gap-1.5 uppercase tracking-wide">
                                    <Keyboard className="h-3.5 w-3.5 text-fcb-gold" />
                                    {language === "de" ? "Tastaturkürzel-Hilfe" : "Keyboard Shortcuts Helper"}
                                  </span>
                                  <button
                                    onClick={() => setShowShortcutsModal(false)}
                                    className="p-1 text-slate-400 hover:text-white hover:bg-slate-900 rounded cursor-pointer transition"
                                  >
                                    <X className="h-3.5 w-3.5" />
                                  </button>
                                </div>

                                <div className="space-y-2 pb-2">
                                  {/* Row 1 */}
                                  <div className="flex items-center justify-between text-[10px] font-mono border-b border-slate-900/40 pb-1.5">
                                    <span className="text-slate-400">{language === "de" ? "Abspielen / Pause" : "Play / Pause Trim Segment"}</span>
                                    <div className="flex items-center gap-1">
                                      <kbd className="px-1.5 py-0.5 bg-slate-900 border border-slate-800 rounded text-[9px] text-slate-300 font-sans shadow-sm">Space</kbd>
                                    </div>
                                  </div>

                                  {/* Row 2 */}
                                  <div className="flex items-center justify-between text-[10px] font-mono border-b border-slate-900/40 pb-1.5">
                                    <span className="text-slate-400">{language === "de" ? "Zuschnitt-Grenzen verschieben" : "Nudge Trim Boundaries"}</span>
                                    <div className="flex items-center gap-1">
                                      <kbd className="px-1 py-0.5 bg-slate-900 border border-slate-800 rounded text-[9px] text-slate-300 font-sans shadow-sm">←</kbd>
                                      <span className="text-slate-600">/</span>
                                      <kbd className="px-1 py-0.5 bg-slate-900 border border-slate-800 rounded text-[9px] text-slate-300 font-sans shadow-sm">→</kbd>
                                      <span className="text-[9px] text-slate-500 ml-1">(0.1s)</span>
                                    </div>
                                  </div>

                                  {/* Row 3 */}
                                  <div className="flex items-center justify-between text-[10px] font-mono border-b border-slate-900/40 pb-1.5">
                                    <span className="text-slate-400">{language === "de" ? "Als .wav-Datei exportieren" : "Export as WAV File"}</span>
                                    <div className="flex items-center gap-1">
                                      <kbd className="px-1 py-0.5 bg-slate-900 border border-slate-800 rounded text-[9px] text-slate-300 font-sans shadow-sm">Ctrl</kbd>
                                      <span className="text-slate-600 text-[8px]">+</span>
                                      <kbd className="px-1 py-0.5 bg-slate-900 border border-slate-800 rounded text-[9px] text-slate-300 font-sans shadow-sm">E</kbd>
                                      <span className="text-slate-500 text-[8px]">{language === "de" ? "oder" : "or"}</span>
                                      <kbd className="px-1 py-0.5 bg-slate-900 border border-slate-800 rounded text-[9px] text-slate-300 font-sans shadow-sm">⌘</kbd>
                                      <span className="text-slate-600 text-[8px]">+</span>
                                      <kbd className="px-1 py-0.5 bg-slate-900 border border-slate-800 rounded text-[9px] text-slate-300 font-sans shadow-sm">E</kbd>
                                    </div>
                                  </div>

                                  {/* Row 4: Undo */}
                                  <div className="flex items-center justify-between text-[10px] font-mono border-b border-slate-900/40 pb-1.5">
                                    <span className="text-slate-400">{language === "de" ? "Änderung rückgängig" : "Undo Trim/Fade Change"}</span>
                                    <div className="flex items-center gap-1">
                                      <kbd className="px-1 py-0.5 bg-slate-900 border border-slate-800 rounded text-[9px] text-slate-300 font-sans shadow-sm">Ctrl</kbd>
                                      <span className="text-slate-600 text-[8px]">+</span>
                                      <kbd className="px-1 py-0.5 bg-slate-900 border border-slate-800 rounded text-[9px] text-slate-300 font-sans shadow-sm">Z</kbd>
                                      <span className="text-slate-500 text-[8px]">{language === "de" ? "oder" : "or"}</span>
                                      <kbd className="px-1 py-0.5 bg-slate-900 border border-slate-800 rounded text-[9px] text-slate-300 font-sans shadow-sm">⌘</kbd>
                                      <span className="text-slate-600 text-[8px]">+</span>
                                      <kbd className="px-1 py-0.5 bg-slate-900 border border-slate-800 rounded text-[9px] text-slate-300 font-sans shadow-sm">Z</kbd>
                                    </div>
                                  </div>

                                  {/* Row 5: Redo */}
                                  <div className="flex items-center justify-between text-[10px] font-mono border-b border-slate-900/40 pb-1.5">
                                    <span className="text-slate-400">{language === "de" ? "Änderung wiederholen" : "Redo Trim/Fade Change"}</span>
                                    <div className="flex items-center gap-1">
                                      <kbd className="px-1 py-0.5 bg-slate-900 border border-slate-800 rounded text-[9px] text-slate-300 font-sans shadow-sm">Ctrl</kbd>
                                      <span className="text-slate-600 text-[8px]">+</span>
                                      <kbd className="px-1 py-0.5 bg-slate-900 border border-slate-800 rounded text-[9px] text-slate-300 font-sans shadow-sm">Y</kbd>
                                      <span className="text-slate-500 text-[8px]">{language === "de" ? "oder" : "or"}</span>
                                      <kbd className="px-1 py-0.5 bg-slate-900 border border-slate-800 rounded text-[9px] text-slate-300 font-sans shadow-sm">⌘</kbd>
                                      <span className="text-slate-600 text-[8px]">+</span>
                                      <kbd className="px-1 py-0.5 bg-slate-900 border border-slate-800 rounded text-[9px] text-slate-300 font-sans shadow-sm">Y</kbd>
                                    </div>
                                  </div>
                                </div>
                              </div>

                              <div className="flex justify-end border-t border-slate-900 pt-2.5">
                                <button
                                  onClick={() => setShowShortcutsModal(false)}
                                  className="px-3 py-1 bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white rounded text-[10px] font-mono cursor-pointer transition"
                                >
                                  {language === "de" ? "Schließen" : "Dismiss"}
                                </button>
                              </div>
                            </motion.div>
                          )}
                        </AnimatePresence>

                        {/* Export Summary Modal */}
                        <AnimatePresence>
                          {showExportSummaryModal && (() => {
                            const totalDuration = Math.max(0, trimEnd - trimStart);
                            const sampleRate = 16000;
                            const bitDepth = 16;
                            const bitrate = 256; // kbps
                            const numSamples = Math.floor(totalDuration * sampleRate);
                            const fileSizeBytes = 44 + numSamples * 2;
                            const fileSizeKb = (fileSizeBytes / 1024).toFixed(2);

                            const calcReduction = (threshold: number, ratio: number) => {
                              if (!compressorEnabled) return 0.0;
                              if (0 > threshold) {
                                const excess = 0 - threshold;
                                const compressedExcess = excess / ratio;
                                return excess - compressedExcess;
                              }
                              return 0.0;
                            };

                            const lowRed = calcReduction(compLowThreshold, compLowRatio);
                            const midRed = calcReduction(compMidThreshold, compMidRatio);
                            const highRed = calcReduction(compHighThreshold, compHighRatio);

                            const heights = [35, 20, 55, 30, 85, 45, 40, 75, 95, 55, 30, 65, 85, 45, 75, 30, 55, 20, 45, 65, 30, 55, 40, 20];
                            const maxVal = Math.max(...heights);
                            const normMultiplier = isNormalized ? (100 / maxVal) : 1.0;
                            const origHeights = heights.map(h => Math.min(100, Math.round(h * normMultiplier)));
                            const compHeights = heights.map((h, idx) => {
                              const processedHeight = Math.min(100, Math.round(h * normMultiplier));
                              const inputDb = (processedHeight / 100) * 40 - 40;

                              let threshold = 0;
                              let ratio = 1;
                              let makeup = 0;

                              if (idx < 8) {
                                threshold = compLowThreshold;
                                ratio = compLowRatio;
                                makeup = compLowMakeup;
                              } else if (idx < 16) {
                                threshold = compMidThreshold;
                                ratio = compMidRatio;
                                makeup = compMidMakeup;
                              } else {
                                threshold = compHighThreshold;
                                ratio = compHighRatio;
                                makeup = compHighMakeup;
                              }

                              if (compressorEnabled) {
                                if (inputDb > threshold) {
                                  const excess = inputDb - threshold;
                                  const compressedExcess = excess / ratio;
                                  let outputDb = threshold + compressedExcess;
                                  outputDb += makeup;
                                  return Math.max(2, Math.min(100, Math.round(((outputDb + 40) / 40) * 100)));
                                } else {
                                  let outputDb = inputDb + makeup;
                                  return Math.max(2, Math.min(100, Math.round(((outputDb + 40) / 40) * 100)));
                                }
                              }
                              return processedHeight;
                            });

                            return (
                              <motion.div
                                initial={{ opacity: 0, scale: 0.95 }}
                                animate={{ opacity: 1, scale: 1 }}
                                exit={{ opacity: 0, scale: 0.95 }}
                                transition={{ duration: 0.15 }}
                                className="absolute inset-x-4 top-4 bottom-4 md:inset-x-8 md:top-8 md:bottom-8 bg-slate-950/98 backdrop-blur-xs z-40 p-4 md:p-5 flex flex-col justify-between border border-slate-800 rounded-lg shadow-2xl"
                                id="export-summary-modal"
                              >
                                {/* Title Header Bar (Persistent) */}
                                <div className="flex items-center justify-between border-b border-slate-900 pb-2 mb-3 shrink-0">
                                  <span className="text-[10.5px] font-mono font-bold text-cyan-400 flex items-center gap-1.5 uppercase tracking-wide">
                                    <Info className="h-4 w-4 text-cyan-400" />
                                    {language === "de" ? "Export-Parameter & Audio-Profil" : "Calculated Export Summary"}
                                  </span>
                                  <button
                                    onClick={() => setShowExportSummaryModal(false)}
                                    className="p-1 text-slate-400 hover:text-white hover:bg-slate-900 rounded cursor-pointer transition"
                                    id="export-summary-close-x"
                                  >
                                    <X className="h-4 w-4" />
                                  </button>
                                </div>

                                {/* Main Two-Column View Layout (Scrollable container) */}
                                <div className="grid grid-cols-1 md:grid-cols-12 gap-5 overflow-y-auto pr-1 select-none scrollbar-thin flex-1 pb-2">
                                  
                                  {/* Left Column (md:col-span-6): File Parameters, Presets, Waveforms */}
                                  <div className="md:col-span-6 space-y-3">
                                    {/* Basic calculated parameters */}
                                    <div className="grid grid-cols-2 gap-2 text-[9.5px] font-mono">
                                      <div className="bg-slate-900/50 p-2 rounded border border-slate-900 flex flex-col justify-between">
                                        <span className="text-slate-500 text-[8px] uppercase">{language === "de" ? "Bittiefe & Format" : "Bit Depth & Format"}</span>
                                        <span className="text-slate-200 font-bold">{bitDepth}-bit Mono PCM (WAV)</span>
                                      </div>
                                      <div className="bg-slate-900/50 p-2 rounded border border-slate-900 flex flex-col justify-between">
                                        <span className="text-slate-500 text-[8px] uppercase">{language === "de" ? "Abtastrate" : "Sample Rate"}</span>
                                        <span className="text-slate-200 font-bold">16,000 Hz (16 kHz)</span>
                                      </div>
                                      <div className="bg-slate-900/50 p-2 rounded border border-slate-900 flex flex-col justify-between">
                                        <span className="text-slate-500 text-[8px] uppercase">{language === "de" ? "Exakte Bitrate" : "Exact Bit-rate"}</span>
                                        <span className="text-slate-200 font-bold">{bitrate} kbps</span>
                                      </div>
                                      <div className="bg-slate-900/50 p-2 rounded border border-slate-900 flex flex-col justify-between">
                                        <span className="text-slate-500 text-[8px] uppercase">{language === "de" ? "Endgültige Dauer" : "Total File Duration"}</span>
                                        <span className="text-emerald-400 font-bold">{totalDuration.toFixed(2)}s</span>
                                      </div>
                                      <div className="bg-slate-900/50 p-2 rounded border border-slate-900 flex flex-col justify-between col-span-2">
                                        <span className="text-slate-500 text-[8px] uppercase">{language === "de" ? "Geschätzte Dateigröße" : "Estimated File Size"}</span>
                                        <span className="text-amber-400 font-bold">{fileSizeKb} KB ({fileSizeBytes.toLocaleString()} Bytes)</span>
                                      </div>
                                    </div>

                                    {/* Gain Reduction Profile Summary Table */}
                                    <div className="space-y-1.5 text-left">
                                      <span className="text-[8.5px] font-mono text-cyan-400/80 font-bold uppercase tracking-wider block text-left">
                                        {language === "de" ? "Angewendetes Pegelreduktionsprofil:" : "Applied Gain Reduction Profile:"}
                                      </span>
                                      <div className="border border-slate-900 rounded overflow-hidden">
                                        <table className="w-full text-left font-mono text-[8.5px]">
                                          <thead>
                                            <tr className="bg-slate-900 text-slate-400 border-b border-slate-800">
                                              <th className="p-1">{language === "de" ? "Band" : "Band"}</th>
                                              <th className="p-1">{language === "de" ? "Schw. (dB)" : "Thresh"}</th>
                                              <th className="p-1">{language === "de" ? "Verh." : "Ratio"}</th>
                                              <th className="p-1">{language === "de" ? "Gain" : "Makeup"}</th>
                                              <th className="p-1 text-right">{language === "de" ? "Max Red." : "Max Red."}</th>
                                            </tr>
                                          </thead>
                                          <tbody className="divide-y divide-slate-950 bg-slate-950/40">
                                            <tr className="text-slate-300">
                                              <td className="p-1 font-bold text-cyan-500">{language === "de" ? "Tief (Bass)" : "Low (<250Hz)"}</td>
                                              <td className="p-1">{compLowThreshold} dB</td>
                                              <td className="p-1">{compLowRatio.toFixed(1)}:1</td>
                                              <td className="p-1">+{compLowMakeup} dB</td>
                                              <td className="p-1 text-right text-rose-400 font-semibold">
                                                {compressorEnabled ? `-${lowRed.toFixed(1)} dB` : "0.0 dB"}
                                              </td>
                                            </tr>
                                            <tr className="text-slate-300">
                                              <td className="p-1 font-bold text-violet-400">{language === "de" ? "Mitte (Speech)" : "Mid (250-4k)"}</td>
                                              <td className="p-1">{compMidThreshold} dB</td>
                                              <td className="p-1">{compMidRatio.toFixed(1)}:1</td>
                                              <td className="p-1">+{compMidMakeup} dB</td>
                                              <td className="p-1 text-right text-rose-400 font-semibold">
                                                {compressorEnabled ? `-${midRed.toFixed(1)} dB` : "0.0 dB"}
                                              </td>
                                            </tr>
                                            <tr className="text-slate-300">
                                              <td className="p-1 font-bold text-amber-500">{language === "de" ? "Hoch (Sibil.)" : "High (>4kHz)"}</td>
                                              <td className="p-1">{compHighThreshold} dB</td>
                                              <td className="p-1">{compHighRatio.toFixed(1)}:1</td>
                                              <td className="p-1">+{compHighMakeup} dB</td>
                                              <td className="p-1 text-right text-rose-400 font-semibold">
                                                {compressorEnabled ? `-${highRed.toFixed(1)} dB` : "0.0 dB"}
                                              </td>
                                            </tr>
                                          </tbody>
                                        </table>
                                      </div>
                                      {!compressorEnabled && (
                                        <p className="text-[7.5px] text-rose-400 italic font-mono text-left">
                                          * {language === "de" 
                                            ? "Hinweis: Der Kompressor ist derzeit umgangen/deaktiviert." 
                                            : "Note: Multiband Compressor is currently bypassed/disabled."}
                                        </p>
                                      )}
                                    </div>

                                    {/* Presets and custom saving */}
                                    <div className="space-y-2 p-2 rounded border border-slate-900 bg-slate-900/40 text-left" id="export-presets-container">
                                      <div className="flex items-center justify-between border-b border-slate-950 pb-1 flex-wrap gap-2">
                                        <span className="text-[8.5px] font-mono text-cyan-400 font-bold uppercase tracking-wider flex items-center gap-1">
                                          <Save className="h-3 w-3 text-cyan-500 animate-pulse" />
                                          {language === "de" ? "Export-Presets:" : "Export Presets:"}
                                        </span>
                                      </div>

                                      {/* 'Quick-Switch' category navigation bar */}
                                      <div 
                                        id="export-presets-quick-switch" 
                                        className="flex items-center gap-1.5 overflow-x-auto pb-1.5 scrollbar-thin border-b border-slate-950/40"
                                      >
                                        <span className="text-[7.5px] font-mono text-slate-500 font-bold uppercase select-none shrink-0 pr-1 border-r border-slate-900/60">
                                          {language === "de" ? "Schnellwahl:" : "Quick-Switch:"}
                                        </span>
                                        <div className="flex items-center gap-1">
                                          {Array.from(new Set([
                                            "All",
                                            "Technical",
                                            "Creative",
                                            ...customCategoryPaths,
                                            ...exportPresets.map(p => p.category)
                                          ])).filter(Boolean).map((cat) => {
                                            const isSel = exportPresetCategoryFilter === cat;
                                            const count = getCategoryPresetCount(cat);
                                            
                                            // Format the display label beautifully with nesting indicators
                                            const categorySegments = cat.split("/");
                                            const displayName = categorySegments.map((seg) => {
                                              if (seg === "All") return language === "de" ? "Alle" : "All";
                                              if (seg === "Technical") return language === "de" ? "Technisch" : "Technical";
                                              if (seg === "Creative") return language === "de" ? "Kreativ" : "Creative";
                                              return seg;
                                            }).join(" › ");

                                            return (
                                              <button
                                                key={cat}
                                                id={`export-preset-quick-btn-${cat.toLowerCase().replace(/[^a-z0-9]/g, '-')}`}
                                                type="button"
                                                onClick={() => setExportPresetCategoryFilter(cat)}
                                                className={`px-1.5 py-0.5 rounded text-[7.5px] font-mono font-bold flex items-center gap-1 transition cursor-pointer select-none whitespace-nowrap border ${
                                                  isSel 
                                                    ? "bg-cyan-600/20 border-cyan-500/50 text-cyan-300 shadow-[0_0_8px_rgba(6,182,212,0.15)]" 
                                                    : "bg-slate-950/60 border-slate-900/60 text-slate-500 hover:text-slate-300 hover:border-slate-800"
                                                }`}
                                              >
                                                <span>{displayName}</span>
                                                <span className={`text-[6.5px] px-0.5 py-[0.5px] rounded font-bold ${
                                                  isSel ? "bg-cyan-500/30 text-cyan-200" : "bg-slate-900 text-slate-600"
                                                }`}>
                                                  {count}
                                                </span>
                                              </button>
                                            );
                                          })}
                                        </div>
                                      </div>
                                      
                                      {/* Search Input Bar for Real-time preset filtering */}
                                      <div className="relative" id="export-presets-search-container">
                                        <input
                                          type="text"
                                          value={exportPresetSearchQuery}
                                          onChange={(e) => setExportPresetSearchQuery(e.target.value)}
                                          placeholder={language === "de" ? "Suchen nach Name oder Kategorie..." : "Search presets by name or category..."}
                                          className="w-full bg-slate-950 border border-slate-900 rounded pl-7 pr-6 py-1 text-[8.5px] font-mono text-white placeholder:text-slate-600 focus:outline-none focus:border-cyan-500 transition"
                                        />
                                        <Search className="absolute left-2 top-1.5 h-3.5 w-3.5 text-slate-600 pointer-events-none" />
                                        {exportPresetSearchQuery && (
                                          <button
                                            onClick={() => setExportPresetSearchQuery("")}
                                            className="absolute right-1.5 top-1.5 text-slate-500 hover:text-white hover:bg-slate-900 p-0.5 rounded cursor-pointer transition"
                                          >
                                            <X className="h-3 w-3" />
                                          </button>
                                        )}
                                      </div>
                                      
                                      {/* Hierarchical Folder Structure representation */}
                                      <div className="space-y-2 max-h-[175px] overflow-y-auto pr-1 scrollbar-thin border border-slate-950 bg-slate-950/20 p-1.5 rounded" id="export-presets-folder-tree">
                                        {(() => {
                                          const filteredPresetsForTree = exportPresets.filter(p => {
                                            if (!exportPresetSearchQuery) return true;
                                            const q = exportPresetSearchQuery.toLowerCase();
                                            return (
                                              p.name?.toLowerCase().includes(q) || 
                                              p.category?.toLowerCase().includes(q)
                                            );
                                          });
                                          const rootNode = buildPresetTree(filteredPresetsForTree, customCategoryPaths);
                                          const displayNode = findSubNode(rootNode, exportPresetCategoryFilter);
                                          
                                          if (exportPresetCategoryFilter !== "All" && displayNode) {
                                            const hasSubfolders = Object.keys(displayNode.subfolders).length > 0;
                                            const hasPresets = displayNode.presets.length > 0;
                                            
                                            if (!hasSubfolders && !hasPresets) {
                                              return (
                                                <div className="text-center py-4 text-slate-500 text-[8.5px] font-mono">
                                                  {language === "de" ? "Keine Presets in dieser Kategorie." : "No presets in this category."}
                                                </div>
                                              );
                                            }
                                            
                                            return (
                                              <div className="space-y-1">
                                                <div className="flex items-center gap-1.5 px-1 py-0.5 border-b border-slate-900 pb-1 mb-1.5 text-slate-400 font-mono text-[8px] uppercase tracking-wider">
                                                  <Folder className="h-2.5 w-2.5 text-cyan-400 fill-cyan-400/10" />
                                                  <span>{exportPresetCategoryFilter}</span>
                                                </div>

                                                {renderFolderNode(displayNode, 0)}
                                                
                                                {displayNode.presets.length > 0 && (
                                                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 pt-1.5">
                                                    {displayNode.presets.map((preset) => renderPresetCard(preset))}
                                                  </div>
                                                )}
                                              </div>
                                            );
                                          }

                                          return (
                                            <div className="space-y-1">
                                              {/* Action to add root category */}
                                              <div className="flex justify-between items-center px-1 border-b border-slate-900/60 pb-1 mb-1 text-[8px] font-mono text-slate-500 uppercase tracking-wider">
                                                <span>{language === "de" ? "Verzeichnisse" : "Directories"}</span>
                                                <button
                                                  type="button"
                                                  onClick={() => {
                                                    setInTreeCategoryCreatePath("");
                                                    setInTreeCategoryInputValue("");
                                                  }}
                                                  className="text-cyan-500 hover:text-cyan-400 flex items-center gap-0.5 cursor-pointer hover:underline transition"
                                                  title={language === "de" ? "Hauptkategorie erstellen" : "Create root category"}
                                                >
                                                  <FolderPlus className="h-3 w-3" />
                                                  <span>{language === "de" ? "+ Hauptkategorie" : "+ Root Folder"}</span>
                                                </button>
                                              </div>

                                              {/* Root category inline creator */}
                                              {inTreeCategoryCreatePath === "" && (
                                                <div className="flex items-center gap-1.5 py-1 px-1.5 bg-slate-900/40 border border-slate-850 rounded mb-1.5">
                                                  <input
                                                    type="text"
                                                    value={inTreeCategoryInputValue}
                                                    onChange={(e) => setInTreeCategoryInputValue(e.target.value)}
                                                    placeholder={language === "de" ? "Neue Hauptkategorie..." : "New root category..."}
                                                    className="flex-1 bg-slate-950 border border-slate-800 text-slate-300 text-[8px] rounded px-1.5 py-0.5 font-mono outline-none"
                                                    maxLength={18}
                                                    autoFocus
                                                    onKeyDown={(e) => {
                                                      if (e.key === "Enter") {
                                                        handleCreateInTreeCategory("");
                                                      } else if (e.key === "Escape") {
                                                        setInTreeCategoryCreatePath(null);
                                                      }
                                                    }}
                                                  />
                                                  <button
                                                    type="button"
                                                    onClick={() => handleCreateInTreeCategory("")}
                                                    className="p-0.5 text-emerald-400 hover:bg-slate-800 rounded cursor-pointer"
                                                  >
                                                    <Check className="h-3 w-3" />
                                                  </button>
                                                  <button
                                                    type="button"
                                                    onClick={() => setInTreeCategoryCreatePath(null)}
                                                    className="p-0.5 text-rose-400 hover:bg-slate-800 rounded cursor-pointer"
                                                  >
                                                    <X className="h-3 w-3" />
                                                  </button>
                                                </div>
                                              )}

                                              {/* Actual tree nodes */}
                                              {renderFolderNode(rootNode, 0)}

                                              {/* Root-level presets */}
                                              {rootNode.presets.length > 0 && (
                                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 pt-1">
                                                  {rootNode.presets.map((preset) => renderPresetCard(preset))}
                                                </div>
                                              )}
                                            </div>
                                          );
                                        })()}
                                      </div>

                                      {/* Preset Saving Controls */}
                                      <div className="flex items-center gap-1.5 pt-1.5 border-t border-slate-900/60 mt-1 flex-wrap md:flex-nowrap">
                                        <input
                                          id="preset-save-name-input"
                                          type="text"
                                          value={newPresetName}
                                          onChange={(e) => setNewPresetName(e.target.value)}
                                          placeholder={language === "de" ? "Preset Name (z.B. Podcast-Mix)..." : "Preset Name (e.g., Podcast Mix)..."}
                                          className="flex-1 min-w-[120px] bg-slate-950 border border-slate-800 text-slate-200 text-[8.5px] rounded px-1.5 py-0.5 outline-none font-mono placeholder:text-slate-600"
                                          maxLength={24}
                                        />
                                        
                                        <div className="flex items-center gap-1.5" id="preset-save-category-wrapper">
                                          <span className="text-[7.5px] font-mono text-slate-500">{language === "de" ? "Kat:" : "Cat:"}</span>
                                          <select
                                            id="preset-save-category-select"
                                            value={presetSaveParentCategory}
                                            onChange={(e) => setPresetSaveParentCategory(e.target.value)}
                                            className="bg-slate-950 border border-slate-800 text-slate-300 rounded px-1 py-0.5 text-[7.5px] font-mono cursor-pointer outline-none max-w-[110px]"
                                          >
                                            <option value="">{language === "de" ? "Hauptverzeichnis" : "Root (None)"}</option>
                                            {Array.from(new Set([
                                              "Technical", 
                                              "Creative", 
                                              ...customCategoryPaths, 
                                              ...exportPresets.map(p => p.category)
                                            ])).map(cat => {
                                              const depth = cat.split("/").length - 1;
                                              const displayName = "\u00A0\u00A0".repeat(depth) + (depth > 0 ? "└ " : "") + cat.split("/").pop();
                                              return (
                                                <option key={cat} value={cat}>
                                                  {displayName}
                                                </option>
                                              );
                                            })}
                                          </select>

                                          {/* Hierarchical Subcategory Input Field */}
                                          <input
                                            id="preset-save-custom-category-input"
                                            type="text"
                                            value={presetSaveNewSubcategory}
                                            onChange={(e) => setPresetSaveNewSubcategory(e.target.value)}
                                            placeholder={language === "de" ? "Neue Kat..." : "New category..."}
                                            className="w-[85px] bg-slate-950 border border-slate-800 text-slate-300 rounded px-1.5 py-0.5 text-[7.5px] font-mono outline-none placeholder:text-slate-700"
                                            maxLength={18}
                                            title={language === "de" ? "Unterkategorie im ausgewählten Ordner erstellen" : "Create subcategory inside selected folder"}
                                          />
                                        </div>

                                        <button
                                          id="preset-save-btn"
                                          onClick={handleSaveExportPreset}
                                          className="px-2 py-0.5 bg-cyan-600 hover:bg-cyan-500 text-white text-[8.5px] rounded font-semibold flex items-center gap-1 cursor-pointer transition select-none font-mono text-xs"
                                          title={language === "de" ? "Aktuelle Einstellungen speichern (Strg+S)" : "Save current settings (Ctrl+S)"}
                                        >
                                          <Save className="h-2.5 w-2.5" />
                                          {language === "de" ? "Sichern" : "Save"}
                                        </button>
                                      </div>
                                    </div>

                                    {/* Waveform comparative views */}
                                    <div className="space-y-2 p-2 rounded border border-slate-900 bg-slate-900/20 text-left" id="export-before-after-waveform-comparison">
                                      <div className="flex items-center justify-between flex-wrap gap-2 min-h-[14px]">
                                        <span className="text-[8.5px] font-mono text-cyan-400/80 font-bold uppercase tracking-wider block">
                                          {language === "de" ? "Signal-Kompression: Vorher vs. Nachher:" : "Signal Compression: Before vs. After:"}
                                        </span>
                                        {hoveredWaveformBarIdx !== null && origHeights[hoveredWaveformBarIdx] !== undefined && compHeights[hoveredWaveformBarIdx] !== undefined && (
                                          <div className="text-[8px] font-mono text-cyan-300 bg-cyan-950/60 px-1.5 py-0.5 rounded border border-cyan-800/40 flex items-center gap-1.5 leading-none">
                                            <span className="text-slate-500 font-bold">
                                              {language === "de" ? "Pos:" : "Pos:"} {((hoveredWaveformBarIdx / 24) * audioDuration).toFixed(1)}s
                                            </span>
                                            <span className="text-rose-400 font-bold">
                                              {language === "de" ? "Vorher:" : "Before:"} {origHeights[hoveredWaveformBarIdx]}%
                                            </span>
                                            <span className="text-slate-600">→</span>
                                            <span className="text-emerald-400 font-bold">
                                              {language === "de" ? "Nachher:" : "After:"} {compHeights[hoveredWaveformBarIdx]}%
                                            </span>
                                            <span className={`font-bold text-[7.5px] ${compHeights[hoveredWaveformBarIdx] - origHeights[hoveredWaveformBarIdx] >= 0 ? "text-cyan-400" : "text-amber-400"}`}>
                                              ({compHeights[hoveredWaveformBarIdx] - origHeights[hoveredWaveformBarIdx] >= 0 ? "+" : ""}{(compHeights[hoveredWaveformBarIdx] - origHeights[hoveredWaveformBarIdx]).toFixed(0)}%)
                                            </span>
                                          </div>
                                        )}
                                      </div>
                                      <div className="grid grid-cols-2 gap-3">
                                        <div className="space-y-1 bg-slate-950/40 p-1.5 rounded border border-slate-950">
                                          <div className="flex items-center justify-between text-[7.5px] font-mono text-slate-500">
                                            <span>{language === "de" ? "VORHER (Original)" : "BEFORE (Original)"}</span>
                                            <span className="text-slate-400">Peak: {Math.max(...origHeights)}%</span>
                                          </div>
                                          <div className="h-[38px] flex items-end justify-between gap-0.5 relative px-1 py-0.5 select-none bg-slate-950/80 rounded border border-slate-900/40">
                                            {origHeights.map((h, idx) => {
                                              const barTime = (idx / 24) * audioDuration;
                                              const isInRange = barTime >= trimStart && barTime <= trimEnd;
                                              const isHovered = hoveredWaveformBarIdx === idx;
                                              return (
                                                <div
                                                  key={idx}
                                                  onMouseEnter={() => setHoveredWaveformBarIdx(idx)}
                                                  onMouseLeave={() => setHoveredWaveformBarIdx(null)}
                                                  className={`w-[3.5%] rounded-t transition-all duration-150 cursor-crosshair ${
                                                    isHovered ? "ring-1 ring-white/50 scale-y-110" : ""
                                                  }`}
                                                  style={{
                                                    height: `${h}%`,
                                                    backgroundColor: isHovered 
                                                      ? "#f87171" 
                                                      : (isInRange ? "#ef4444" : "#475569"),
                                                    opacity: isHovered ? 1 : (isInRange ? 0.95 : 0.2)
                                                  }}
                                                  title={language === "de" 
                                                    ? `Zeit: ${barTime.toFixed(2)}s\nVorher (Original): ${h}%\nNachher (Komprimiert): ${compHeights[idx]}%\nDifferenz: ${compHeights[idx] - h >= 0 ? "+" : ""}${compHeights[idx] - h}%`
                                                    : `Time: ${barTime.toFixed(2)}s\nBefore (Original): ${h}%\nAfter (Compressed): ${compHeights[idx]}%\nDifference: ${compHeights[idx] - h >= 0 ? "+" : ""}${compHeights[idx] - h}%`
                                                  }
                                                />
                                              );
                                            })}
                                          </div>
                                        </div>

                                        <div className="space-y-1 bg-slate-950/40 p-1.5 rounded border border-slate-950">
                                          <div className="flex items-center justify-between text-[7.5px] font-mono text-slate-500">
                                            <span>{language === "de" ? "NACHHER (Komprimiert)" : "AFTER (Compressed)"}</span>
                                            <span className="text-emerald-400">Peak: {Math.max(...compHeights)}%</span>
                                          </div>
                                          <div className="h-[38px] flex items-end justify-between gap-0.5 relative px-1 py-0.5 select-none bg-slate-950/80 rounded border border-slate-900/40">
                                            {compHeights.map((h, idx) => {
                                              const barTime = (idx / 24) * audioDuration;
                                              const isInRange = barTime >= trimStart && barTime <= trimEnd;
                                              const isHovered = hoveredWaveformBarIdx === idx;
                                              return (
                                                <div
                                                  key={idx}
                                                  onMouseEnter={() => setHoveredWaveformBarIdx(idx)}
                                                  onMouseLeave={() => setHoveredWaveformBarIdx(null)}
                                                  className={`w-[3.5%] rounded-t transition-all duration-150 cursor-crosshair ${
                                                    isHovered ? "ring-1 ring-white/50 scale-y-110" : ""
                                                  }`}
                                                  style={{
                                                    height: `${h}%`,
                                                    backgroundColor: isHovered 
                                                      ? "#34d399" 
                                                      : (isInRange ? "#10b981" : "#334155"),
                                                    opacity: isHovered ? 1 : (isInRange ? 0.95 : 0.15)
                                                  }}
                                                  title={language === "de" 
                                                    ? `Zeit: ${barTime.toFixed(2)}s\nVorher (Original): ${origHeights[idx]}%\nNachher (Komprimiert): ${h}%\nDifferenz: ${h - origHeights[idx] >= 0 ? "+" : ""}${h - origHeights[idx]}%`
                                                    : `Time: ${barTime.toFixed(2)}s\nBefore (Original): ${origHeights[idx]}%\nAfter (Compressed): ${h}%\nDifference: ${h - origHeights[idx] >= 0 ? "+" : ""}${h - origHeights[idx]}%`
                                                  }
                                                />
                                              );
                                            })}
                                          </div>
                                        </div>
                                      </div>
                                      <p className="text-[7.5px] text-slate-500 leading-snug font-mono">
                                        {language === "de"
                                          ? "Visualisiert die Bändigung lauter Spitzen & Anhebung leiser Pegel innerhalb des Schnittfensters."
                                          : "Visualizes the taming of loud peaks and gain enhancement for quiet passages inside your crop range."}
                                      </p>
                                    </div>
                                  </div>

                                  {/* Right Column: Live Compression Curve Workspace with Interactive Sliders */}
                                  <div className="md:col-span-6 flex flex-col bg-slate-900/20 border border-slate-900/85 rounded-lg p-3 space-y-3.5 text-left" id="export-live-compression-workspace">
                                    <div className="flex items-center justify-between border-b border-slate-900/60 pb-1.5 shrink-0">
                                      <span className="text-[8.5px] font-mono text-cyan-400 font-bold uppercase tracking-wider flex items-center gap-1">
                                        <Sliders className="h-3 w-3 text-cyan-500" />
                                        {language === "de" ? "Interaktiver DSP-Kurven-Editor:" : "Interactive DSP Curve Editor:"}
                                      </span>
                                      
                                      <button
                                        onClick={() => {
                                          setCompressorEnabled(!compressorEnabled);
                                          handleAddLog({
                                            id: `export-comp-toggle-${Date.now()}`,
                                            timestamp: new Date().toLocaleTimeString(),
                                            source: "DSP Editor",
                                            level: "INFO",
                                            message: language === "de"
                                              ? `Kompressor im Editor ${!compressorEnabled ? "aktiviert" : "umgangen"}.`
                                              : `Compressor in editor ${!compressorEnabled ? "activated" : "bypassed"}.`
                                          });
                                        }}
                                        className={`px-1.5 py-0.5 rounded text-[8px] font-mono font-bold transition flex items-center gap-1 cursor-pointer select-none border ${
                                          compressorEnabled 
                                            ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20" 
                                            : "bg-rose-500/10 text-rose-400 border-rose-500/20"
                                        }`}
                                      >
                                        <div className={`w-1 h-1 rounded-full ${compressorEnabled ? "bg-emerald-400 animate-ping" : "bg-rose-400"}`} />
                                        {compressorEnabled 
                                          ? (language === "de" ? "AKTIV" : "ACTIVE") 
                                          : (language === "de" ? "BYPASS" : "BYPASS")}
                                      </button>
                                    </div>

                                    {/* Band Tabs Selector */}
                                    <div className="grid grid-cols-3 gap-1 bg-slate-950 p-1 rounded border border-slate-900 shrink-0" id="export-comp-band-tabs">
                                      {(["low", "mid", "high"] as const).map((band) => {
                                        const isSel = compressorActiveBand === band;
                                        const bandLabel = band === "low" 
                                          ? (language === "de" ? "TIEF (Bass)" : "LOW (Bass)") 
                                          : band === "mid" 
                                            ? (language === "de" ? "MITTE (Mitten)" : "MID (Speech)") 
                                            : (language === "de" ? "HOCH (Höhen)" : "HIGH (Sibil.)");
                                        const tabColorClass = band === "low" 
                                          ? (isSel ? "bg-cyan-500/20 text-cyan-300 border-cyan-500/40" : "text-slate-500 hover:text-cyan-400/80")
                                          : band === "mid"
                                            ? (isSel ? "bg-violet-500/20 text-violet-300 border-violet-500/40" : "text-slate-500 hover:text-violet-400/80")
                                            : (isSel ? "bg-amber-500/20 text-amber-300 border-amber-500/40" : "text-slate-500 hover:text-amber-400/80");

                                        return (
                                          <button
                                            key={band}
                                            onClick={() => setCompressorActiveBand(band)}
                                            className={`px-2 py-1 rounded text-[8.5px] font-mono font-bold transition border border-transparent cursor-pointer select-none text-center ${tabColorClass}`}
                                          >
                                            {bandLabel}
                                          </button>
                                        );
                                      })}
                                    </div>

                                    {(() => {
                                      const getBandSettings = () => {
                                        if (compressorActiveBand === "low") {
                                          return {
                                            thresh: compLowThreshold,
                                            setThresh: setCompLowThreshold,
                                            ratio: compLowRatio,
                                            setRatio: setCompLowRatio,
                                            makeup: compLowMakeup,
                                            setMakeup: setCompLowMakeup,
                                            color: "text-cyan-400 border-cyan-500/30",
                                            accentBg: "bg-cyan-500/10",
                                            accentText: "text-cyan-400",
                                            stroke: "#22d3ee" // cyan-400
                                          };
                                        } else if (compressorActiveBand === "mid") {
                                          return {
                                            thresh: compMidThreshold,
                                            setThresh: setCompMidThreshold,
                                            ratio: compMidRatio,
                                            setRatio: setCompMidRatio,
                                            makeup: compMidMakeup,
                                            setMakeup: setCompMidMakeup,
                                            color: "text-violet-400 border-violet-500/30",
                                            accentBg: "bg-violet-500/10",
                                            accentText: "text-violet-400",
                                            stroke: "#a78bfa" // violet-400
                                          };
                                        } else {
                                          return {
                                            thresh: compHighThreshold,
                                            setThresh: setCompHighThreshold,
                                            ratio: compHighRatio,
                                            setRatio: setCompHighRatio,
                                            makeup: compHighMakeup,
                                            setMakeup: setCompHighMakeup,
                                            color: "text-amber-400 border-amber-500/30",
                                            accentBg: "bg-amber-500/10",
                                            accentText: "text-amber-400",
                                            stroke: "#fbbf24" // amber-400
                                          };
                                        }
                                      };

                                      const activeProps = getBandSettings();
                                      const T = activeProps.thresh;
                                      const R = activeProps.ratio;
                                      const M = activeProps.makeup;

                                      const clampY = (yVal: number) => Math.max(5, Math.min(95, yVal));
                                      
                                      const pyA = clampY(90 - (M / 52) * 80);
                                      const pyB = clampY(90 - ((T + M + 40) / 52) * 80);
                                      const pyC = clampY(90 - ((T - T / R + M + 40) / 52) * 80);
                                      const pxB = 20 + ((T + 40) / 40) * 120;

                                      return (
                                        <div className="space-y-3 flex-1 flex flex-col justify-between overflow-hidden">
                                          <div className="bg-slate-950/80 rounded border border-slate-900 p-2.5 flex flex-col justify-center relative flex-1 min-h-[120px]" id="export-detailed-curve-svg-wrapper">
                                            <svg viewBox="0 0 160 100" className="w-full h-full select-none flex-1 max-h-[140px]">
                                              {[-30, -20, -10].map((db) => {
                                                const x = 20 + ((db + 40) / 40) * 120;
                                                return (
                                                  <g key={`v-grid-${db}`}>
                                                    <line x1={x} y1={10} x2={x} y2={90} stroke="#111827" strokeWidth="0.75" strokeDasharray="2,3" />
                                                    <text x={x} y={96} fill="#475569" fontSize="4.5" textAnchor="middle" fontFamily="monospace">{db}dB</text>
                                                  </g>
                                                );
                                              })}

                                              {[0, -10, -20, -30].map((db) => {
                                                const y = 90 - ((db + 40) / 52) * 80;
                                                const isZero = db === 0;
                                                return (
                                                  <g key={`h-grid-${db}`}>
                                                    <line x1={20} y1={y} x2={140} y2={y} stroke={isZero ? "#1f2937" : "#0f172a"} strokeWidth="0.75" strokeDasharray={isZero ? "1,1" : "2,4"} />
                                                    <text x={16} y={y + 1.5} fill={isZero ? "#64748b" : "#475569"} fontSize="4.5" textAnchor="end" fontFamily="monospace">{db}dB</text>
                                                  </g>
                                                );
                                              })}

                                              <text x={20} y={96} fill="#475569" fontSize="4.5" textAnchor="middle" fontFamily="monospace">-40dB</text>
                                              <text x={140} y={96} fill="#475569" fontSize="4.5" textAnchor="middle" fontFamily="monospace">0dB</text>
                                              <text x={14} y={12} fill="#475569" fontSize="4.5" textAnchor="end" fontFamily="monospace">+12</text>
                                              <text x={14} y={91.5} fill="#475569" fontSize="4.5" textAnchor="end" fontFamily="monospace">-40</text>

                                              <line x1={20} y1={90} x2={140} y2={28.46} stroke="#1e293b" strokeWidth="1" strokeDasharray="3,3" />
                                              
                                              <text x={24} y={16} fill="#334155" fontSize="4" fontFamily="monospace">--- UNITY REFERENCE</text>
                                              <text x={24} y={22} fill={activeProps.stroke} fontSize="4" fontFamily="monospace">___ COMPRESSION KNEE</text>

                                              <path 
                                                d={`M 20 ${pyA} L ${pxB} ${pyB} L 140 ${pyC}`} 
                                                fill="none" 
                                                stroke={compressorEnabled ? activeProps.stroke : "#4b5563"} 
                                                strokeWidth={compressorEnabled ? "2" : "1"} 
                                                strokeLinecap="round"
                                                strokeLinejoin="round"
                                                className="transition-all duration-100"
                                              />

                                              <circle 
                                                cx={pxB} 
                                                cy={pyB} 
                                                r="3.5" 
                                                fill={compressorEnabled ? activeProps.stroke : "#6b7280"} 
                                                className={compressorEnabled ? "stroke-slate-950 stroke-[1.5px]" : ""}
                                              />

                                              <text 
                                                x={pxB} 
                                                y={pyB - 6} 
                                                fill={compressorEnabled ? activeProps.stroke : "#9ca3af"} 
                                                fontSize="4.5" 
                                                textAnchor="middle" 
                                                fontFamily="monospace"
                                                fontWeight="bold"
                                              >
                                                KNEE ({T}dB)
                                              </text>
                                            </svg>
                                            
                                            <div className="text-[7px] font-mono text-slate-500 text-center mt-1 pt-1 border-t border-slate-900/40">
                                              {language === "de"
                                                ? "X-Achse: Eingang (dB) • Y-Achse: Ausgang (dB)"
                                                : "X-Axis: Input Level (dB) • Y-Axis: Output Level (dB)"}
                                            </div>
                                          </div>

                                          {/* Sliders Workspace Panel */}
                                          <div className="bg-slate-950/40 border border-slate-900 rounded p-2.5 space-y-3 font-mono shrink-0">
                                            <div className="space-y-1">
                                              <div className="flex items-center justify-between text-[8.5px]">
                                                <span className="text-slate-400 font-bold">{language === "de" ? "SCHWELLENWERT (Threshold):" : "THRESHOLD (KNEE):"}</span>
                                                <span className={`text-[9px] font-bold px-1 py-0.2 rounded ${activeProps.accentBg} ${activeProps.accentText}`}>
                                                  {T} dB
                                                </span>
                                              </div>
                                              <div className="flex items-center gap-2">
                                                <span className="text-[7.5px] text-slate-600">-36 dB</span>
                                                <input 
                                                  type="range"
                                                  min={-36}
                                                  max={0}
                                                  step={1}
                                                  value={T}
                                                  onChange={(e) => activeProps.setThresh(Number(e.target.value))}
                                                  className="flex-1 h-1 bg-slate-900 hover:bg-slate-850 rounded-lg appearance-none cursor-pointer accent-cyan-500"
                                                />
                                                <span className="text-[7.5px] text-slate-600">0 dB</span>
                                              </div>
                                            </div>

                                            <div className="space-y-1">
                                              <div className="flex items-center justify-between text-[8.5px]">
                                                <span className="text-slate-400 font-bold">{language === "de" ? "KOMPRESSIONS-VERHÄLTNIS (Ratio):" : "COMPRESSION RATIO:"}</span>
                                                <span className={`text-[9px] font-bold px-1 py-0.2 rounded ${activeProps.accentBg} ${activeProps.accentText}`}>
                                                  {R.toFixed(1)}:1
                                                </span>
                                              </div>
                                              <div className="flex items-center gap-2">
                                                <span className="text-[7.5px] text-slate-600">1.0:1</span>
                                                <input 
                                                  type="range"
                                                  min={1}
                                                  max={10}
                                                  step={0.1}
                                                  value={R}
                                                  onChange={(e) => activeProps.setRatio(Number(e.target.value))}
                                                  className="flex-1 h-1 bg-slate-900 hover:bg-slate-850 rounded-lg appearance-none cursor-pointer accent-violet-500"
                                                />
                                                <span className="text-[7.5px] text-slate-600">10.0:1</span>
                                              </div>
                                            </div>

                                            <div className="space-y-1">
                                              <div className="flex items-center justify-between text-[8.5px]">
                                                <span className="text-slate-400 font-bold">{language === "de" ? "LAUTSTÄRKE-AUSGLEICH (Makeup Gain):" : "MAKEUP GAIN:"}</span>
                                                <span className={`text-[9px] font-bold px-1 py-0.2 rounded ${activeProps.accentBg} ${activeProps.accentText}`}>
                                                  +{M} dB
                                                </span>
                                              </div>
                                              <div className="flex items-center gap-2">
                                                <span className="text-[7.5px] text-slate-600">0 dB</span>
                                                <input 
                                                  type="range"
                                                  min={0}
                                                  max={12}
                                                  step={1}
                                                  value={M}
                                                  onChange={(e) => activeProps.setMakeup(Number(e.target.value))}
                                                  className="flex-1 h-1 bg-slate-900 hover:bg-slate-850 rounded-lg appearance-none cursor-pointer accent-amber-500"
                                                />
                                                <span className="text-[7.5px] text-slate-600">+12 dB</span>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                      );
                                    })()}
                                  </div>
                                </div>

                                {/* Modal Footer (Persistent) */}
                                <div className="flex justify-end border-t border-slate-900 pt-2 mt-2 shrink-0">
                                  <button
                                    onClick={() => setShowExportSummaryModal(false)}
                                    className="px-3 py-1 bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white rounded text-[10px] font-mono cursor-pointer transition"
                                    id="export-summary-dismiss-btn"
                                  >
                                    {language === "de" ? "Schließen" : "Dismiss"}
                                  </button>
                                </div>
                              </motion.div>
                            );
                          })()}
                        </AnimatePresence>
                      </div>
                    );
                  })()}

                  {/* Voice Command History Panel */}
                  <div className="space-y-2 border-t border-slate-800/60 pt-3">
                    <div className="flex items-center justify-between">
                      <span className="text-[8px] font-mono text-slate-400 uppercase tracking-wider flex items-center gap-1">
                        <History className="h-3 w-3 text-fcb-gold" />
                        {language === "de" ? "Befehlsverlauf:" : "Command History (Last 5):"}
                      </span>
                      {voiceCommandHistory.length > 0 && (
                        <button
                          onClick={() => {
                            setVoiceCommandHistory([]);
                            try {
                              localStorage.removeItem("fcb_miasanai_voice_history");
                            } catch (e) {
                              console.error(e);
                            }
                          }}
                          className="text-[8px] font-mono text-slate-500 hover:text-red-400 cursor-pointer"
                        >
                          {language === "de" ? "[leeren]" : "[clear]"}
                        </button>
                      )}
                    </div>
                    {voiceCommandHistory.length === 0 ? (
                      <p className="text-[9px] font-mono text-slate-600 italic">
                        {language === "de" ? "Keine Befehle im Verlauf" : "No commands in history"}
                      </p>
                    ) : (
                      <div className="space-y-1">
                        {voiceCommandHistory.map((cmd, idx) => (
                          <button
                            key={idx}
                            onClick={() => executeVoiceCommand(cmd)}
                            className="w-full text-left bg-slate-950/60 hover:bg-slate-850 border border-slate-800/60 hover:border-fcb-gold/30 rounded-md p-1.5 transition-all flex items-center justify-between group cursor-pointer text-slate-300 hover:text-white"
                          >
                            <span className="text-[10px] font-mono truncate mr-2">
                              "{cmd}"
                            </span>
                            <Play className="h-2.5 w-2.5 text-slate-500 group-hover:text-fcb-gold transition-colors flex-shrink-0" />
                          </button>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Available Command Shortcuts */}
                  <div className="space-y-2">
                    <span className="text-[8px] font-mono text-slate-500 uppercase tracking-wider block">
                      {language === "de" ? "Unterstützte Sprachbefehle:" : "Supported Commands:"}
                    </span>
                    <div className="space-y-1.5 text-[10px] font-mono text-slate-400">
                      <div className="bg-slate-950/40 p-1.5 rounded border border-slate-800/40">
                        <span className="text-fcb-gold">1. Navigation:</span>
                        <p className="text-[9px] text-slate-500 mt-0.5 italic">
                          "Go to Command Center" / "Wechsle zu Kommandozentrale" / "RAG" / "Lifecycle" / "Video" / "Webhook"
                        </p>
                      </div>
                      <div className="bg-slate-950/40 p-1.5 rounded border border-slate-800/40">
                        <span className="text-fcb-gold">2. Generation:</span>
                        <p className="text-[9px] text-slate-500 mt-0.5 italic">
                          "Generate post for Harry Kane" / "Erstelle Beitrag für Musiala auf TikTok"
                        </p>
                      </div>
                      <div className="bg-slate-950/40 p-1.5 rounded border border-slate-800/40">
                        <span className="text-fcb-gold">3. Search:</span>
                        <p className="text-[9px] text-slate-500 mt-0.5 italic">
                          "Search Allianz Arena" / "Suche Marken-Compliance"
                        </p>
                      </div>
                    </div>
                  </div>

                  {!speechSupported && (
                    <p className="text-[9px] text-amber-500 text-center font-mono">
                      ⚠️ {language === "de" ? "Web Speech API wird nicht voll unterstützt." : "Web Speech API is not supported."}
                    </p>
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Secure compliance badge */}
          <div className="hidden md:flex items-center gap-2 bg-slate-950 border border-slate-800/80 px-3 py-1.5 rounded-lg text-slate-400 font-mono text-[10px]">
            <Cpu className="h-3.5 w-3.5 text-green-400 animate-pulse" />
            <span>{t("secureBadge")}</span>
          </div>
        </div>
      </header>

      {/* 2. Primary layout with Sidebar and Main Tab Workspace */}
      <div className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left Side Navigation & Quick References (Span 3) */}
        <div className="lg:col-span-3 space-y-6">
          
          {/* Main Navigation Tab Selector */}
          <div className="bg-slate-900/40 p-4 rounded-2xl border border-slate-800/90 space-y-1">
            <span className="block text-[10px] font-mono text-slate-400 uppercase tracking-wide mb-3 px-1">
              Social Operations Workspace
            </span>
            {navigationTabs.map((tab) => {
              const TabIcon = tab.icon;
              const isSelected = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => {
                    setActiveTab(tab.id);
                    setNotification(`${t("workspaceShifted")}${tab.name}`);
                  }}
                  className={`w-full flex items-center gap-3 p-3 rounded-xl text-left transition-all group cursor-pointer border ${
                    isSelected 
                      ? "bg-gradient-to-r from-fcb-red to-rose-600 border-fcb-red text-white font-semibold shadow-md shadow-fcb-red/5" 
                      : "bg-transparent border-transparent text-slate-400 hover:text-white hover:bg-slate-950"
                  }`}
                  id={`tab-select-${tab.id}`}
                >
                  <TabIcon className={`h-4.5 w-4.5 transition-transform group-hover:scale-105 ${isSelected ? "text-white" : "text-slate-400"}`} />
                  <div>
                    <span className="text-xs block leading-none">{tab.name}</span>
                    <span className={`text-[9.5px] mt-0.5 block font-medium leading-none ${isSelected ? "text-slate-100" : "text-slate-500"}`}>
                      {tab.description}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Quick RAG Compliance Reference Panel */}
          <div className="bg-slate-900/40 p-4 rounded-2xl border border-slate-800/90 space-y-3 hidden lg:block">
            <span className="block text-[10px] font-mono text-fcb-gold uppercase tracking-wide font-bold px-1 flex items-center gap-1">
              <ShieldAlert className="h-3.5 w-3.5 text-fcb-gold" /> {t("brandComplianceTitle")}
            </span>
            <div className="space-y-2 select-text">
              {FCB_BRAND_RULES.map((rule, idx) => (
                <div key={idx} className="bg-slate-950/60 p-2 rounded-lg border border-slate-900/40 text-[10px] text-slate-400 leading-normal">
                  {rule}
                </div>
              ))}
            </div>
            <div className="pt-1.5 border-t border-slate-900/80 text-[10px] text-slate-500 font-mono text-center">
              {t("brandComplianceFooter")}
            </div>
          </div>
        </div>

        {/* Right Main Panel (Span 9) */}
        <main className="lg:col-span-9">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.15 }}
            >
              {activeTab === "dashboard" && (
                <DashboardOverview 
                  logs={logs} 
                  onAddLog={handleAddLog} 
                  onSimulateTrigger={handleSimulateTrigger} 
                />
              )}

              {activeTab === "journey" && (
                <JourneyBuilder 
                  onAddLog={handleAddLog} 
                  onTriggerSimulate={handleSimulateTrigger}
                  activeSimulation={activeSimulation}
                />
              )}

              {activeTab === "generator" && (
                <ContentGenerator 
                  onAddLog={handleAddLog} 
                  drafts={drafts}
                  setDrafts={setDrafts}
                />
              )}

              {activeTab === "moderation" && (
                <ModerationPanel 
                  drafts={drafts}
                  setDrafts={setDrafts}
                  onAddLog={handleAddLog}
                  language={language}
                />
              )}

              {activeTab === "video" && (
                <VideoStudio 
                  onAddLog={handleAddLog} 
                />
              )}

              {activeTab === "rag" && (
                <RagHub 
                  onAddLog={handleAddLog} 
                />
              )}

              {activeTab === "automation" && (
                <AutomationLogs 
                  logs={logs}
                  onAddLog={handleAddLog} 
                />
              )}

              {activeTab === "langgraph" && (
                <LangGraphAgent 
                  onAddLog={handleAddLog} 
                />
              )}

              {activeTab === "analytics" && (
                <Analytics 
                  logs={logs}
                  onAddLog={handleAddLog}
                />
              )}

              {activeTab === "settings" && (
                <SettingsPanel
                  theme={theme}
                  setTheme={setTheme}
                  onAddLog={handleAddLog}
                  speechEnabled={speechEnabled}
                  setSpeechEnabled={setSpeechEnabled}
                />
              )}
            </motion.div>
          </AnimatePresence>
        </main>

      </div>

      {/* 3. Global Footer */}
      <footer className="mt-auto bg-slate-950/40 border-t border-slate-800/80 py-4 text-center text-xs text-slate-500 font-mono">
        <p>{t("footerText")}</p>
        <p className="text-[10px] text-slate-600 mt-1">
          {t("footerSubText")}
        </p>
      </footer>
    </div>
  );
}
