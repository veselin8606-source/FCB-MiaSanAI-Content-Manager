import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  ShieldCheck, AlertTriangle, AlertCircle, Play, RefreshCw, Copy, Check, Terminal,
  Sliders, FileJson, Video, AudioLines, Sparkles, Send, Database, HelpCircle, Info, Layers, CheckCircle2, BadgeAlert, Plus
} from "lucide-react";

interface MultiAgentAutomationProps {
  onAddLog: (log: any) => void;
}

interface AgentResult {
  score: number;
  reason: string;
  weight: number;
}

interface QAExecutionResponse {
  success: boolean;
  draft: string;
  agent1: AgentResult;
  agent2: AgentResult;
  agent3: AgentResult;
  weightedScore: number;
  actionTaken: "APPROVE" | "STOP" | "RE_PROMPT" | "ESCALATE";
  errorLog: string | null;
  attempt: number;
  timestamp: string;
  metadata: {
    eventType: string;
    coreData: string;
    channels: string[];
    ragScope: string;
  };
}

export const MultiAgentAutomation: React.FC<MultiAgentAutomationProps> = ({ onAddLog }) => {
  // 1. Input states
  const [eventType, setEventType] = useState<string>("Spielday-Sieg (Full-Time Victory)");
  const [coreData, setCoreData] = useState<string>(
    "Thomas Müller feiert sein 710. Pflichtspiel-Jubiläum für den FC Bayern München. Er erzielt den entscheidenden Treffer in der 82. Minute zum 3:1 Sieg gegen Real Madrid vor 75.000 Zuschauern in der ausverkauften Allianz Arena."
  );
  const [channels, setChannels] = useState<string[]>(["Instagram"]);
  const [ragScope, setRagScope] = useState<string>("Squad Statistics & Match Reports");

  // Flow State
  const [forcePath, setForcePath] = useState<string>("auto");
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [activeStep, setActiveStep] = useState<number>(-1);
  const [history, setHistory] = useState<QAExecutionResponse[]>([]);
  const [currentResult, setCurrentResult] = useState<QAExecutionResponse | null>(null);
  
  // Tab within JSON / schemas view
  const [jsonTab, setJsonTab] = useState<"n8n" | "interfaces">("n8n");
  const [copied, setCopied] = useState<boolean>(false);

  // Re-prompting cycle simulation states
  const [loopCount, setLoopCount] = useState<number>(1);
  const [repromptingLogs, setRepromptingLogs] = useState<string[]>([]);

  // MP4 openVoice / FFmpeg rendering state
  const [renderingProgress, setRenderingProgress] = useState<number>(0);
  const [isRendering, setIsRendering] = useState<boolean>(false);
  const [videoRendered, setVideoRendered] = useState<boolean>(false);
  const [playAudio, setPlayAudio] = useState<boolean>(false);

  // Channels definitions
  const availableChannels = ["Instagram", "X/Twitter", "TikTok", "FCB App"];

  const handleChannelToggle = (ch: string) => {
    if (channels.includes(ch)) {
      setChannels(channels.filter(item => item !== ch));
    } else {
      setChannels([...channels, ch]);
    }
  };

  // Run the full pipeline
  const runQAWorkflow = async () => {
    setIsRunning(true);
    setActiveStep(0);
    setCurrentResult(null);
    setVideoRendered(false);
    setRenderingProgress(0);
    setRepromptingLogs([]);
    
    onAddLog({
      id: `multi-agent-qa-trigger-${Date.now()}`,
      timestamp: new Date().toLocaleTimeString(),
      level: "TRIGGER",
      source: "n8n Webhook Ingestion",
      message: `Inbound webhook triggered for event type '${eventType}' with RAG scope: [${ragScope}].`
    });

    // Step-by-step pipeline visualization
    const stepsDelays = [1000, 1500, 1200, 2000, 1500]; // Delay times for animation
    
    // Step 0: Input Layer (Ingestion & Setup)
    await new Promise(r => setTimeout(r, stepsDelays[0]));
    setActiveStep(1); // Step 1: n8n Routing and RAG retrieval
    onAddLog({
      id: `multi-agent-rag-retrieval-${Date.now()}`,
      timestamp: new Date().toLocaleTimeString(),
      level: "INFO",
      source: "RAG Hub Integration",
      message: `Retrieving relevant narrative pillars from scope: [${ragScope}]. Retrieved 3 document chunks.`
    });

    // Step 1 -> Step 2: Generation via Claude/Gemini
    await new Promise(r => setTimeout(r, stepsDelays[1]));
    setActiveStep(2); // Step 2: Content generation
    onAddLog({
      id: `multi-agent-llm-generation-${Date.now()}`,
      timestamp: new Date().toLocaleTimeString(),
      level: "INFO",
      source: "n8n LLM Node",
      message: "Orchestrating primary draft generation with Gemini using strict platform format rules."
    });

    // Step 2 -> Step 3: Multi-Agent QA
    await new Promise(r => setTimeout(r, stepsDelays[2]));
    setActiveStep(3); // Step 3: Multi-Agent QA Audit
    onAddLog({
      id: `multi-agent-review-start-${Date.now()}`,
      timestamp: new Date().toLocaleTimeString(),
      level: "INFO",
      source: "QA Review Engine",
      message: "Initiating 3-Agent verification layer. Calculating weights: Fact-Checker (40%), Brand-Strategist (35%), Perspective-Analyst (25%)."
    });

    // Let's call the actual server endpoint or perform loops
    try {
      let currentAttempt = 1;
      let finalResult: QAExecutionResponse | null = null;
      let stopLoop = false;

      while (!stopLoop && currentAttempt <= 3) {
        // Prepare payload
        const payload = {
          eventType,
          coreData,
          channels,
          ragScope,
          attempt: currentAttempt,
          forcePath: currentAttempt === 1 ? forcePath : (forcePath === "force_re_prompt" && currentAttempt === 2 ? "force_escalate" : "auto")
        };

        const response = await fetch("/api/automation/multi-agent-qa", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload)
        });

        if (!response.ok) {
          throw new Error("Multi-Agent QA service responded with an error");
        }

        const data: QAExecutionResponse = await response.json();
        finalResult = data;

        if (data.actionTaken === "RE_PROMPT" && currentAttempt < 3) {
          const repromptLogStr = `[Loop #${currentAttempt} FAILED] Weighted Score: ${data.weightedScore}/100 (< 80). Reason: QA threshold not met. Initiating Auto Re-prompting...`;
          setRepromptingLogs(prev => [...prev, repromptLogStr]);
          onAddLog({
            id: `reprompt-log-${currentAttempt}-${Date.now()}`,
            timestamp: new Date().toLocaleTimeString(),
            level: "WARNING",
            source: "Governance Guard",
            message: `QA verification score failed (${data.weightedScore}/100). Auto-initiating corrective prompt loop.`
          });
          currentAttempt++;
          await new Promise(r => setTimeout(r, 2200)); // Sleep before retrying to simulate LLM thinking
        } else {
          stopLoop = true;
        }
      }

      if (finalResult) {
        setCurrentResult(finalResult);
        setHistory(prev => [finalResult!, ...prev]);
        setActiveStep(4); // Step 4: Governance outcome determination

        // Write specific governance action logs
        if (finalResult.actionTaken === "APPROVE") {
          onAddLog({
            id: `qa-success-${Date.now()}`,
            timestamp: new Date().toLocaleTimeString(),
            level: "SUCCESS",
            source: "Governance Guard",
            message: `[AUTO-RELEASE] Weighted Quality Score of ${finalResult.weightedScore}/100 exceeded the threshold of 95. Caption auto-cleared and pushed to publication pipelines.`
          });
          
          // Trigger OpenVoice rendering automatically on success
          triggerMediaSynthesis();
        } else if (finalResult.actionTaken === "STOP") {
          onAddLog({
            id: `qa-stop-${Date.now()}`,
            timestamp: new Date().toLocaleTimeString(),
            level: "WARNING",
            source: "Governance Guard",
            message: `[AUTO-STOP] Quality Score of ${finalResult.weightedScore}/100 fell into the review window [80, 95). Manual Human-in-the-Loop clearance required.`
          });
        } else if (finalResult.actionTaken === "ESCALATE") {
          onAddLog({
            id: `qa-escalation-${Date.now()}`,
            timestamp: new Date().toLocaleTimeString(),
            level: "WARNING",
            source: "Governance Guard",
            message: `[CRITICAL ESCALATION] Content Quality Score remained at ${finalResult.weightedScore}/100 after 2 corrective prompt iterations. Alerting Redaktion Specialist with Root-Cause report.`
          });
        }
      }

    } catch (err: any) {
      console.error("Multi-agent automation failed:", err);
      onAddLog({
        id: `multi-agent-error-${Date.now()}`,
        timestamp: new Date().toLocaleTimeString(),
        level: "WARNING",
        source: "Multi-Agent Automation",
        message: `Validation pipeline crashed: ${err.message}. Controlling manual backup routing.`
      });
    } finally {
      setIsRunning(false);
    }
  };

  const triggerMediaSynthesis = () => {
    setIsRendering(true);
    setRenderingProgress(0);
    setVideoRendered(false);

    const interval = setInterval(() => {
      setRenderingProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsRendering(false);
          setVideoRendered(true);
          onAddLog({
            id: `synthesis-rendered-${Date.now()}`,
            timestamp: new Date().toLocaleTimeString(),
            level: "SUCCESS",
            source: "OpenVoice / FFmpeg Engine",
            message: `Successfully synthesized German voice note via OpenVoice and rendered MP4 container.`
          });
          return 100;
        }
        return prev + 10;
      });
    }, 400);
  };

  const handleCopyJSON = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // 1. JSON-Struktur für n8n Agenten-Kommunikation
  const n8nWorkflowJSON = `{
  "meta": {
    "system": "MiaSanAI Multi-Agent Content Automation Node",
    "version": "1.0.0",
    "timestamp": "${new Date().toISOString()}"
  },
  "pipeline_input": {
    "event_type": "${eventType}",
    "core_data": "${coreData}",
    "target_channels": ${JSON.stringify(channels)},
    "rag_scope": "${ragScope}"
  },
  "n8n_context": {
    "node_id": "n8n-multi-agent-orchestrator",
    "execution_id": "exec_fcb_${Date.now().toString().slice(-6)}",
    "next_nodes": ["Fact_Checker_Agent", "Brand_Strategist_Agent", "Perspective_Analyst_Agent"]
  },
  "agent_payload_schemas": {
    "Agent_1_Fact_Checker": {
      "weight": 0.40,
      "role_instructions": "Verifiziere jedes Datum, jede Zahl, jeden Spielernamen und jedes Ereignis gegen die RAG-Chunks.",
      "input_draft": "{{ $json.primary_draft }}"
    },
    "Agent_2_Brand_Strategist": {
      "weight": 0.35,
      "role_instructions": "Prüfung auf 'Cultural Fit' und Clubidentität (Mia San Mia, Emotionen, Emojis, Hashtags).",
      "input_draft": "{{ $json.primary_draft }}"
    },
    "Agent_3_Perspective_Analyst": {
      "weight": 0.25,
      "role_instructions": "Prüfe auf Bias, einseitige Fan-Tunnelblick, Sprachfluss und Internationalisierung.",
      "input_draft": "{{ $json.primary_draft }}"
    }
  }
}`;

  // 2. TypeScript-Schnittstellen für Fehler-Logging & Historie
  const tsInterfacesCode = `/**
 * @interface QAAgentReview
 * Repräsentiert das detaillierte Review-Ergebnis eines einzelnen Qualitätsagenten.
 */
export interface QAAgentReview {
  agentName: "Fact-Checker" | "Brand-Strategist" | "Perspective-Analyst";
  agentId: string;
  weight: number;         // z.B. 0.40, 0.35, 0.25
  score: number;          // 0 bis 100
  critique: string;       // Begründung / Feedback-Text
  hallucinationsDetected: string[]; // Nur für Fact-Checker relevant
}

/**
 * @interface QAGovernanceRecord
 * Der vollständige historische Datensatz eines Pipeline-Qualitätsaudits.
 */
export interface QAGovernanceRecord {
  auditId: string;
  timestamp: string;
  eventType: string;
  coreData: string;
  targetDraft: string;
  reviews: QAAgentReview[];
  weightedScore: number;  // S = Σ (Score_i * Weight_i)
  
  // Governance outcome:
  // S >= 95 -> APPROVED
  // 80 <= S < 95 -> MANUAL_REVIEW
  // S < 80 -> RE_PROMPT_CYCLE / ESCALATED
  outcome: "APPROVED" | "MANUAL_REVIEW" | "RE_PROMPT_TRIGGERED" | "CRITICAL_ESCALATED";
  
  attemptNumber: number;  // Aktuelle Iterations-Runde (1 bis 3)
  errorLog: {
    code: string;
    rootCause: string;
    analysisMessage: string;
    recommendations: string[];
  } | null;
}`;

  return (
    <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 select-none" id="multi-agent-system-panel">
      
      {/* 1. INPUT-LAYER & SETUP (Span 4) */}
      <div className="xl:col-span-4 space-y-6">
        <div className="bg-slate-900/40 p-5 rounded-2xl border border-slate-800 space-y-4 flex flex-col justify-between h-full min-h-[580px]">
          <div className="space-y-4">
            <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
              <Sliders className="h-5 w-5 text-fcb-red" />
              <h3 className="font-bold text-white font-display text-sm uppercase tracking-wide">
                1. Input-Layer (n8n Ingest)
              </h3>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              Definieren Sie die Ereignismetadaten, die RAG-Suchvorgaben und Zielkanäle. Diese Rohdaten werden in die automatisierte n8n-Pipeline geladen.
            </p>

            {/* Event Type */}
            <div className="space-y-1.5 text-left">
              <label className="text-[10px] font-mono text-slate-400 uppercase tracking-wide">
                Ereignistyp / Event Type
              </label>
              <select
                value={eventType}
                onChange={(e) => setEventType(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 focus:border-fcb-red text-slate-300 rounded-lg p-2.5 text-xs outline-none transition cursor-pointer"
                disabled={isRunning}
              >
                <option value="Spielday-Sieg (Full-Time Victory)">🏆 Spielday-Sieg (Full-Time Victory)</option>
                <option value="Pressekonferenz (Press Conference)">🎤 Pressekonferenz (Press Conference)</option>
                <option value="Transfer-Verkündung (Transfer Announcement)">⚽ Transfer-Verkündung (Transfer)</option>
                <option value="Sponsoring-Deal (Partnership Release)">🤝 Sponsoring-Deal (Partnership)</option>
              </select>
            </div>

            {/* Core Data */}
            <div className="space-y-1.5 text-left">
              <label className="text-[10px] font-mono text-slate-400 uppercase tracking-wide">
                Kerndaten / Core Event Data
              </label>
              <textarea
                value={coreData}
                onChange={(e) => setCoreData(e.target.value)}
                className="w-full h-24 bg-slate-950 border border-slate-800 focus:border-fcb-red text-slate-200 rounded-lg p-2.5 text-xs outline-none resize-none transition"
                placeholder="Details zum Spielverlauf, Torschützen, Statistiken..."
                disabled={isRunning}
              />
            </div>

            {/* RAG Scope */}
            <div className="space-y-1.5 text-left">
              <label className="text-[10px] font-mono text-slate-400 uppercase tracking-wide">
                RAG-Scope (Wissens-Quelle)
              </label>
              <input
                type="text"
                value={ragScope}
                onChange={(e) => setRagScope(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 focus:border-fcb-red text-slate-200 rounded-lg p-2.5 text-xs outline-none transition"
                placeholder="Z.B. Squad Statistics & Match Reports"
                disabled={isRunning}
              />
            </div>

            {/* Target Channels */}
            <div className="space-y-1.5 text-left">
              <label className="text-[10px] font-mono text-slate-400 uppercase tracking-wide block mb-1">
                Zielkanäle / Target Channels
              </label>
              <div className="grid grid-cols-2 gap-2">
                {availableChannels.map((ch) => {
                  const active = channels.includes(ch);
                  return (
                    <button
                      key={ch}
                      type="button"
                      onClick={() => handleChannelToggle(ch)}
                      className={`py-2 px-2.5 rounded-lg text-[10.5px] border font-semibold transition cursor-pointer text-center ${
                        active
                          ? "bg-fcb-red/10 border-fcb-red text-fcb-red shadow-sm"
                          : "bg-slate-950 border-slate-850 text-slate-400 hover:text-slate-300"
                      }`}
                      disabled={isRunning}
                    >
                      {ch === "Instagram" && "📸 Instagram"}
                      {ch === "X/Twitter" && "🐦 X/Twitter"}
                      {ch === "TikTok" && "🎵 TikTok"}
                      {ch === "FCB App" && "📱 FCB App"}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Controls Panel & Trigger */}
          <div className="pt-4 border-t border-slate-800 space-y-3">
            <div className="space-y-1">
              <span className="text-[9px] font-mono text-slate-500 uppercase tracking-wide block text-left">
                QS-Pfad erzwingen (Simulationstest):
              </span>
              <div className="grid grid-cols-2 gap-1.5">
                <button
                  onClick={() => setForcePath("auto")}
                  className={`py-1 rounded text-[9px] font-mono border transition ${
                    forcePath === "auto"
                      ? "bg-slate-800 text-white border-slate-700"
                      : "bg-slate-950 text-slate-500 border-slate-900 hover:text-slate-300"
                  }`}
                >
                  🤖 Auto-AI
                </button>
                <button
                  onClick={() => setForcePath("force_publish")}
                  className={`py-1 rounded text-[9px] font-mono border transition ${
                    forcePath === "force_publish"
                      ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/25"
                      : "bg-slate-950 text-slate-500 border-slate-900 hover:text-slate-300"
                  }`}
                  title="S >= 95: Auto-Freigabe"
                >
                  🟢 S &ge; 95 (Publish)
                </button>
                <button
                  onClick={() => setForcePath("force_stop")}
                  className={`py-1 rounded text-[9px] font-mono border transition ${
                    forcePath === "force_stop"
                      ? "bg-amber-500/10 text-amber-400 border-amber-500/25"
                      : "bg-slate-950 text-slate-500 border-slate-900 hover:text-slate-300"
                  }`}
                  title="80 <= S < 95: Stopp für Review"
                >
                  🟡 80&le;S&lt;95 (Stop)
                </button>
                <button
                  onClick={() => setForcePath("force_re_prompt")}
                  className={`py-1 rounded text-[9px] font-mono border transition ${
                    forcePath === "force_re_prompt"
                      ? "bg-rose-500/10 text-rose-400 border-rose-500/25"
                      : "bg-slate-950 text-slate-500 border-slate-900 hover:text-slate-300"
                  }`}
                  title="S < 80: Re-prompt & Eskalation"
                >
                  🔴 S &lt; 80 (Loop Fail)
                </button>
              </div>
            </div>

            <button
              onClick={runQAWorkflow}
              disabled={isRunning || channels.length === 0 || !coreData.trim()}
              className="w-full bg-fcb-red hover:bg-red-700 disabled:bg-slate-950 disabled:border-slate-900 disabled:text-slate-600 border border-transparent text-white font-bold py-3 px-4 rounded-xl text-xs flex items-center justify-center gap-2 transition cursor-pointer uppercase tracking-wider shadow-lg shadow-fcb-red/10"
            >
              {isRunning ? (
                <>
                  <RefreshCw className="h-4 w-4 animate-spin" />
                  <span>Pipelines laufen...</span>
                </>
              ) : (
                <>
                  <Play className="h-4 w-4 fill-current" />
                  <span>n8n Pipeline starten</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* 2. AUTOMATION & MULTI-AGENT-QS VISUALIZER (Span 5) */}
      <div className="xl:col-span-5 space-y-6">
        <div className="bg-slate-900/40 p-5 rounded-2xl border border-slate-800 h-full flex flex-col min-h-[580px]">
          
          <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
            <span className="text-xs text-slate-300 font-mono flex items-center gap-1.5 uppercase font-semibold">
              <Layers className="h-4 w-4 text-cyan-400" /> Multi-Agent Governance Node
            </span>
            <span className="bg-slate-950 border border-slate-850 text-[10px] px-2 py-0.5 rounded-md font-mono text-fcb-gold">
              n8n Router Active
            </span>
          </div>

          <div className="flex-1 space-y-4">
            {activeStep === -1 ? (
              <div className="h-full flex flex-col items-center justify-center text-center text-slate-500 py-20">
                <ShieldCheck className="h-10 w-10 mb-3 opacity-30 text-fcb-gold" />
                <p className="text-[11px] uppercase font-bold tracking-wider text-slate-400">QS-Pipeline bereit</p>
                <p className="text-[11px] text-slate-500 mt-1 max-w-[220px]">
                  Starten Sie den n8n-Workflow links, um die vollautomatische Multi-Agenten-Prüfung zu starten.
                </p>
              </div>
            ) : (
              <div className="space-y-4 text-left">
                {/* Visual Pipeline Steps */}
                <div className="grid grid-cols-5 gap-1 bg-slate-950 p-1.5 rounded-xl border border-slate-900">
                  {[
                    { label: "Ingest", icon: Send },
                    { label: "RAG", icon: Database },
                    { label: "Draft", icon: Sparkles },
                    { label: "Audit", icon: ShieldCheck },
                    { label: "Outcome", icon: Layers }
                  ].map((step, idx) => {
                    const isDone = activeStep > idx;
                    const isActive = activeStep === idx;
                    
                    let bg = "bg-transparent text-slate-500";
                    if (isDone) bg = "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20";
                    if (isActive) bg = "bg-fcb-red text-white font-bold animate-pulse";

                    return (
                      <div key={idx} className={`p-1 rounded-lg flex flex-col items-center text-center transition ${bg}`}>
                        <step.icon className="h-3.5 w-3.5 mb-1" />
                        <span className="text-[9px] font-mono uppercase font-bold tracking-tight">{step.label}</span>
                      </div>
                    );
                  })}
                </div>

                {/* Animated Loop Tracking Logs */}
                {repromptingLogs.length > 0 && (
                  <div className="space-y-1.5 bg-rose-950/15 border border-rose-900/40 p-2.5 rounded-xl text-[10px] font-mono text-rose-300">
                    <span className="font-bold uppercase flex items-center gap-1">
                      <AlertTriangle className="h-3 w-3 text-rose-400" /> Re-Prompting Cycles:
                    </span>
                    <ul className="list-disc list-inside space-y-0.5">
                      {repromptingLogs.map((log, lIdx) => (
                        <li key={lIdx}>{log}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Agent Card Review Grid */}
                {activeStep >= 3 && currentResult && (
                  <div className="space-y-3.5">
                    <span className="text-[10px] font-mono text-slate-500 uppercase font-bold tracking-wider block">
                      Qualitäts-Reviews der Einzelagenten:
                    </span>

                    <div className="space-y-2.5">
                      {/* Agent 1 (Fact Checker) */}
                      <div className="bg-slate-950 border border-slate-900 rounded-xl p-3 flex flex-col gap-1.5">
                        <div className="flex items-center justify-between text-[11px] font-mono">
                          <span className="text-cyan-400 font-bold uppercase flex items-center gap-1">
                            <span className="h-1.5 w-1.5 rounded-full bg-cyan-400" />
                            Agent 1: Fakten-Check (40% Weight)
                          </span>
                          <span className={`font-bold px-1.5 py-0.5 rounded text-[10px] ${
                            currentResult.agent1.score >= 85 ? "text-green-400 bg-green-500/5" : "text-rose-400 bg-rose-500/5"
                          }`}>
                            Score: {currentResult.agent1.score}/100
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-300 leading-relaxed font-sans italic">
                          "{currentResult.agent1.reason}"
                        </p>
                      </div>

                      {/* Agent 2 (Brand/Tone) */}
                      <div className="bg-slate-950 border border-slate-900 rounded-xl p-3 flex flex-col gap-1.5">
                        <div className="flex items-center justify-between text-[11px] font-mono">
                          <span className="text-fcb-gold font-bold uppercase flex items-center gap-1">
                            <span className="h-1.5 w-1.5 rounded-full bg-fcb-gold" />
                            Agent 2: Brand & Tone (35% Weight)
                          </span>
                          <span className={`font-bold px-1.5 py-0.5 rounded text-[10px] ${
                            currentResult.agent2.score >= 85 ? "text-green-400 bg-green-500/5" : "text-rose-400 bg-rose-500/5"
                          }`}>
                            Score: {currentResult.agent2.score}/100
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-300 leading-relaxed font-sans italic">
                          "{currentResult.agent2.reason}"
                        </p>
                      </div>

                      {/* Agent 3 (Bias/Alternative) */}
                      <div className="bg-slate-950 border border-slate-900 rounded-xl p-3 flex flex-col gap-1.5">
                        <div className="flex items-center justify-between text-[11px] font-mono">
                          <span className="text-violet-400 font-bold uppercase flex items-center gap-1">
                            <span className="h-1.5 w-1.5 rounded-full bg-violet-400" />
                            Agent 3: Perspektiven-Check (25% Weight)
                          </span>
                          <span className={`font-bold px-1.5 py-0.5 rounded text-[10px] ${
                            currentResult.agent3.score >= 85 ? "text-green-400 bg-green-500/5" : "text-rose-400 bg-rose-500/5"
                          }`}>
                            Score: {currentResult.agent3.score}/100
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-300 leading-relaxed font-sans italic">
                          "{currentResult.agent3.reason}"
                        </p>
                      </div>
                    </div>

                    {/* Weighted Score Banner */}
                    <div className="bg-slate-950 border border-slate-850 p-4 rounded-xl space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-mono text-slate-400 uppercase font-bold">
                          Berechneter Gesamt-Score (S):
                        </span>
                        <span className="text-xs text-slate-500 font-mono">
                          ({currentResult.agent1.score}*0.40) + ({currentResult.agent2.score}*0.35) + ({currentResult.agent3.score}*0.25)
                        </span>
                      </div>
                      
                      <div className="flex items-center justify-between border-t border-slate-900 pt-2.5">
                        <div className="flex items-baseline gap-1">
                          <span className="text-2xl font-black font-mono text-fcb-gold">
                            {currentResult.weightedScore}
                          </span>
                          <span className="text-xs text-slate-500">/ 100</span>
                        </div>

                        {/* Outcome badge */}
                        {currentResult.actionTaken === "APPROVE" && (
                          <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[10.5px] font-mono font-bold px-3 py-1 rounded-lg uppercase flex items-center gap-1.5">
                            <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />
                            Auto-Publishing (S &ge; 95)
                          </span>
                        )}
                        {currentResult.actionTaken === "STOP" && (
                          <span className="bg-amber-500/10 text-amber-400 border border-amber-500/20 text-[10.5px] font-mono font-bold px-3 py-1 rounded-lg uppercase flex items-center gap-1.5">
                            <Info className="h-3.5 w-3.5 text-amber-400" />
                            Manual Review [80, 95)
                          </span>
                        )}
                        {currentResult.actionTaken === "ESCALATE" && (
                          <span className="bg-rose-500/10 text-rose-400 border border-rose-500/20 text-[10.5px] font-mono font-bold px-3 py-1 rounded-lg uppercase flex items-center gap-1.5">
                            <BadgeAlert className="h-3.5 w-3.5 text-rose-400 animate-pulse" />
                            Loop Failed & Halted (S &lt; 80)
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Rendered Draft Caption Text Output */}
                    <div className="space-y-1 text-[11px]">
                      <span className="text-[10px] font-mono text-slate-500 uppercase font-bold">
                        Generierter Social-Media Post:
                      </span>
                      <p className="bg-slate-950 p-3 rounded-xl border border-slate-850 text-slate-200 leading-relaxed italic">
                        "{currentResult.draft}"
                      </p>
                    </div>

                    {/* Escalate / Manual Review Trigger buttons */}
                    {currentResult.actionTaken === "STOP" && (
                      <div className="flex gap-2">
                        <button
                          onClick={() => {
                            onAddLog({
                              id: `manual-clear-${Date.now()}`,
                              timestamp: new Date().toLocaleTimeString(),
                              level: "SUCCESS",
                              source: "Operator Guard",
                              message: `Draft manually approved by human operator. Moving into queue.`
                            });
                            setCurrentResult(prev => prev ? { ...prev, actionTaken: "APPROVE" } : null);
                            triggerMediaSynthesis();
                          }}
                          className="flex-1 bg-emerald-500 hover:bg-emerald-600 text-white py-2 rounded-lg text-xs font-bold transition cursor-pointer"
                        >
                          Händisch freigeben (Approve Post)
                        </button>
                        <button
                          onClick={() => {
                            setForcePath("force_re_prompt");
                            runQAWorkflow();
                          }}
                          className="bg-slate-800 hover:bg-slate-700 text-slate-300 py-2 px-3 rounded-lg text-xs font-semibold transition cursor-pointer"
                        >
                          Fehlerhaftes Re-Prompting
                        </button>
                      </div>
                    )}

                    {/* Error Log Report Viewer (Root-Cause-Analyse) */}
                    {currentResult.errorLog && (
                      <div className="bg-slate-950 border border-rose-950/40 rounded-xl p-3.5 font-mono text-[10.5px] text-left text-rose-300 space-y-2">
                        <div className="flex items-center gap-1 text-xs text-rose-400 font-bold border-b border-rose-950/40 pb-1.5">
                          <Terminal className="h-4 w-4" />
                          <span>FEHLERPROTOKOLL (Root-Cause-Analyse)</span>
                        </div>
                        <pre className="whitespace-pre-wrap leading-relaxed select-text">
                          {currentResult.errorLog}
                        </pre>
                      </div>
                    )}

                  </div>
                )}
              </div>
            )}
          </div>

        </div>
      </div>

      {/* 3. OUTPUT-LAYER: SCHEMAS & SYNTHESIS (Span 3) */}
      <div className="xl:col-span-3 space-y-6">
        
        {/* JSON / n8n / Interfaces Tab */}
        <div className="bg-slate-900/40 p-4 rounded-2xl border border-slate-800 space-y-3 flex flex-col justify-between min-h-[290px]">
          <div>
            <div className="flex items-center justify-between border-b border-slate-800 pb-2.5 mb-2.5">
              <span className="text-[10px] font-mono text-fcb-gold uppercase font-bold flex items-center gap-1">
                <FileJson className="h-3.5 w-3.5 text-fcb-gold" /> Data Structures
              </span>
              
              <div className="flex gap-1 bg-slate-950 p-0.5 rounded-md border border-slate-900">
                <button
                  onClick={() => setJsonTab("n8n")}
                  className={`px-1.5 py-0.5 rounded text-[8px] font-mono font-medium transition cursor-pointer uppercase ${
                    jsonTab === "n8n" ? "bg-slate-800 text-white" : "text-slate-400 hover:text-slate-200"
                  }`}
                >
                  n8n JSON
                </button>
                <button
                  onClick={() => setJsonTab("interfaces")}
                  className={`px-1.5 py-0.5 rounded text-[8px] font-mono font-medium transition cursor-pointer uppercase ${
                    jsonTab === "interfaces" ? "bg-slate-800 text-white" : "text-slate-400 hover:text-slate-200"
                  }`}
                >
                  TS Types
                </button>
              </div>
            </div>

            {/* Code Box */}
            <div className="relative bg-slate-950 rounded-lg p-2.5 border border-slate-850 font-mono text-[9px] text-slate-300 leading-normal max-h-[170px] overflow-y-auto text-left select-text scrollbar-thin">
              <button
                onClick={() => handleCopyJSON(jsonTab === "n8n" ? n8nWorkflowJSON : tsInterfacesCode)}
                className="absolute top-1.5 right-1.5 p-1 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded text-slate-400 hover:text-white transition"
                title="Copy Code"
              >
                {copied ? <Check className="h-3 w-3 text-green-400" /> : <Copy className="h-3 w-3" />}
              </button>
              <pre className="whitespace-pre">
                {jsonTab === "n8n" ? n8nWorkflowJSON : tsInterfacesCode}
              </pre>
            </div>
          </div>

          <div className="text-[9.5px] text-slate-500 text-left font-sans italic pt-1 border-t border-slate-800/40">
            {jsonTab === "n8n" 
              ? "This JSON is used by the n8n Workflow router nodes to dispatch tasks to Review Agents."
              : "TypeScript interfaces mapping the full historical score records for persistent auditing logs."}
          </div>
        </div>

        {/* Output rendering & Media Player (MP4 OpenVoice / FFmpeg) */}
        <div className="bg-slate-900/40 p-4 rounded-2xl border border-slate-800 space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-800 pb-2.5">
            <Video className="h-4 w-4 text-cyan-400" />
            <h3 className="font-bold text-white font-display text-[11px] uppercase tracking-wide">
              Output-Layer: MP4 & OpenVoice
            </h3>
          </div>

          <p className="text-[10px] text-slate-400 leading-normal text-left">
            Nach erfolgreicher QS-Freigabe generiert das System eine synthetische Audiospur mit OpenVoice (Deutsch) und rendert den Post in einen MP4-Container für Instagram/TikTok.
          </p>

          {/* Render State Area */}
          {isRendering ? (
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-850 text-center space-y-3">
              <RefreshCw className="h-6 w-6 text-cyan-400 animate-spin mx-auto" />
              <div className="space-y-1">
                <span className="text-[9.5px] font-mono text-cyan-400 font-bold uppercase block">FFmpeg rendering in progress</span>
                <div className="w-full bg-slate-900 rounded-full h-1">
                  <div className="bg-cyan-400 h-1 rounded-full transition-all duration-300" style={{ width: `${renderingProgress}%` }}></div>
                </div>
                <span className="text-[9px] font-mono text-slate-500">{renderingProgress}% complete</span>
              </div>
            </div>
          ) : videoRendered && currentResult ? (
            <div className="bg-slate-950 p-3 rounded-xl border border-slate-850 space-y-3">
              <div className="aspect-video bg-slate-900 rounded-lg relative overflow-hidden flex flex-col items-center justify-center border border-slate-800">
                {/* Simulated MP4 Video Player */}
                <div className="absolute inset-0 bg-cover bg-center opacity-40 filter blur-[1px]" style={{ backgroundImage: "url('https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=400&auto=format&fit=crop')" }}></div>
                <div className="absolute inset-0 bg-slate-950/60 flex flex-col items-center justify-center p-3 text-center">
                  <AudioLines className={`h-8 w-8 mb-1 text-fcb-gold ${playAudio ? "animate-pulse" : ""}`} />
                  <p className="text-[10px] text-fcb-gold font-bold font-mono uppercase tracking-wider">MiaSanAI Media Renderer</p>
                  <p className="text-[9px] text-slate-300 font-mono mt-0.5 max-w-[160px] truncate">{eventType}</p>
                </div>
              </div>

              {/* Audio visual player controls */}
              <div className="flex gap-2">
                <button
                  onClick={() => setPlayAudio(!playAudio)}
                  className={`flex-1 py-1.5 px-3 rounded text-[10px] font-semibold flex items-center justify-center gap-1 transition-all cursor-pointer ${
                    playAudio ? "bg-fcb-red text-white" : "bg-slate-800 text-slate-200 hover:bg-slate-700"
                  }`}
                >
                  <AudioLines className="h-3 w-3" />
                  <span>{playAudio ? "Audio stoppen" : "OpenVoice abspielen"}</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="bg-slate-950/40 p-5 rounded-xl border border-slate-900 text-center py-6 text-slate-600">
              <AudioLines className="h-6 w-6 mx-auto opacity-35 mb-2" />
              <p className="text-[9px] font-mono uppercase font-bold tracking-wider">Rendering wartet...</p>
              <p className="text-[9px] text-slate-500 mt-0.5">Startet nach erfolgreicher automatischer S &ge; 95 Freigabe.</p>
            </div>
          )}

        </div>

      </div>

    </div>
  );
};
