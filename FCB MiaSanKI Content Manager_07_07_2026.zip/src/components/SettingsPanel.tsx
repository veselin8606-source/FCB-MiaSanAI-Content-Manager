import React from "react";
import { Settings, Shield, Volume2, VolumeX, CheckCircle, Eye, RefreshCw, Sparkles } from "lucide-react";
import { useLanguage } from "../context/LanguageContext";

interface SettingsPanelProps {
  theme: "dark" | "classic";
  setTheme: (theme: "dark" | "classic") => void;
  onAddLog: (log: any) => void;
  speechEnabled: boolean;
  setSpeechEnabled: (enabled: boolean) => void;
}

export const SettingsPanel: React.FC<SettingsPanelProps> = ({
  theme,
  setTheme,
  onAddLog,
  speechEnabled,
  setSpeechEnabled,
}) => {
  const { language, t } = useLanguage();

  const handleThemeChange = (newTheme: "dark" | "classic") => {
    setTheme(newTheme);
    onAddLog({
      id: `theme-${Date.now()}`,
      timestamp: new Date().toLocaleTimeString(),
      level: "SUCCESS",
      source: "System UI",
      message: language === "de" 
        ? `Design-Thema geändert zu: ${newTheme === "classic" ? "FCB Classic (Rot/Weiß)" : "Sophisticated Dark"}`
        : `Theme changed to: ${newTheme === "classic" ? "FCB Classic (Red/White)" : "Sophisticated Dark"}`
    });
  };

  return (
    <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 animate-fade-in" id="settings-tab">
      {/* Primary Display Settings (Col Span 2) */}
      <div className="xl:col-span-2 space-y-6">
        <div className="bg-slate-900/40 p-5 rounded-2xl border border-slate-800 space-y-5">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <Settings className="h-5 w-5 text-fcb-red animate-spin-slow" />
              <h3 className="font-bold text-white font-display text-sm uppercase tracking-wide">
                {language === "de" ? "System- & Anzeigeeinstellungen" : "System & Display Settings"}
              </h3>
            </div>
            <span className="text-[10px] text-slate-500 font-mono uppercase tracking-wider">
              {language === "de" ? "Konfiguration" : "Configuration"}
            </span>
          </div>

          <p className="text-xs text-slate-400 leading-relaxed">
            {language === "de" 
              ? "Personalisieren Sie die MiaSanAI-Benutzeroberfläche. Wechseln Sie zwischen dem standardmäßigen eleganten Dunkelmodus und dem klassischen rot-weißen Vereinsdesign für maximale Kontraste."
              : "Personalize the MiaSanAI interface. Toggle between the default sophisticated dark mode and the classic red-and-white club layout for high-contrast viewing."}
          </p>

          {/* Theme Selector Section */}
          <div className="space-y-3 pt-2">
            <h4 className="text-xs font-mono font-bold text-slate-400 uppercase tracking-wide">
              {language === "de" ? "Anzeige-Thema (Display Theme):" : "Display Theme:"}
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Sophisticated Dark Option */}
              <button
                onClick={() => handleThemeChange("dark")}
                className={`text-left rounded-xl p-4 border transition-all relative overflow-hidden group cursor-pointer ${
                  theme === "dark"
                    ? "bg-slate-950 border-fcb-gold/80 shadow-lg shadow-fcb-gold/5 text-white"
                    : "bg-slate-950/20 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-white"
                }`}
              >
                {/* Theme visual card mimic */}
                <div className="h-20 bg-[#0c0c0f] rounded-lg border border-slate-850 p-2.5 mb-3 flex flex-col justify-between overflow-hidden relative">
                  <div className="flex items-center justify-between">
                    <span className="text-[8px] font-mono font-bold text-fcb-gold uppercase tracking-wider">MiaSanAI Dark</span>
                    <span className="h-2 w-2 rounded-full bg-green-500 animate-pulse"></span>
                  </div>
                  <div className="space-y-1">
                    <div className="h-1 w-1/2 bg-slate-800 rounded"></div>
                    <div className="h-1.5 w-3/4 bg-fcb-red rounded"></div>
                  </div>
                  {/* Visual design representation */}
                  <div className="absolute right-2 bottom-2 h-6 w-6 rounded-full bg-gradient-to-tr from-slate-900 to-slate-950 border border-slate-800 flex items-center justify-center">
                    <Eye className="h-3 w-3 text-fcb-gold" />
                  </div>
                </div>

                <div className="flex items-start justify-between">
                  <div>
                    <h5 className="font-bold text-xs">
                      {language === "de" ? "Sophisticated Dark" : "Sophisticated Dark"}
                    </h5>
                    <p className="text-[10px] text-slate-500 mt-1 leading-normal">
                      {language === "de" 
                        ? "Elegantes, augenschonendes Dunkelblau-Grau mit goldenen Highlights."
                        : "Premium, low-light blue-grey slate canvas with gold details."}
                    </p>
                  </div>
                  {theme === "dark" && (
                    <span className="bg-fcb-gold/15 text-fcb-gold border border-fcb-gold/30 rounded-full p-1 self-start">
                      <CheckCircle className="h-3.5 w-3.5" />
                    </span>
                  )}
                </div>
              </button>

              {/* FCB Classic Red/White Option */}
              <button
                onClick={() => handleThemeChange("classic")}
                className={`text-left rounded-xl p-4 border transition-all relative overflow-hidden group cursor-pointer ${
                  theme === "classic"
                    ? "bg-white border-fcb-red shadow-lg shadow-fcb-red/5 text-slate-900"
                    : "bg-slate-950/20 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-white"
                }`}
              >
                {/* Theme visual card mimic */}
                <div className="h-20 bg-slate-100 rounded-lg border border-slate-200 p-2.5 mb-3 flex flex-col justify-between overflow-hidden relative">
                  <div className="flex items-center justify-between">
                    <span className="text-[8px] font-mono font-bold text-fcb-red uppercase tracking-wider">FCB Classic</span>
                    <span className="h-2 w-2 rounded-full bg-fcb-red"></span>
                  </div>
                  <div className="space-y-1">
                    <div className="h-1 w-1/2 bg-slate-300 rounded"></div>
                    <div className="h-1.5 w-3/4 bg-fcb-red rounded"></div>
                  </div>
                  {/* Visual design representation */}
                  <div className="absolute right-2 bottom-2 h-6 w-6 rounded-full bg-white border border-slate-300 flex items-center justify-center">
                    <Eye className="h-3 w-3 text-fcb-red" />
                  </div>
                </div>

                <div className="flex items-start justify-between">
                  <div>
                    <h5 className={`font-bold text-xs ${theme === "classic" ? "text-fcb-red" : ""}`}>
                      {language === "de" ? "FCB Classic (Rot/Weiß)" : "FCB Classic (Red/White)"}
                    </h5>
                    <p className="text-[10px] text-slate-500 mt-1 leading-normal">
                      {language === "de" 
                        ? "Traditionelles FC Bayern Design mit hohem Kontrast und roten Akzenten."
                        : "High-contrast traditional FC Bayern Red & White layout."}
                    </p>
                  </div>
                  {theme === "classic" && (
                    <span className="bg-fcb-red/10 text-fcb-red border border-fcb-red/20 rounded-full p-1 self-start">
                      <CheckCircle className="h-3.5 w-3.5" />
                    </span>
                  )}
                </div>
              </button>
            </div>
          </div>
        </div>

        {/* Voice Assistant Configurations */}
        <div className="bg-slate-900/40 p-5 rounded-2xl border border-slate-800 space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
            <Volume2 className="h-4.5 w-4.5 text-fcb-gold" />
            <h4 className="font-bold text-white text-xs uppercase tracking-wider font-mono">
              {language === "de" ? "Sprachassistent-Einstellungen" : "Voice Assistant Preferences"}
            </h4>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-slate-950/60 rounded-xl border border-slate-850">
            <div className="space-y-1">
              <span className="text-xs font-bold text-white block">
                {language === "de" ? "Audio-Rückmeldung (TTS)" : "Text-to-Speech (TTS) Feedback"}
              </span>
              <p className="text-[11px] text-slate-500">
                {language === "de" 
                  ? "Aktiviert die Sprachrückmeldung, wenn ein Sprachbefehl erkannt wurde."
                  : "Enable or disable verbal confirmation when speech commands are triggered."}
              </p>
            </div>

            <button
              onClick={() => {
                const nextVal = !speechEnabled;
                setSpeechEnabled(nextVal);
                onAddLog({
                  id: `audio-pref-${Date.now()}`,
                  timestamp: new Date().toLocaleTimeString(),
                  level: "INFO",
                  source: "Voice Setup",
                  message: language === "de"
                    ? `Audio-Rückmeldung ${nextVal ? "aktiviert" : "deaktiviert"}`
                    : `Audio feedback ${nextVal ? "enabled" : "disabled"}`
                });
              }}
              className={`px-4 py-2 rounded-lg text-xs font-mono font-bold border transition-all cursor-pointer flex items-center gap-1.5 ${
                speechEnabled
                  ? "bg-green-500/10 border-green-500/30 text-green-400 hover:bg-green-500/20"
                  : "bg-slate-900 border-slate-800 text-slate-400 hover:text-white"
              }`}
            >
              {speechEnabled ? (
                <>
                  <Volume2 className="h-3.5 w-3.5" />
                  <span>{language === "de" ? "AKTIV" : "ENABLED"}</span>
                </>
              ) : (
                <>
                  <VolumeX className="h-3.5 w-3.5" />
                  <span>{language === "de" ? "DEAKTIVIERT" : "MUTED"}</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Connection Info & Metadata (Right side Col Span 1) */}
      <div className="space-y-6">
        <div className="bg-slate-900/40 p-5 rounded-2xl border border-slate-800 space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
            <Shield className="h-5 w-5 text-fcb-gold" />
            <h3 className="font-bold text-white font-display">
              {language === "de" ? "Sicherheit & Status" : "System Diagnostics"}
            </h3>
          </div>

          <div className="space-y-3.5 text-xs font-mono">
            <div className="space-y-1">
              <span className="text-[9px] text-slate-500 uppercase tracking-wide block">Orchestrator Mode</span>
              <div className="p-2 bg-slate-950 border border-slate-850 rounded-lg flex items-center justify-between text-[10px]">
                <span className="text-slate-400">Antigravity Core</span>
                <span className="text-fcb-gold font-bold">ACTIVE V3.1</span>
              </div>
            </div>

            <div className="space-y-1">
              <span className="text-[9px] text-slate-500 uppercase tracking-wide block">RAG Engine Cluster</span>
              <div className="p-2 bg-slate-950 border border-slate-850 rounded-lg flex items-center justify-between text-[10px]">
                <span className="text-slate-400">Gemini Pro retrieved</span>
                <span className="text-green-400">SECURE DISPATCH</span>
              </div>
            </div>

            <div className="space-y-1">
              <span className="text-[9px] text-slate-500 uppercase tracking-wide block">Active Profile</span>
              <div className="p-2 bg-slate-950 border border-slate-850 rounded-lg flex items-center justify-between text-[10px]">
                <span className="text-slate-400">{language === "de" ? "Aktiver Account:" : "Target User:"}</span>
                <span className="text-slate-300 font-bold">veselintakev@fcb.de</span>
              </div>
            </div>
          </div>
        </div>

        {/* Brand visual banner card */}
        <div className="bg-gradient-to-br from-fcb-red to-rose-700 p-5 rounded-2xl border border-fcb-red text-white space-y-3 relative overflow-hidden">
          <div className="absolute right-0 bottom-0 opacity-10 font-display font-black text-6xl select-none translate-x-4 translate-y-4">
            FCB
          </div>
          <Sparkles className="h-6 w-6 text-fcb-gold animate-pulse" />
          <h4 className="font-display font-bold text-sm tracking-wide uppercase">Mia San Mia</h4>
          <p className="text-[11px] text-slate-100 leading-relaxed font-sans">
            {language === "de" 
              ? "Dieses Portal ist für die weltweite Medienarbeit des FC Bayern München autorisiert. Jede KI-generierte Kampagne unterliegt den FCB-Compliance-Regeln."
              : "This platform is authorized for the global media output of FC Bayern Munich. Every AI-assisted customer journey complies with standard FCB policy rules."}
          </p>
        </div>
      </div>
    </div>
  );
};
